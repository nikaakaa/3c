using System;
using UnityEngine;
using Unity.Collections;
using ThirdPersonCharacter.Pipeline.Animation;
using ThirdPersonCharacter.Pipeline.Presentation;
namespace ThirdPersonCharacter.Pipeline.Editor { internal static class CapturedFootPoseRigFunctions {
        internal static CharacterFootPlacementAnimatedFootPose CaptureFoot(
            Transform poseRoot,
            AnimationLocalBonePose hip,
            AnimationLocalBonePose knee,
            AnimationLocalBonePose ankle,
            AnimationLocalBonePose toe,
            Vector3 heelContactOffset,
            Vector3 toeContactOffset,
            Quaternion soleFrameLocalRotation,
            in CharacterFootPlacementFootCalibration calibration)
        {
            if (!hip.IsValid || !knee.IsValid ||
                !ankle.IsValid || !toe.IsValid)
            {
                throw new InvalidOperationException(
                    "Foot Placement upstream Component Pose is invalid.");
            }
            Quaternion rootRotation = poseRoot.rotation;
            Quaternion ankleRotation = rootRotation * ankle.Rotation;
            Quaternion toeRotation = rootRotation * toe.Rotation;
            Quaternion semanticRotation =
                ankleRotation * soleFrameLocalRotation;
            var samples = new FixedList512Bytes<Vector3>();
            Matrix4x4 rootMatrix = poseRoot.localToWorldMatrix;
            Matrix4x4 ankleMatrix = rootMatrix * Matrix4x4.TRS(ankle.Position, ankle.Rotation, ankle.Scale);
            Matrix4x4 toeMatrix = rootMatrix * Matrix4x4.TRS(toe.Position, toe.Rotation, toe.Scale);
            for (int i = 0; i < calibration.SoleSamples.Count; i++)
                samples.Add(calibration.SoleSamples[i].Resolve(ankleMatrix, toeMatrix));
            return new CharacterFootPlacementAnimatedFootPose(
                poseRoot.TransformPoint(hip.Position),
                poseRoot.TransformPoint(knee.Position),
                poseRoot.TransformPoint(ankle.Position),
                ankleRotation,
                TransformPoint(
                    poseRoot,
                    in toe,
                    toeContactOffset),
                toeRotation,
                TransformPoint(
                    poseRoot,
                    in ankle,
                    heelContactOffset),
                semanticRotation * Vector3.forward,
                semanticRotation * Vector3.up,
                semanticRotation,
                soleFrameLocalRotation)
            {
                SoleSamples = samples
            };
        }
        internal static Vector3 TransformPoint(
            Transform poseRoot,
            in AnimationLocalBonePose bone,
            Vector3 localOffset) =>
            poseRoot.TransformPoint(
                bone.Position +
                bone.Rotation * Vector3.Scale(
                    bone.Scale,
                    localOffset));
}}