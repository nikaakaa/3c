/*
目的：验证已释放接触交还目标控制权，并沿同一连续输入检查真实地形查询、插值与最终单脚 Goal。
输入：采样 B 右脚 34668～34767 共 100 帧、每帧 23 个原脚底探针、实际帧间隔、事件、路径及 Corin 正式配置。
链路：录制输入 → LandingRuntime → SwingMotionBuilder → Lifecycle（插值、真实 PhysicsScene 查询、输出约束）→ GoalTarget。
预期：旧版重现 27 帧目标缺失与掉权重；当前版保持作者权重 1，前 45 帧输出一致，24 帧真实接触继续保留目标。
边界：先逐点确认原地形一致，再连续推进两版冷启动上下文；不逐帧回填期望状态，不执行骨盆、腿 IK 或整角色回放。
净空只检查新姿态上正式向下查询命中的脚底点；无命中不能证明无碰撞。缺失的窗口前插值历史不用于要求旧空间轨迹重现。
解析、断言和 JSON 写出在计算循环外；预热后分别测量两版连续计算分配，失败也保存已完成帧和执行阶段。
说明：docs/diagnostics/foot-placement/ik-tests/expired-contact.html。
*/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using ThirdPersonCharacter.Pipeline.Animation;
using ThirdPersonCharacter.Pipeline.Presentation;
using ThirdPersonSimulation;
using Unity.Collections;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace ThirdPersonCharacter.Pipeline.Editor
{
    public sealed partial class CharacterFootCapturedContactTests
    {
        const string AssetRoot = "Assets/Configs/Character/Corin/Pipeline/Presentation/";
        static readonly string Repository = Path.GetFullPath(Path.Combine(Application.dataPath, "../../../.."));
        static string Sha256(string path)
        {
            using var algorithm = System.Security.Cryptography.SHA256.Create();
            using var stream = File.OpenRead(path);
            return BitConverter.ToString(algorithm.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }
        static CharacterFootLandingFact Fact(in CharacterFootGroundPathLanding landing)
        {
            var prediction = new CharacterFootLandingPredictionResult(CharacterFootSide.Right,
                CharacterFootLandingPredictionState.Accepted, 0, CharacterFootLandingStepSource.FormalNextLanding,
                landing.LandingEventIdentity, landing.TrajectoryGeneration, 1f, 0f, default, false,
                landing.FutureBodyTranslationSourceIdentity, default, default, default, default, default,
                new CharacterFootLandingSupport(landing.SurfaceIdentity, landing.Point, landing.Normal, 0f), default);
            return CharacterFootLandingFact.Create(landing.LandingEventIdentity, in prediction);
        }
        static CharacterFootPlacementAnimatedFootPose AnimatedPose(Row r, Row[] probes)
        {
            Vector3 rootPosition = r.V("physical-body/pose-root-world-position");
            Quaternion rootRotation = r.Q("physical-body/pose-root-world-rotation");
            Quaternion ankle = r.Q("foot/source-ankle-rotation");
            Quaternion local = r.Q("foot/resolved/core/source-sole-frame-local-rotation");
            Quaternion sole = ankle * local;
            var pose = new CharacterFootPlacementAnimatedFootPose(
                rootPosition + rootRotation * r.V("leg/leg-pose/original-hip"),
                rootPosition + rootRotation * r.V("leg/leg-pose/original-knee"),
                r.V("foot/source-ankle-position"), ankle, r.V("foot/source-toe-position"),
                Quaternion.identity, r.V("foot/source-heel-position"),
                sole * Vector3.forward, sole * Vector3.up, sole, local);
            var soleSamples = new FixedList512Bytes<Vector3>();
            foreach (Row probe in probes) soleSamples.Add(probe.V("probe-position"));
            pose.SoleSamples = soleSamples;
            return pose;
        }
        static CharacterFootGroundPathLanding PathLanding(Row r, string name, string source) =>
            new CharacterFootGroundPathLanding(r.U("foot/ground-path/" + name + "-event-identity"),
                r.U("foot/ground-path/trajectory-generation"), r.S("foot/ground-path/" + source),
                r.I("foot/ground-path/" + name + "-surface-identity"),
                r.V("foot/ground-path/" + name), r.V("foot/ground-path/" + name + "-normal"));
        static CharacterFootGroundPathResult PathInput(Row r, JToken captured, JObject columns,
            CharacterFootSide side = CharacterFootSide.Right)
        {
            var page = new CharacterFootGroundPathPage(64);
            if (r.I("foot/ground-path/state") == (int)CharacterFootGroundPathState.Rejected)
            {
                page.SetRejected((CharacterFootGroundPathRejectReason)r.I("foot/ground-path/reject-reason"),
                    r.B("foot/ground-path/query-executed-this-frame"),
                    r.I("foot/ground-path/segment-count"), default, default);
                return new CharacterFootGroundPathResult(page, true);
            }
            var last = PathLanding(r, "last-landing", "last-future-body-translation-source-identity");
            var next = PathLanding(r, "next-swing-landing", "next-swing-future-body-translation-source-identity");
            var key = CharacterFootGroundPathInputBuilder.BuildKey(side,
                in last, in next, r.U("foot/ground-path/authority-tick"), Vector3.up, string.Empty);
            const string q = "foot/ground-path/query/";
            var query = new CharacterFootGroundPathQueryRequest(side,
                r.V(q + "axis-start"), r.V(q + "axis-end"), r.F(q + "radius"),
                r.F(q + "maximum-axis-segment-length"), r.V(q + "direction"),
                r.F(q + "maximum-distance"), r.I(q + "layer-mask"),
                r.I(q + "segment-hit-capacity"), r.I(q + "contact-capacity"));
            var input = new CharacterFootGroundPathInput(r.U("foot/ground-path/input-identity"),
                in key, last.Point, next.Point, last.Normal, next.Normal,
                last.SurfaceIdentity, next.SurfaceIdentity, r.V("foot/ground-path/component-up"),
                r.F("foot/ground-path/maximum-reachable-vertical-edge"), in query);
            Assert.That(page.Contacts.SurfaceCoverage.Begin(input.Query,
                r.U("foot/ground-path/surface-coverage/world-revision")), Is.True);
            foreach (Row surface in Row.Table(captured, columns, "surfaces"))
                Assert.That(page.Contacts.SurfaceCoverage.TryAdd(surface.I("surface-identity"),
                    surface.I("face-identity"), surface.V2("start"), surface.V2("end")), Is.True);
            page.Contacts.SurfaceCoverage.Complete();
            foreach (Row contact in Row.Table(captured, columns, "contacts"))
            {
                var value = new CharacterFootGroundContact(contact.I("segment-index"), contact.I("surface-identity"),
                    contact.U("candidate-identity"), contact.V("position"), contact.V("normal"), contact.F("query-distance"));
                Assert.That(page.Contacts.TryAdd(in value), Is.True);
            }
            foreach (Row vertex in Row.Table(captured, columns, "envelope"))
                Assert.That(page.Envelope.TryPush(vertex.V("position")), Is.True);
            page.SetAccepted(r.I("foot/ground-path/segment-count"), in input);
            return new CharacterFootGroundPathResult(page, true);
        }
        static string Git(string arguments) => Run("git", arguments);
        static string Run(string executable, string arguments)
        {
            using var process = Process.Start(new ProcessStartInfo(executable, arguments)
            {
                WorkingDirectory = Repository, UseShellExecute = false,
                RedirectStandardOutput = true, RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8,
                CreateNoWindow = true
            });
            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();
            process.WaitForExit();
            Assert.That(process.ExitCode, Is.Zero, output + error);
            return output.TrimEnd();
        }
        static JArray Vec(Vector3 value) => new JArray(value.x, value.y, value.z);
        sealed class Row
        {
            readonly Dictionary<string, string> values;
            Row(JToken values, JToken columns) => this.values = columns.Select((x, i) =>
                new KeyValuePair<string, string>((string)x, (string)values[i])).ToDictionary(x => x.Key, x => x.Value);
            internal static Row Main(JToken frame, JObject columns) => new Row(frame["main"], columns["main"]);
            internal static IEnumerable<Row> Table(JToken frame, JObject columns, string name) =>
                frame[name].Select(x => new Row(x, columns[name]));
            internal string S(string key) => values[key];
            internal float F(string key) => float.Parse(S(key), CultureInfo.InvariantCulture);
            internal int I(string key) => int.Parse(S(key), CultureInfo.InvariantCulture);
            internal ulong U(string key) => ulong.Parse(S(key), CultureInfo.InvariantCulture);
            internal bool B(string key) => bool.Parse(S(key));
            internal Vector3 V(string key) => new Vector3(F(key + ".x"), F(key + ".y"), F(key + ".z"));
            internal Vector2 V2(string key) => new Vector2(F(key + ".x"), F(key + ".y"));
            internal Quaternion Q(string key) => new Quaternion(F(key + ".x"), F(key + ".y"), F(key + ".z"), F(key + ".w"));
        }
    }
}
