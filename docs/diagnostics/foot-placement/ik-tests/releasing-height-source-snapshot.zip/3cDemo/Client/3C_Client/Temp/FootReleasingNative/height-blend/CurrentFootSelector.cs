using System;
namespace ThirdPersonCharacter.Pipeline.Animation { internal static class CurrentFootSelector {
        internal static int RequireFootMotionContribution(
            AnimationPoseSourceContribution[] contributions,
            int contributionCount)
        {
            int selected = -1;
            float selectedWeight = 0f;
            for (int i = 0; i < contributionCount; i++)
            {
                ref readonly AnimationPoseSourceContribution candidate = ref contributions[i];
                if (candidate.Weight <= selectedWeight)
                {
                    continue;
                }
                selected = i;
                selectedWeight = candidate.Weight;
            }
            if (selected < 0)
                throw new InvalidOperationException(
                    "Foot Placement has no contributing Foot Motion sample.");
            return selected;
        }
}}