using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Profiling;

namespace ThirdPersonCharacter.Pipeline.Animation {
    internal static class CharacterPoseNativePoseBufferCopy
    {
        internal static void ValidateLayout(
            in CharacterPoseNativePoseReadBinding input,
            in AnimationPlayerPoseNativeWriteBinding output)
        {
            if (input.DenseLocalPoses.Length != output.DenseLocalPoses.Length ||
                input.PoseParameters.Length != output.PoseParameters.Length ||
                input.ContributionCount[0] < 0 ||
                input.ContributionCount[0] > output.Contributions.Length ||
                input.Contributions.Length < input.ContributionCount[0] ||
                input.DenseContributionWeights.Length <
                input.ContributionCount[0] * input.DenseLocalPoses.Length)
            {
                throw new InvalidOperationException(
                    "Pose native node buffer layouts are incompatible.");
            }
        }

        internal static void CopyMetadata(
            in CharacterPoseNativePoseReadBinding input,
            in AnimationPlayerPoseNativeWriteBinding output)
        {
            CopyAttributes(in input, in output);
            NativeSlice<AnimationBlendBoneVelocity> outputVelocities =
                output.DenseVelocities;
            outputVelocities.CopyFrom(input.DenseVelocities);
        }

        internal static void CopyAttributes(
            in CharacterPoseNativePoseReadBinding input,
            in AnimationPlayerPoseNativeWriteBinding output)
        {
            ValidateLayout(in input, in output);
            NativeSlice<float> outputParameters = output.PoseParameters;
            NativeSlice<byte> outputParameterAvailability =
                output.PoseParameterAvailability;
            NativeSlice<AnimationPrimitivePoseContribution> outputContributions =
                output.Contributions;
            NativeSlice<float> outputContributionWeights =
                output.DenseContributionWeights;
            NativeSlice<float> outputOutputWeight = output.OutputWeight;
            NativeSlice<AnimationFootFeatureSample> outputLeftFootFeatures =
                output.LeftFootFeatures;
            NativeSlice<AnimationFootFeatureSample> outputRightFootFeatures =
                output.RightFootFeatures;
            NativeSlice<byte> outputHasFootFeatures = output.HasFootFeatures;
            NativeSlice<AnimationPoseAvailability> outputAvailability =
                output.Availability;
            NativeSlice<ulong> outputContinuity = output.ContinuityIdentity;
            NativeSlice<PoseDiscontinuityNative> outputDiscontinuity =
                output.Discontinuity;
            NativeSlice<AnimationPoseNativeInvalidReason> outputInvalidReason =
                output.InvalidReason;
            NativeSlice<ulong> outputCompletedAt = output.CompletedAt;
            outputParameters.CopyFrom(input.PoseParameters);
            outputParameterAvailability.CopyFrom(input.PoseParameterAvailability);
            int contributionCount = input.ContributionCount[0];
            ExtendContributionPrefix(in output, contributionCount);
            outputContributions.Slice(0, contributionCount).CopyFrom(input.Contributions.Slice(0, contributionCount));
            int boneCount = output.DenseLocalPoses.Length;
            int weightCount = contributionCount * boneCount;
            outputContributionWeights.Slice(0, weightCount).CopyFrom(input.DenseContributionWeights.Slice(0, weightCount));
            CompleteContributions(in output, contributionCount);
            outputOutputWeight[0] = input.OutputWeight[0];
            outputLeftFootFeatures[0] = input.LeftFootFeatures[0];
            outputRightFootFeatures[0] = input.RightFootFeatures[0];
            outputHasFootFeatures[0] = input.HasFootFeatures[0];
            outputAvailability[0] = input.Availability[0];
            outputContinuity[0] = input.ContinuityIdentity[0];
            outputDiscontinuity[0] = input.Discontinuity[0];
            outputInvalidReason[0] = input.InvalidReason[0];
            outputCompletedAt[0] = input.CompletedAt[0];
        }

        internal static void ExtendContributionPrefix(
            in AnimationPlayerPoseNativeWriteBinding output,
            int contributionCount)
        {
            NativeSlice<int> count = output.ContributionCount;
            if (contributionCount > count[0])
                count[0] = contributionCount;
        }

        internal static void CompleteContributions(
            in AnimationPlayerPoseNativeWriteBinding output,
            int contributionCount)
        {
            // Pending writes retain their touched prefix until tail cleanup succeeds.
            NativeSlice<int> count = output.ContributionCount;
            int previousCount = count[0];
            NativeSlice<AnimationPrimitivePoseContribution> contributions = output.Contributions;
            NativeSlice<float> weights = output.DenseContributionWeights;
            for (int i = contributionCount; i < previousCount; i++)
                contributions[i] = default;
            int boneCount = output.DenseLocalPoses.Length;
            int previousWeightCount = previousCount * boneCount;
            for (int i = contributionCount * boneCount; i < previousWeightCount; i++)
                weights[i] = 0f;
            count[0] = contributionCount;
        }
    }
}