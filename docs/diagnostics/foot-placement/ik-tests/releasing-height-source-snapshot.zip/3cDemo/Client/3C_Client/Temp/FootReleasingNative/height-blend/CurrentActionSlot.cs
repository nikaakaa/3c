using System;
using Unity.Collections;
using UnityEngine;
namespace ThirdPersonCharacter.Pipeline.Animation { internal sealed class CurrentActionSlot {

        AnimationPlayerPoseNativeWriteBinding m_WriteBinding;
        ulong m_LastSourceContinuity, m_LastActionContinuity, m_ContinuityIdentity;
        ulong m_NextContinuityIdentity = 1;
        float m_LastActionWeight;
        CharacterPoseNativeLocalPoseValue m_Output;
        PoseNodeId NodeId => new PoseNodeId("corin.full-body-action.slot");
        internal void Evaluate(in CharacterPoseNativePoseReadBinding source, in CharacterPoseNativePoseReadBinding action,
            in AnimationPlayerPoseNativeWriteBinding output, bool hasAction) { m_WriteBinding = output; if (hasAction) BlendPoses(in source, in action); else CopyPose(in source, CharacterPoseSpace.Local); }
        void BlendPoses(
            in CharacterPoseNativePoseReadBinding source,
            in CharacterPoseNativePoseReadBinding action)
        {
            float actionGlobalWeight = Mathf.Clamp01(action.OutputWeight[0]);
            float sourceGlobalWeight = Mathf.Clamp01(1f - actionGlobalWeight);
            if (m_LastSourceContinuity != source.ContinuityIdentity[0] ||
                m_LastActionContinuity != action.ContinuityIdentity[0] ||
                m_LastActionWeight != actionGlobalWeight)
            {
                if (m_NextContinuityIdentity == ulong.MaxValue)
                    throw new InvalidOperationException(
                        $"Animation Slot '{NodeId}' continuity identity was exhausted.");
                m_ContinuityIdentity = m_NextContinuityIdentity++;
                m_LastSourceContinuity = source.ContinuityIdentity[0];
                m_LastActionContinuity = action.ContinuityIdentity[0];
                m_LastActionWeight = actionGlobalWeight;
            }
            NativeSlice<AnimationLocalBonePose> outputPoses =
                m_WriteBinding.DenseLocalPoses;
            NativeSlice<AnimationBlendBoneVelocity> outputVelocities =
                m_WriteBinding.DenseVelocities;
            NativeSlice<AnimationLocalBonePose> sourcePoses =
                source.DenseLocalPoses;
            NativeSlice<AnimationLocalBonePose> actionPoses =
                action.DenseLocalPoses;
            NativeSlice<AnimationBlendBoneVelocity> sourceVelocities =
                source.DenseVelocities;
            NativeSlice<AnimationBlendBoneVelocity> actionVelocities =
                action.DenseVelocities;
            int actionContributionCount = action.ContributionCount[0];
            int actionBoneCount = action.DenseLocalPoses.Length;
            NativeSlice<float> actionContributionWeights =
                action.DenseContributionWeights;
            for (int bone = 0; bone < outputPoses.Length; bone++)
            {
                float actionBoneWeight = BoneOutputWeight(
                    bone,
                    actionContributionCount,
                    actionBoneCount,
                    actionContributionWeights);
                float sourceBoneWeight = 1f - actionBoneWeight;
                AnimationLocalBonePose sourcePose = sourcePoses[bone];
                AnimationLocalBonePose actionPose = actionPoses[bone];
                float total = sourceBoneWeight + actionBoneWeight;
                if (!sourcePose.IsValid || !actionPose.IsValid || total <= 0f)
                    throw new InvalidOperationException(
                        $"Animation Slot '{NodeId}' Bone #{bone} Pose is invalid.");
                Vector3 position =
                    (sourcePose.Position * sourceBoneWeight +
                     actionPose.Position * actionBoneWeight) / total;
                Vector3 scale =
                    (sourcePose.Scale * sourceBoneWeight +
                     actionPose.Scale * actionBoneWeight) / total;
                Vector4 rotation =
                    new Vector4(
                        sourcePose.Rotation.x * sourceBoneWeight,
                        sourcePose.Rotation.y * sourceBoneWeight,
                        sourcePose.Rotation.z * sourceBoneWeight,
                        sourcePose.Rotation.w * sourceBoneWeight) +
                    AnimationPoseMath.AlignAndScale(
                        actionPose.Rotation,
                        sourcePose.Rotation,
                        actionBoneWeight);
                outputPoses[bone] = AnimationPoseMath.BlendWeighted(
                    position * total,
                    rotation,
                    scale * total,
                    total,
                    sourcePose);
                AnimationBlendBoneVelocity sourceVelocity = sourceVelocities[bone];
                AnimationBlendBoneVelocity actionVelocity = actionVelocities[bone];
                outputVelocities[bone] = new AnimationBlendBoneVelocity(
                    Vector3.LerpUnclamped(
                        sourceVelocity.Linear,
                        actionVelocity.Linear,
                        actionBoneWeight),
                    Vector3.LerpUnclamped(
                        sourceVelocity.Angular,
                        actionVelocity.Angular,
                        actionBoneWeight),
                    Vector3.LerpUnclamped(
                        sourceVelocity.Scale,
                        actionVelocity.Scale,
                        actionBoneWeight));
            }
            BlendParameters(in source, in action, sourceGlobalWeight, actionGlobalWeight);
            BlendContributions(in source, in action, in m_WriteBinding);
            m_WriteBinding.OutputWeight[0] = Mathf.Clamp01(
                source.OutputWeight[0] + action.OutputWeight[0]);
            BlendFeet(in source, in action, sourceGlobalWeight, actionGlobalWeight);
            m_WriteBinding.Availability[0] = AnimationPoseAvailability.Pose;
            m_WriteBinding.ContinuityIdentity[0] = m_ContinuityIdentity;
            m_WriteBinding.Discontinuity[0] = actionGlobalWeight >= 0.5f
                ? action.Discontinuity[0]
                : source.Discontinuity[0];
            m_WriteBinding.InvalidReason[0] = AnimationPoseNativeInvalidReason.None;
            m_WriteBinding.CompletedAt[0] = m_WriteBinding.CompletionIdentity;
            CharacterPoseNativePoseReadBinding output =
                new CharacterPoseNativePoseReadBinding(in m_WriteBinding);
            m_Output = CharacterPoseNativeLocalPoseValue.Reuse(
                m_Output,
                NodeId,
                in output);
        }
        void CopyPose(
            in CharacterPoseNativePoseReadBinding input,
            CharacterPoseSpace space)
        {
            CharacterPoseNativePoseBufferCopy.CopyMetadata(
                in input,
                in m_WriteBinding);
            NativeSlice<AnimationLocalBonePose> poses =
                m_WriteBinding.DenseLocalPoses;
            poses.CopyFrom(input.DenseLocalPoses);
            CharacterPoseNativePoseReadBinding output =
                new CharacterPoseNativePoseReadBinding(in m_WriteBinding, space);
            m_ContinuityIdentity = input.ContinuityIdentity[0];
            m_LastSourceContinuity = input.ContinuityIdentity[0];
            m_LastActionContinuity = 0;
            m_LastActionWeight = 0f;
            m_Output = CharacterPoseNativeLocalPoseValue.Reuse(
                m_Output,
                NodeId,
                in output);
        }
        void BlendParameters(
            in CharacterPoseNativePoseReadBinding source,
            in CharacterPoseNativePoseReadBinding action,
            float sourceWeight,
            float actionWeight)
        {
            NativeSlice<float> parameters = m_WriteBinding.PoseParameters;
            NativeSlice<byte> availability = m_WriteBinding.PoseParameterAvailability;
            NativeSlice<float> sourceParameters = source.PoseParameters;
            NativeSlice<float> actionParameters = action.PoseParameters;
            NativeSlice<byte> sourceAvailability =
                source.PoseParameterAvailability;
            NativeSlice<byte> actionAvailability =
                action.PoseParameterAvailability;
            for (int parameter = 0; parameter < parameters.Length; parameter++)
            {
                byte sourceAvailable = sourceAvailability[parameter];
                byte actionAvailable = actionAvailability[parameter];
                if (sourceAvailable != 0 && actionAvailable != 0)
                {
                    parameters[parameter] =
                        (sourceParameters[parameter] * sourceWeight +
                         actionParameters[parameter] * actionWeight) /
                        (sourceWeight + actionWeight);
                    availability[parameter] = 1;
                }
                else if (actionAvailable != 0)
                {
                    parameters[parameter] = actionParameters[parameter];
                    availability[parameter] = 1;
                }
                else
                {
                    parameters[parameter] = sourceParameters[parameter];
                    availability[parameter] = sourceAvailable;
                }
            }
        }
        static void AppendContributions(
            in CharacterPoseNativePoseReadBinding input,
            in CharacterPoseNativePoseReadBinding action,
            in AnimationPlayerPoseNativeWriteBinding outputBinding,
            bool actionContribution,
            float factor,
            float leftFootFactor,
            float rightFootFactor,
            ref int outputCount)
        {
            int inputCount = input.ContributionCount[0];
            int boneCount = outputBinding.DenseLocalPoses.Length;
            NativeSlice<AnimationPrimitivePoseContribution> output =
                outputBinding.Contributions;
            NativeSlice<float> outputWeights =
                outputBinding.DenseContributionWeights;
            NativeSlice<AnimationPrimitivePoseContribution> inputContributions =
                input.Contributions;
            NativeSlice<float> inputWeights =
                input.DenseContributionWeights;
            for (int contribution = 0; contribution < inputCount; contribution++)
            {
                if (outputCount >= output.Length)
                    throw new InvalidOperationException(
                        "Animation Slot contribution capacity was exceeded.");
                AnimationPrimitivePoseContribution value = inputContributions[contribution];
                CharacterPoseNativePoseBufferCopy.ExtendContributionPrefix(in outputBinding, outputCount + 1);
                int outputWeightOffset = outputCount * boneCount;
                int inputWeightOffset = contribution * boneCount;
                output[outputCount] = new AnimationPrimitivePoseContribution(
                    value.PhysicalPlayerIndex,
                    value.PhysicalSourceIndex,
                    value.PhysicalSourceGeneration,
                    value.Kind,
                    value.SourceOwnerIndex,
                    value.ContributionContinuityIdentity,
                    value.Weight * factor,
                    value.LeftFootWeight * leftFootFactor,
                    value.RightFootWeight * rightFootFactor,
                    in value.FootMotion);
                for (int bone = 0; bone < boneCount; bone++)
                {
                    float boneFactor = actionContribution
                        ? 1f
                        : 1f - BoneOutputWeight(bone, action.ContributionCount[0],
                            boneCount, action.DenseContributionWeights);
                    outputWeights[outputWeightOffset + bone] =
                        inputWeights[inputWeightOffset + bone] * boneFactor;
                }
                outputCount++;
            }
        }
        void BlendFeet(
            in CharacterPoseNativePoseReadBinding source,
            in CharacterPoseNativePoseReadBinding action,
            float sourceWeight,
            float actionWeight)
        {
            bool hasSource = source.HasFootFeatures[0] != 0;
            bool hasAction = action.HasFootFeatures[0] != 0;
            if (hasSource && hasAction && sourceWeight > 0f && actionWeight > 0f)
            {
                var left = new AnimationFootFeatureBlendAccumulator();
                var right = new AnimationFootFeatureBlendAccumulator();
                left.Add(source.LeftFootFeatures[0], sourceWeight);
                left.Add(action.LeftFootFeatures[0], actionWeight);
                right.Add(source.RightFootFeatures[0], sourceWeight);
                right.Add(action.RightFootFeatures[0], actionWeight);
                m_WriteBinding.LeftFootFeatures[0] = left.Resolve();
                m_WriteBinding.RightFootFeatures[0] = right.Resolve();
                m_WriteBinding.HasFootFeatures[0] = 1;
                return;
            }
            if (hasAction && actionWeight > 0f)
            {
                m_WriteBinding.LeftFootFeatures[0] = action.LeftFootFeatures[0];
                m_WriteBinding.RightFootFeatures[0] = action.RightFootFeatures[0];
                m_WriteBinding.HasFootFeatures[0] = 1;
                return;
            }
            if (hasSource && sourceWeight > 0f)
            {
                m_WriteBinding.LeftFootFeatures[0] = source.LeftFootFeatures[0];
                m_WriteBinding.RightFootFeatures[0] = source.RightFootFeatures[0];
                m_WriteBinding.HasFootFeatures[0] = 1;
                return;
            }
            m_WriteBinding.LeftFootFeatures[0] = default;
            m_WriteBinding.RightFootFeatures[0] = default;
            m_WriteBinding.HasFootFeatures[0] = 0;
        }
        static float BoneOutputWeight(
            int bone,
            int contributionCount,
            int boneCount,
            NativeSlice<float> contributionWeights)
        {
            float weight = 0f;
            for (int contribution = 0; contribution < contributionCount; contribution++)
                weight += contributionWeights[
                    contribution * boneCount + bone];
            return Mathf.Clamp01(weight);
        }
        internal static void BlendContributions(
            in CharacterPoseNativePoseReadBinding source,
            in CharacterPoseNativePoseReadBinding action,
            in AnimationPlayerPoseNativeWriteBinding output)
        {
            float actionLeftWeight = 0f;
            float actionRightWeight = 0f;
            NativeSlice<AnimationPrimitivePoseContribution> actionContributions = action.Contributions;
            for (int i = 0; i < action.ContributionCount[0]; i++)
            {
                AnimationPrimitivePoseContribution value = actionContributions[i];
                actionLeftWeight += value.LeftFootWeight;
                actionRightWeight += value.RightFootWeight;
            }
            int count = 0;
            AppendContributions(in source, in action, in output, false,
                1f - Mathf.Clamp01(action.OutputWeight[0]),
                1f - Mathf.Clamp01(actionLeftWeight),
                1f - Mathf.Clamp01(actionRightWeight), ref count);
            AppendContributions(in action, in action, in output, true, 1f, 1f, 1f, ref count);
            CharacterPoseNativePoseBufferCopy.CompleteContributions(in output, count);
        }
}}