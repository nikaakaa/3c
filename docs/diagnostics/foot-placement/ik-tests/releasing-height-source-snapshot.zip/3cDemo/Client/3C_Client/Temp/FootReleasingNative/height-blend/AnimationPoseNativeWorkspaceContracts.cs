using System;
using ThirdPersonCharacter.Pipeline.Animation.BlendStack;
using Unity.Collections;

namespace ThirdPersonCharacter.Pipeline.Animation {
    internal readonly struct AnimationPrimitivePoseContribution
    {
        internal AnimationPrimitivePoseContribution(
            int physicalSlotIndex,
            int physicalSourceIndex,
            ulong physicalSourceGeneration,
            AnimationPoseContributionKind kind,
            int sourceOwnerIndex,
            ulong contributionContinuityIdentity,
            float weight,
            float leftFootWeight,
            float rightFootWeight,
            in AnimationFootMotionSourceSample footMotion)
        {
            int kindValue = (int)kind;
            if (physicalSlotIndex < 0 ||
                kindValue < (int)AnimationPoseContributionKind.Live ||
                kindValue > (int)AnimationPoseContributionKind.Stored ||
                kind == AnimationPoseContributionKind.Live &&
                (physicalSourceIndex < 0 || physicalSourceGeneration == 0 || sourceOwnerIndex < 0) ||
                kind != AnimationPoseContributionKind.Live &&
                (physicalSourceIndex != -1 || physicalSourceGeneration != 0 || sourceOwnerIndex != -1) ||
                contributionContinuityIdentity == 0 ||
                !float.IsFinite(weight) || weight < 0f || weight > 1f ||
                !float.IsFinite(leftFootWeight) || leftFootWeight < 0f || leftFootWeight > 1f ||
                !float.IsFinite(rightFootWeight) || rightFootWeight < 0f || rightFootWeight > 1f)
            {
                throw new ArgumentException("Primitive animation pose contribution is invalid.");
            }

            PhysicalPlayerIndex = physicalSlotIndex;
            PhysicalSourceIndex = physicalSourceIndex;
            PhysicalSourceGeneration = physicalSourceGeneration;
            Kind = kind;
            SourceOwnerIndex = sourceOwnerIndex;
            ContributionContinuityIdentity = contributionContinuityIdentity;
            Weight = weight;
            LeftFootWeight = leftFootWeight;
            RightFootWeight = rightFootWeight;
            FootMotion = footMotion;
        }

        internal int PhysicalPlayerIndex { get; }
        internal int PhysicalSourceIndex { get; }
        internal ulong PhysicalSourceGeneration { get; }
        internal AnimationPoseContributionKind Kind { get; }
        internal int SourceOwnerIndex { get; }
        internal ulong ContributionContinuityIdentity { get; }
        internal float Weight { get; }
        internal float LeftFootWeight { get; }
        internal float RightFootWeight { get; }
        internal readonly AnimationFootMotionSourceSample FootMotion;
    }
    internal struct AnimationPlayerPoseNativeWriteBinding
    {
        internal AnimationPlayerPoseNativeWriteBinding(
            int physicalPlayerIndex,
            int boneCount,
            int parameterCount,
            int contributionCapacity,
            ulong completionIdentity,
            NativeSlice<AnimationLocalBonePose> denseLocalPoses,
            NativeSlice<AnimationBlendBoneVelocity> denseVelocities,
            NativeSlice<float> poseParameters,
            NativeSlice<byte> poseParameterAvailability,
            NativeSlice<AnimationPrimitivePoseContribution> contributions,
            NativeSlice<float> denseContributionWeights,
            NativeSlice<int> contributionCount,
            NativeSlice<float> outputWeight,
            NativeSlice<AnimationFootFeatureSample> leftFootFeatures,
            NativeSlice<AnimationFootFeatureSample> rightFootFeatures,
            NativeSlice<byte> hasFootFeatures,
            NativeSlice<AnimationPoseAvailability> availability,
            NativeSlice<ulong> continuityIdentity,
            NativeSlice<PoseDiscontinuityNative> discontinuity,
            NativeSlice<AnimationPoseNativeInvalidReason> invalidReason,
            NativeSlice<ulong> completedAt)
        {
            if (physicalPlayerIndex < 0 || boneCount <= 0 || parameterCount <= 0 ||
                contributionCapacity <= 0 || completionIdentity == 0 ||
                denseLocalPoses.Length != boneCount ||
                denseVelocities.Length != boneCount ||
                poseParameters.Length != parameterCount ||
                poseParameterAvailability.Length != parameterCount ||
                contributions.Length != contributionCapacity ||
                denseContributionWeights.Length !=
                    checked(contributionCapacity * boneCount) ||
                contributionCount.Length != 1 || outputWeight.Length != 1 ||
                leftFootFeatures.Length != 1 || rightFootFeatures.Length != 1 ||
                hasFootFeatures.Length != 1 || availability.Length != 1 ||
                continuityIdentity.Length != 1 || discontinuity.Length != 1 ||
                invalidReason.Length != 1 || completedAt.Length != 1)
            {
                throw new ArgumentException(
                    "Animation pose native node write binding is invalid.");
            }
            Range = new AnimationPlayerPoseNativeRange(
                physicalPlayerIndex,
                0,
                0,
                0,
                0,
                contributionCapacity,
                0);
            CompletionIdentity = completionIdentity;
            DenseLocalPoses = denseLocalPoses;
            DenseVelocities = denseVelocities;
            PoseParameters = poseParameters;
            PoseParameterAvailability = poseParameterAvailability;
            Contributions = contributions;
            DenseContributionWeights = denseContributionWeights;
            ContributionCount = contributionCount;
            OutputWeight = outputWeight;
            LeftFootFeatures = leftFootFeatures;
            RightFootFeatures = rightFootFeatures;
            HasFootFeatures = hasFootFeatures;
            Availability = availability;
            ContinuityIdentity = continuityIdentity;
            Discontinuity = discontinuity;
            InvalidReason = invalidReason;
            CompletedAt = completedAt;
        }


        internal AnimationPlayerPoseNativeRange Range;
        internal ulong CompletionIdentity;
        internal NativeSlice<AnimationLocalBonePose> DenseLocalPoses;
        internal NativeSlice<AnimationBlendBoneVelocity> DenseVelocities;
        internal NativeSlice<float> PoseParameters;
        internal NativeSlice<byte> PoseParameterAvailability;
        internal NativeSlice<AnimationPrimitivePoseContribution> Contributions;
        internal NativeSlice<float> DenseContributionWeights;
        internal NativeSlice<int> ContributionCount;
        internal NativeSlice<float> OutputWeight;
        internal NativeSlice<AnimationFootFeatureSample> LeftFootFeatures;
        internal NativeSlice<AnimationFootFeatureSample> RightFootFeatures;
        internal NativeSlice<byte> HasFootFeatures;
        internal NativeSlice<AnimationPoseAvailability> Availability;
        internal NativeSlice<ulong> ContinuityIdentity;
        internal NativeSlice<PoseDiscontinuityNative> Discontinuity;
        internal NativeSlice<AnimationPoseNativeInvalidReason> InvalidReason;
        internal NativeSlice<ulong> CompletedAt;
    }
    internal readonly struct AnimationPoseValueNativeReadBinding
    {

        internal AnimationPoseValueNativeReadBinding(
            in CharacterPoseNativePoseReadBinding native)
        {
            if (!native.IsValid)
                throw new ArgumentException(
                    "Animation pose native read binding is invalid.",
                    nameof(native));
            CompletionIdentity = native.CompletionIdentity;
            ValueIndex = -1;
            DensePoses = native.DenseLocalPoses;
            PoseParameters = native.PoseParameters;
            PoseParameterAvailability = native.PoseParameterAvailability;
            Contributions = native.Contributions;
            DenseContributionWeights = native.DenseContributionWeights;
            ContributionCount = native.ContributionCount;
            OutputWeight = native.OutputWeight;
            LeftFootFeatures = native.LeftFootFeatures;
            RightFootFeatures = native.RightFootFeatures;
            HasFootFeatures = native.HasFootFeatures;
            Availability = native.Availability;
            ContinuityIdentity = native.ContinuityIdentity;
            InvalidReason = native.InvalidReason;
            PoseGraphInvalidOperationIndex = default;
        }


        internal ulong CompletionIdentity { get; }
        internal int ValueIndex { get; }
        internal readonly NativeSlice<AnimationLocalBonePose> DensePoses;
        internal readonly NativeSlice<float> PoseParameters;
        internal readonly NativeSlice<byte> PoseParameterAvailability;
        internal readonly NativeSlice<AnimationPrimitivePoseContribution> Contributions;
        internal readonly NativeSlice<float> DenseContributionWeights;
        internal readonly NativeSlice<int> ContributionCount;
        internal readonly NativeSlice<float> OutputWeight;
        internal readonly NativeSlice<AnimationFootFeatureSample> LeftFootFeatures;
        internal readonly NativeSlice<AnimationFootFeatureSample> RightFootFeatures;
        internal readonly NativeSlice<byte> HasFootFeatures;
        internal readonly NativeSlice<AnimationPoseAvailability> Availability;
        internal readonly NativeSlice<ulong> ContinuityIdentity;
        internal readonly NativeSlice<AnimationPoseNativeInvalidReason> InvalidReason;
        internal readonly NativeSlice<int> PoseGraphInvalidOperationIndex;
    }
}