using System;
using BTSMTL.EventGraphs;
using ThirdPersonCharacter.Pipeline.Animation.MotionMatching;
using Unity.Collections;

namespace ThirdPersonCharacter.Pipeline.Animation {
    internal readonly struct CharacterPoseNativePoseReadBinding
    {

        internal CharacterPoseNativePoseReadBinding(
            in AnimationPlayerPoseNativeWriteBinding output)
            : this(in output, CharacterPoseSpace.Local)
        {
        }

        internal CharacterPoseNativePoseReadBinding(
            in AnimationPlayerPoseNativeWriteBinding output,
            CharacterPoseSpace space)
        {
            if (output.CompletionIdentity == 0 ||
                space != CharacterPoseSpace.Local &&
                space != CharacterPoseSpace.Component ||
                output.DenseLocalPoses.Length == 0 ||
                output.DenseVelocities.Length != output.DenseLocalPoses.Length ||
                output.PoseParameters.Length == 0 ||
                output.PoseParameterAvailability.Length !=
                    output.PoseParameters.Length ||
                output.Contributions.Length == 0 ||
                output.DenseContributionWeights.Length !=
                    output.Contributions.Length * output.DenseLocalPoses.Length ||
                output.ContributionCount.Length != 1 ||
                output.OutputWeight.Length != 1 ||
                output.LeftFootFeatures.Length != 1 ||
                output.RightFootFeatures.Length != 1 ||
                output.HasFootFeatures.Length != 1 ||
                output.Availability.Length != 1 ||
                output.ContinuityIdentity.Length != 1 ||
                output.Discontinuity.Length != 1 ||
                output.InvalidReason.Length != 1 ||
                output.CompletedAt.Length != 1)
            {
                throw new ArgumentException(
                    "Pose native read binding is invalid.",
                    nameof(output));
            }
            CompletionIdentity = output.CompletionIdentity;
            Space = space;
            DenseLocalPoses = output.DenseLocalPoses;
            DenseVelocities = output.DenseVelocities;
            PoseParameters = output.PoseParameters;
            PoseParameterAvailability = output.PoseParameterAvailability;
            Contributions = output.Contributions;
            DenseContributionWeights = output.DenseContributionWeights;
            ContributionCount = output.ContributionCount;
            OutputWeight = output.OutputWeight;
            LeftFootFeatures = output.LeftFootFeatures;
            RightFootFeatures = output.RightFootFeatures;
            HasFootFeatures = output.HasFootFeatures;
            Availability = output.Availability;
            ContinuityIdentity = output.ContinuityIdentity;
            Discontinuity = output.Discontinuity;
            InvalidReason = output.InvalidReason;
            CompletedAt = output.CompletedAt;
        }

        internal ulong CompletionIdentity { get; }
        internal CharacterPoseSpace Space { get; }
        internal readonly NativeSlice<AnimationLocalBonePose> DenseLocalPoses;
        internal readonly NativeSlice<AnimationBlendBoneVelocity> DenseVelocities;
        internal readonly NativeSlice<float> PoseParameters;
        internal readonly NativeSlice<byte> PoseParameterAvailability;
        internal readonly NativeSlice<AnimationPrimitivePoseContribution> Contributions;
        internal readonly NativeSlice<float> DenseContributionWeights;
        internal readonly NativeSlice<int> ContributionCount;
        internal readonly NativeSlice<float> OutputWeight;
        internal readonly NativeSlice<AnimationFootFeatureSample> LeftFootFeatures;
        internal readonly NativeSlice<AnimationFootFeatureSample> RightFootFeatures;
        internal readonly NativeSlice<byte> HasFootFeatures;
        internal readonly NativeSlice<AnimationPoseAvailability> Availability;
        internal readonly NativeSlice<ulong> ContinuityIdentity;
        internal readonly NativeSlice<PoseDiscontinuityNative> Discontinuity;
        internal readonly NativeSlice<AnimationPoseNativeInvalidReason> InvalidReason;
        internal readonly NativeSlice<ulong> CompletedAt;
        internal bool IsValid => CompletionIdentity != 0;
    }
    internal abstract class CharacterPoseNativePortValue
    {
        PoseNodeId m_ProducerNodeId;
        ulong m_CompletionIdentity;

        protected CharacterPoseNativePortValue(
            PoseNodeId producerNodeId,
            ulong completionIdentity)
        {
            SetIdentity(producerNodeId, completionIdentity);
        }

        internal PoseNodeId ProducerNodeId => m_ProducerNodeId;
        internal ulong CompletionIdentity => m_CompletionIdentity;
        internal bool IsValid => ProducerNodeId.IsValid && CompletionIdentity != 0;

        protected void SetIdentity(
            PoseNodeId producerNodeId,
            ulong completionIdentity)
        {
            if (!producerNodeId.IsValid || completionIdentity == 0)
                throw new ArgumentException("Pose native port value identity is invalid.");
            m_ProducerNodeId = producerNodeId;
            m_CompletionIdentity = completionIdentity;
        }
    }
    internal sealed class CharacterPoseNativeLocalPoseValue : CharacterPoseNativePortValue
    {
        CharacterPoseNativePoseReadBinding m_Native;

        internal CharacterPoseNativeLocalPoseValue(
            PoseNodeId producerNodeId,
            in CharacterPoseNativePoseReadBinding native)
            : base(producerNodeId, native.CompletionIdentity)
        {
            ValidateNative(producerNodeId, in native);
            m_Native = native;
        }

        internal CharacterPoseNativeLocalPoseValue(
            PoseNodeId producerNodeId,
            AnimationPoseValue pose)
            : base(producerNodeId, pose.CompletionIdentity)
        {
            if (!pose.NodeId.IsValid || pose.Availability == AnimationPoseAvailability.Invalid)
                throw new ArgumentException("Pose native local value is invalid.");
            Pose = pose;
        }

        internal ref readonly CharacterPoseNativePoseReadBinding Native => ref m_Native;
        internal AnimationPoseValue Pose { get; private set; }

        internal static CharacterPoseNativeLocalPoseValue Reuse(
            CharacterPoseNativeLocalPoseValue value,
            PoseNodeId producerNodeId,
            in CharacterPoseNativePoseReadBinding native)
        {
            if (value == null)
                return new CharacterPoseNativeLocalPoseValue(producerNodeId, in native);
            value.Refresh(producerNodeId, in native);
            return value;
        }

        void Refresh(
            PoseNodeId producerNodeId,
            in CharacterPoseNativePoseReadBinding native)
        {
            ValidateNative(producerNodeId, in native);
            SetIdentity(producerNodeId, native.CompletionIdentity);
            m_Native = native;
            Pose = default;
        }

        static void ValidateNative(
            PoseNodeId producerNodeId,
            in CharacterPoseNativePoseReadBinding native)
        {
            if (!producerNodeId.IsValid || native.CompletionIdentity == 0)
                throw new ArgumentException("Pose native port value identity is invalid.");
            if (!native.IsValid ||
                native.Space != CharacterPoseSpace.Local ||
                native.Availability[0] == AnimationPoseAvailability.Invalid)
            {
                throw new ArgumentException(
                    "Pose native local value is invalid.",
                    nameof(native));
            }
        }
    }
}