namespace ThirdPersonCharacter.Pipeline.Presentation
{
    internal interface ICharacterFootPlacementWorldQuery :
        ICharacterFootLandingWorldQuery,
        ICharacterFootGroundPathWorldQuery,
        ICharacterFootCurrentSupportWorldQuery
    {
    }
}
