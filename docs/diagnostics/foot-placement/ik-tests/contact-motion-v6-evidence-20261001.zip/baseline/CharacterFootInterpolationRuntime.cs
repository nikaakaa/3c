using Unity.Collections;
using UnityEngine;

namespace ThirdPersonCharacter.Pipeline.Presentation
{
    internal static class CharacterFootInterpolationRuntime
    {
        internal static void RebaseOutputWeight(
            ref CharacterFootInterpolationState state,
            float previousWeight,
            float currentWeight,
            Vector3 previousAnimatedSole)
        {
            state.OutputWeightRebased = state.HasOutput &&
                previousWeight > CharacterFootConstraintMath.GeometryEpsilon &&
                currentWeight > previousWeight;
            if (!state.OutputWeightRebased)
                return;
            float ratio = previousWeight / currentWeight;
            state.EffectiveCorrection *= ratio;
            if (state.HasPreviousResponseOutputPoint)
                state.PreviousResponseOutputPoint = previousAnimatedSole +
                    (state.PreviousResponseOutputPoint - previousAnimatedSole) * ratio;
            state.SwingResidual = state.EffectiveCorrection - state.PreviousSwingTargetCorrection;
            state.Residual = state.EffectiveCorrection - state.PreviousTargetCorrection;
            state.HasPlantTarget = false;
            if (state.ResponseHistory.HasValue)
            {
                ref readonly CharacterFootCorrectionResponseHistory history =
                    ref state.ResponseHistory;
                state.ResponseHistory = new CharacterFootCorrectionResponseHistory(
                    history.Scalar * ratio, history.Domain, history.AppliedDirection);
            }
        }

        internal static CharacterFootInterpolationResult Evaluate(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateTarget target,
            in CharacterFootStateFrame frame)
        {
            UpdateCorrectionResponseLineage(ref state, in frame);
            if (target.SuppressOutput ||
                target.InterpolationPolicy ==
                CharacterFootInterpolationPolicy.Suppressed)
            {
                CharacterFootCorrectionResponseInitializationReason reason =
                    (frame.OwnershipLossReason &
                     CharacterFootGoalOwnershipLossReason
                         .SourceLineageInvalidated) != 0
                        ? CharacterFootCorrectionResponseInitializationReason
                            .SourceLineageInvalidated
                        : CharacterFootCorrectionResponseInitializationReason
                            .PolicyExited;
                reason = ResolveSuppressedInitializationReason(
                    state.PendingCorrectionResponseInitializationReason,
                    reason);
                ResetInterpolation(ref state, in frame, reason);
                return new CharacterFootInterpolationResult(
                    default,
                    false,
                    default,
                    CharacterFootPathContinuityFact.CreateUnevaluated(
                        target.TimeToLandingSeconds,
                        in frame.Settings,
                        frame.ComponentUp.normalized),
                    default,
                    default);
            }
            if (!state.HasOutput)
            {
                state.HasOutput = true;
                state.EffectiveCorrection = target.SwingCorrection;
            }
            state.Policy = target.InterpolationPolicy;
            switch (target.InterpolationPolicy)
            {
                case CharacterFootInterpolationPolicy.SwingResidual:
                    ClearPlant(ref state);
                    return EvaluateSwing(
                        ref state,
                        in target,
                        in frame,
                        true);
                case CharacterFootInterpolationPolicy.VerifiedSupport:
                    return EvaluatePlant(ref state, in target, in frame);
                case CharacterFootInterpolationPolicy.ReleaseResidual:
                    return EvaluateRelease(ref state, in target, in frame);
                default:
                    throw new System.InvalidOperationException(
                        "Foot interpolation policy is invalid.");
            }
        }

        internal static CharacterFootInterpolationResult AdvanceUnavailable(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateTarget target,
            in CharacterFootStateFrame frame)
        {
            if (target.InterpolationPolicy !=
                    CharacterFootInterpolationPolicy.SwingResidual ||
                target.SupportTargetAvailable)
            {
                throw new System.InvalidOperationException(
                    "Unavailable Foot interpolation input is invalid.");
            }
            UpdateCorrectionResponseLineage(ref state, in frame);
            if (!state.HasOutput)
            {
                state.HasOutput = true;
                state.EffectiveCorrection = target.SwingCorrection;
            }
            state.Policy = CharacterFootInterpolationPolicy.SwingResidual;
            ClearPlant(ref state);
            CharacterFootInterpolationResult result = EvaluateSwing(
                ref state,
                in target,
                in frame,
                false);
            state.EffectiveCorrection = default;
            state.PendingReleaseResponseRebase = false;
            ClearCorrectionResponse(
                ref state,
                CharacterFootCorrectionResponseInitializationReason.PolicyExited);
            return result;
        }

        internal static void ApplyPostTransition(
            ref CharacterFootInterpolationState state,
            in CharacterFootTransitionDecision transition)
        {
            if (!transition.ResetInterpolation ||
                transition.Phase !=
                CharacterFootTransitionPhase.PostInterpolation)
            {
                return;
            }
            Vector3 correction = state.EffectiveCorrection;
            CharacterFootCorrectionResponseHistory responseHistory = state.ResponseHistory;
            bool hasPreviousResponseOutputPoint =
                state.HasPreviousResponseOutputPoint;
            Vector3 previousResponseOutputPoint =
                state.PreviousResponseOutputPoint;
            CharacterFootCorrectionResponseInitializationReason reason =
                state.PendingCorrectionResponseInitializationReason;
            FixedString128Bytes sourceLineage =
                state.CorrectionResponseSourceLineage;
            FixedString128Bytes profileRevision =
                state.CorrectionResponseProfileRevision;
            ulong worldRevision = state.CorrectionResponseWorldRevision;
            bool hasLineage = state.HasCorrectionResponseLineage;
            bool pendingReleaseResponseRebase =
                transition.Reason == CharacterFootTransitionReason.ReleaseCompleted;
            state = default;
            state.HasOutput = true;
            state.EffectiveCorrection = correction;
            state.ResponseHistory = responseHistory;
            state.HasPreviousResponseOutputPoint =
                hasPreviousResponseOutputPoint;
            state.PreviousResponseOutputPoint = previousResponseOutputPoint;
            state.HasCorrectionResponseLineage = hasLineage;
            state.CorrectionResponseSourceLineage = sourceLineage;
            state.CorrectionResponseProfileRevision = profileRevision;
            state.CorrectionResponseWorldRevision = worldRevision;
            state.PendingReleaseResponseRebase = pendingReleaseResponseRebase;
            state.PendingCorrectionResponseInitializationReason = reason;
        }

        internal static void ApplyOutputCorrection(
            ref CharacterFootInterpolationState state,
            Vector3 outputCorrection)
        {
            Vector3 adjustment = outputCorrection - state.EffectiveCorrection;
            if (adjustment.sqrMagnitude == 0f)
                return;
            state.EffectiveCorrection = outputCorrection;
            if (state.Policy == CharacterFootInterpolationPolicy.ReleaseResidual)
                state.Residual += adjustment;
            if (state.HasPreviousResponseOutputPoint)
                state.PreviousResponseOutputPoint += adjustment;
            if (!state.ResponseHistory.HasValue)
                return;
            ref readonly CharacterFootCorrectionResponseHistory history =
                ref state.ResponseHistory;
            if (history.Domain == CharacterFootCorrectionResponseDomain.ContactWorldResidual)
            {
                state.PlantWorldResidual += adjustment;
                state.PlantWorldResidualTransitionActive =
                    state.PlantWorldResidual.sqrMagnitude >
                    CharacterFootConstraintMath.GeometryEpsilon *
                    CharacterFootConstraintMath.GeometryEpsilon;
            }
            else
            {
                state.ResponseHistory = new CharacterFootCorrectionResponseHistory(
                    history.Scalar + Vector3.Dot(adjustment, history.AppliedDirection),
                    history.Domain,
                    history.AppliedDirection);
            }
        }

        static CharacterFootInterpolationResult EvaluatePlant(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateTarget target,
            in CharacterFootStateFrame frame)
        {
            if (!target.PlantTargetAvailable ||
                !target.PlantTargetVerified ||
                target.PlantTargetEventIdentity == 0 ||
                (target.PlantTargetKind != CharacterFootPlantTargetKind.VerifiedAnchor &&
                 target.PlantTargetKind != CharacterFootPlantTargetKind.LockedFullAnchor &&
                 target.PlantTargetKind != CharacterFootPlantTargetKind.LockedSliding) ||
                !CharacterFootConstraintMath.Finite(target.PlantTargetPoint) ||
                !target.SupportTargetAvailable ||
                !target.SupportTarget.IsValid)
            {
                throw new System.InvalidOperationException(
                    "Foot Plant target is invalid.");
            }
            Vector3 up = frame.ComponentUp.normalized;
            Vector3 supportNormal = target.SupportTarget.SupportNormal;
            Vector3 originalSole =
                CharacterFootConstraintMath.ResolveOriginalSole(
                    frame.AnimatedFoot);
            ref readonly CharacterFootSupportIntent supportIntent = ref target.SupportIntent;
            CharacterFootInterpolationResult swing = EvaluateSwing(
                ref state,
                new CharacterFootStateTarget(
                    target.SwingCorrection,
                    target.SwingCorrection,
                    CharacterFootInterpolationPolicy.SwingResidual,
                    false,
                    0,
                    false,
                    default,
                    CharacterFootPlantTargetKind.None,
                    CharacterFootLockResponse.None,
                    false,
                    false,
                    default,
                    false,
                    false,
                    false,
                    false,
                    target.TimeToLandingSeconds,
                    in supportIntent),
                in frame,
                false);
            bool previousResponseOutputAvailable =
                state.HasPreviousResponseOutputPoint;
            ref readonly CharacterFootCorrectionResponseHistory responseHistory =
                ref state.ResponseHistory;
            Vector3 currentOutputBefore = previousResponseOutputAvailable
                ? state.PreviousResponseOutputPoint
                : originalSole + swing.Correction;
            if (state.PendingReleaseResponseRebase &&
                previousResponseOutputAvailable &&
                responseHistory.HasValue &&
                responseHistory.Domain ==
                CharacterFootCorrectionResponseDomain.AnimationRelativeScalar)
            {
                float releaseResponseScalar = responseHistory.Scalar;
                float releaseResponseStep =
                    frame.Settings.CorrectionResponseDecreaseSpeed *
                    frame.DeltaSeconds;
                float releaseResponseRebase = Mathf.Min(
                    Mathf.Abs(releaseResponseScalar),
                    releaseResponseStep * 0.5f);
                Vector3 releaseResponseRebaseVector =
                    responseHistory.AppliedDirection *
                    Mathf.Sign(releaseResponseScalar) *
                    releaseResponseRebase;
                currentOutputBefore -= releaseResponseRebaseVector;
                state.PendingReleaseResponseRebase = false;
            }
            Vector3 effectiveCorrectionBefore =
                currentOutputBefore - originalSole;
            bool hadPlantTarget = state.HasPlantTarget;
            bool sameTarget = hadPlantTarget &&
                              state.PlantTargetEventIdentity ==
                              target.PlantTargetEventIdentity;
            CharacterFootPlantTargetKind previousTargetKind =
                state.PlantTargetKind;
            CharacterFootLockResponse previousLockResponse =
                state.PlantLockResponse;
            bool previousVerified = state.PlantTargetVerified;
            bool previousDirectFollow = state.PlantDirectFollow;
            Vector3 previousDesiredPoint = state.PlantDesiredPoint;
            Vector3 previousSelectedWorldTarget =
                state.PreviousPlantSelectedWorldTarget;
            float desiredTargetHeightAlongUp = Vector3.Dot(
                target.PlantTargetPoint,
                up);
            bool hadTargetHeight = state.HasTargetHeight;
            bool matchingTargetHeight = hadTargetHeight &&
                                        state.TargetHeightEventIdentity ==
                                        target.PlantTargetEventIdentity;
            bool targetHeightInitialized = !hadTargetHeight;
            bool targetHeightEventChanged = hadTargetHeight &&
                                            !matchingTargetHeight;
            float targetHeightBefore = hadTargetHeight
                ? state.FilteredTargetHeightAlongUp
                : desiredTargetHeightAlongUp;
            float targetVerticalDelta = desiredTargetHeightAlongUp -
                                        targetHeightBefore;
            bool verificationRefresh = matchingTargetHeight &&
                                       target.PlantTargetVerified &&
                                       !previousVerified;
            bool directAdoption = frame.Settings.TargetHeightAdoptionMode ==
                                  CharacterFootTargetHeightAdoptionMode.Direct;
            bool distanceForceRefresh = matchingTargetHeight &&
                                         !directAdoption &&
                                         !target.DirectPlantFollow &&
                                         !verificationRefresh &&
                                         Mathf.Abs(targetVerticalDelta) >=
                                         frame.Settings
                                             .TargetHeightForceRefreshDistance;
            bool targetForceRefreshed = verificationRefresh ||
                                        distanceForceRefresh;
            bool targetRevisionAdmitted =
                Mathf.Abs(targetVerticalDelta) >
                frame.Settings.PathRevisionDistance;
            float maximumTargetDelta =
                frame.Settings.MaximumVerticalTargetSpeed *
                frame.DeltaSeconds;
            float targetAppliedVerticalDelta = targetHeightInitialized ||
                                               targetHeightEventChanged ||
                                               directAdoption ||
                                               target.DirectPlantFollow ||
                                               targetForceRefreshed
                ? targetVerticalDelta
                : targetRevisionAdmitted
                    ? Mathf.Clamp(
                        targetVerticalDelta,
                        -maximumTargetDelta,
                        maximumTargetDelta)
                    : 0f;
            bool targetVerticalClamped = targetRevisionAdmitted &&
                                         !targetHeightInitialized &&
                                         !targetHeightEventChanged &&
                                         !directAdoption &&
                                         !target.DirectPlantFollow &&
                                         !targetForceRefreshed &&
                                         !Mathf.Approximately(
                                             targetVerticalDelta,
                                             targetAppliedVerticalDelta);
            state.HasTargetHeight = true;
            state.TargetHeightEventIdentity = target.PlantTargetEventIdentity;
            state.FilteredTargetHeightAlongUp =
                targetHeightBefore + targetAppliedVerticalDelta;
            state.TargetHeightRetargetActive = false;
            CharacterFootPlantTargetHeightUpdateReason targetHeightUpdateReason;
            if (targetHeightInitialized)
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.Initialized;
            }
            else if (targetHeightEventChanged)
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.EventChanged;
            }
            else if (verificationRefresh)
            {
                targetHeightUpdateReason = CharacterFootPlantTargetHeightUpdateReason
                    .VerificationRefresh;
            }
            else if (targetVerticalDelta == 0f)
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.None;
            }
            else if (target.DirectPlantFollow)
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.DirectFollow;
            }
            else if (directAdoption)
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.DirectAdoption;
            }
            else if (distanceForceRefresh)
            {
                targetHeightUpdateReason = CharacterFootPlantTargetHeightUpdateReason
                    .ForceRefreshDistanceExceeded;
            }
            else if (!targetRevisionAdmitted)
            {
                targetHeightUpdateReason = CharacterFootPlantTargetHeightUpdateReason
                    .HeldWithinRevisionDistance;
            }
            else if (targetVerticalClamped)
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.RateLimited;
            }
            else
            {
                targetHeightUpdateReason =
                    CharacterFootPlantTargetHeightUpdateReason.WithinRate;
            }
            state.PlantFilteredPoint = Vector3.ProjectOnPlane(
                target.PlantTargetPoint,
                up) + up * state.FilteredTargetHeightAlongUp;
            Vector3 selectedWorldTarget = state.PlantFilteredPoint;
            bool targetRevised = sameTarget &&
                                  !target.DirectPlantFollow &&
                                 Vector3.Distance(
                                     previousDesiredPoint,
                                      target.PlantTargetPoint) >
                                  frame.Settings.LandingAcceptanceDistance;
            CharacterFootPlantResidualCaptureReason captureReason =
                CharacterFootPlantResidualCaptureReason.None;
            if (!sameTarget)
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .TargetEventChanged;
            if (hadPlantTarget && previousTargetKind != target.PlantTargetKind)
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .TargetKindChanged;
            if (hadPlantTarget &&
                previousLockResponse != target.PlantLockResponse)
            {
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .LockResponseChanged;
            }
            if (hadPlantTarget && previousVerified != target.PlantTargetVerified)
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .VerificationChanged;
            if (hadPlantTarget &&
                previousDirectFollow != target.DirectPlantFollow)
            {
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .DirectFollowChanged;
            }
            if (target.StateEntered)
                captureReason |=
                    CharacterFootPlantResidualCaptureReason.StateEntered;
            if (target.ResponseEntered)
                captureReason |=
                    CharacterFootPlantResidualCaptureReason.ResponseEntered;
            if (targetRevised)
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .TargetPointRevised;
            if (targetForceRefreshed)
                captureReason |= CharacterFootPlantResidualCaptureReason
                    .TargetHeightForceRefreshed;
            Vector3 residualBeforeCapture = state.PlantWorldResidual;
            bool captureTransition = captureReason !=
                                     CharacterFootPlantResidualCaptureReason.None;
            Vector3 continuityOutputBefore = currentOutputBefore;
            if (captureTransition)
            {
                state.PlantWorldResidual =
                    continuityOutputBefore - selectedWorldTarget;
            }
            else if (target.DirectPlantFollow)
            {
                state.PlantWorldResidual += up * Vector3.Dot(
                    previousSelectedWorldTarget - selectedWorldTarget, up);
            }
            state.PlantWorldResidualTransitionActive =
                state.PlantWorldResidual.sqrMagnitude >
                CharacterFootConstraintMath.GeometryEpsilon *
                CharacterFootConstraintMath.GeometryEpsilon;
            Vector3 residualCapturedBeforeDecay = state.PlantWorldResidual;
            bool residualDecayApplied = false;
            float residualBaseHalfLifeSeconds =
                frame.Settings.EffectiveCorrectionHalfLifeSeconds;
            bool residualDeadlineHalfLifeAvailable = false;
            float residualDeadlineHalfLifeSeconds = 0f;
            float residualAppliedHalfLifeSeconds = 0f;
            bool residualClearedAtZeroTolerance = false;
            if (state.PlantWorldResidualTransitionActive &&
                frame.DeltaSeconds > 0f)
            {
                residualAppliedHalfLifeSeconds = ResolveSwingResidualHalfLife(
                    state.PlantWorldResidual,
                    target.TimeToLandingSeconds,
                    in frame.Settings,
                    out residualDeadlineHalfLifeAvailable,
                    out residualDeadlineHalfLifeSeconds);
                residualDecayApplied = true;
                state.PlantWorldResidual = Advance(
                    state.PlantWorldResidual,
                    default,
                    frame.DeltaSeconds,
                    residualAppliedHalfLifeSeconds);
                if (state.PlantWorldResidual.sqrMagnitude <=
                    CharacterFootConstraintMath.GeometryEpsilon *
                    CharacterFootConstraintMath.GeometryEpsilon)
                {
                    state.PlantWorldResidual = default;
                    state.PlantWorldResidualTransitionActive = false;
                    residualClearedAtZeroTolerance = true;
                }
            }
            Vector3 residualAfterDecay = state.PlantWorldResidual;
            Vector3 desiredOutputPoint =
                selectedWorldTarget + residualAfterDecay;
            CharacterFootCorrectionResponseResult response = ApplyCorrectionResponse(
                ref state,
                desiredOutputPoint,
                supportNormal,
                CharacterFootCorrectionResponseDomain.ContactWorldResidual,
                captureTransition,
                in frame);
            Vector3 responseOutputPoint = response.OutputPoint;
            ref readonly CharacterFootCorrectionResponseFact correctionResponseFact =
                ref response.Fact;
            state.EffectiveCorrection = responseOutputPoint - originalSole;
            CharacterFootVerticalContinuityOwner verticalContinuityOwners =
                CharacterFootVerticalContinuityOwner.PlantTarget;
            if (targetHeightUpdateReason !=
                    CharacterFootPlantTargetHeightUpdateReason.None ||
                targetVerticalClamped || targetForceRefreshed)
            {
                verticalContinuityOwners |=
                    CharacterFootVerticalContinuityOwner.TargetHeightHistory;
            }
            if (captureTransition ||
                residualCapturedBeforeDecay.sqrMagnitude >
                CharacterFootConstraintMath.GeometryEpsilon *
                CharacterFootConstraintMath.GeometryEpsilon ||
                residualAfterDecay.sqrMagnitude >
                CharacterFootConstraintMath.GeometryEpsilon *
                CharacterFootConstraintMath.GeometryEpsilon)
            {
                verticalContinuityOwners |=
                    CharacterFootVerticalContinuityOwner.PlantWorldResidual;
            }
            state.HasPlantTarget = true;
            state.PlantTargetEventIdentity = target.PlantTargetEventIdentity;
            state.PlantTargetKind = target.PlantTargetKind;
            state.PlantLockResponse = target.PlantLockResponse;
            state.PlantTargetVerified = target.PlantTargetVerified;
            state.PlantDirectFollow = target.DirectPlantFollow;
            state.PlantDesiredPoint = target.PlantTargetPoint;
            state.PreviousPlantSelectedWorldTarget = selectedWorldTarget;
            state.SelectedSupportTarget = target.SupportTarget.WithSupportNormal(
                response.AppliedDirection);
            state.PreviousTargetCorrection = selectedWorldTarget - originalSole;
            state.Progress = 1f;
            state.StartResidual = 0f;
            float outputDistance = Vector3.Distance(
                responseOutputPoint,
                target.PlantTargetPoint);
            float penetrationDepth = Mathf.Max(
                0f,
                Vector3.Dot(
                    target.PlantTargetPoint - responseOutputPoint,
                    up));
            state.Completed = target.PlantTargetVerified &&
                              target.LockWeightCompleted &&
                              frame.LockRequest.RequestsLock &&
                              frame.LockRequest.EventIdentity ==
                              target.PlantTargetEventIdentity &&
                              outputDistance <=
                              frame.Settings.LandingLockCompletionTolerance &&
                              penetrationDepth <=
                              frame.Settings.GroundPenetrationTolerance;
            var plantFact = new CharacterFootPlantInterpolationFact(
                true,
                target.PlantTargetEventIdentity,
                target.PlantTargetVerified,
                target.PlantTargetKind,
                target.PlantLockResponse,
                target.PlantTargetPoint,
                state.PlantFilteredPoint,
                frame.Settings.TargetHeightAdoptionMode,
                frame.Settings.MaximumVerticalTargetSpeed,
                targetHeightBefore,
                desiredTargetHeightAlongUp,
                targetVerticalDelta,
                targetAppliedVerticalDelta,
                state.FilteredTargetHeightAlongUp,
                state.TargetHeightEventIdentity,
                targetHeightUpdateReason,
                targetForceRefreshed,
                frame.Settings.TargetHeightForceRefreshDistance,
                targetVerticalClamped,
                previousSelectedWorldTarget,
                selectedWorldTarget,
                captureReason,
                residualBeforeCapture,
                residualCapturedBeforeDecay,
                residualDecayApplied,
                residualBaseHalfLifeSeconds,
                residualDeadlineHalfLifeAvailable,
                residualDeadlineHalfLifeSeconds,
                residualAppliedHalfLifeSeconds,
                residualAfterDecay,
                CharacterFootConstraintMath.GeometryEpsilon,
                residualClearedAtZeroTolerance,
                verticalContinuityOwners,
                effectiveCorrectionBefore,
                state.EffectiveCorrection,
                outputDistance,
                penetrationDepth);
            return Result(
                in state,
                state.Completed,
                swing.ContinuityFact,
                in plantFact,
                in correctionResponseFact);
        }

        static CharacterFootInterpolationResult EvaluateRelease(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateTarget target,
            in CharacterFootStateFrame frame)
        {
            state.SelectedSupportTarget = target.SupportTargetAvailable
                ? target.SupportTarget
                : default;
            Vector3 originalSole =
                CharacterFootConstraintMath.ResolveOriginalSole(
                    frame.AnimatedFoot);
            if (target.StateEntered || state.OutputWeightRebased)
            {
                if (state.HasPreviousResponseOutputPoint)
                {
                    state.EffectiveCorrection =
                        state.PreviousResponseOutputPoint - originalSole;
                }
                state.PreviousTargetCorrection = target.Correction;
                state.Residual =
                    state.EffectiveCorrection - target.Correction;
                state.StartResidual = state.Residual.magnitude;
                state.Progress = 0f;
            }
            else
            {
                state.Residual +=
                    state.PreviousTargetCorrection - target.Correction;
            }
            state.PreviousTargetCorrection = target.Correction;
            state.Residual = Advance(
                state.Residual,
                default,
                frame.DeltaSeconds,
                frame.Settings.EffectiveCorrectionHalfLifeSeconds);
            Vector3 desiredCorrection = target.Correction + state.Residual;
            CharacterFootCorrectionResponseResult response = ApplyCorrectionResponse(
                ref state,
                originalSole + desiredCorrection,
                target.SupportTarget.SupportNormal,
                CharacterFootCorrectionResponseDomain.AnimationRelativeScalar,
                target.StateEntered,
                in frame);
            Vector3 releaseOutputPoint = response.OutputPoint;
            ref readonly CharacterFootCorrectionResponseFact correctionResponseFact =
                ref response.Fact;
            state.SelectedSupportTarget = target.SupportTarget.WithSupportNormal(
                response.AppliedDirection);
            state.EffectiveCorrection = releaseOutputPoint - originalSole;
            state.Completed = frame.LockRequest.Weight <=
                              CharacterFootConstraintMath.GeometryEpsilon &&
                              Vector3.Distance(
                                  state.EffectiveCorrection,
                                  target.Correction) <=
                              frame.Settings.ReleaseCompletionTolerance;
            return Result(
                in state,
                state.Completed,
                Unevaluated(in target, in frame),
                default,
                in correctionResponseFact);
        }

        static CharacterFootInterpolationResult EvaluateSwing(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateTarget target,
            in CharacterFootStateFrame frame,
            bool applyCorrectionResponse)
        {
            state.SelectedSupportTarget = target.SupportTargetAvailable
                ? target.SupportTarget
                : default;
            bool pathAvailableBefore = state.HasSwingPath;
            ulong previousLandingEventIdentity =
                state.SwingLandingEventIdentity;
            ulong previousGroundPathInputIdentity =
                state.SwingGroundPathInputIdentity;
            Vector3 previousLandingPoint = state.SwingLandingPoint;
            Vector3 previousTargetCorrection =
                state.PreviousSwingTargetCorrection;
            Vector3 residualBeforeRevision = state.SwingResidual;
            ref readonly CharacterFootSwingMotionResult swing = ref frame.SwingMotion;
            ref readonly CharacterFootSwingPathReference swingPath =
                ref swing.SwingPathReference;
            bool hasPath = target.SupportTarget.Kind ==
                           CharacterFootSupportTargetKind.SwingGround &&
                           swing.Accepted &&
                           swingPath.IsAvailable &&
                           swingPath.LandingEventIdentity ==
                           swing.LandingEventIdentity;
            bool comparablePath = pathAvailableBefore && hasPath;
            Vector3 up = frame.ComponentUp.normalized;
            Vector3 originalSole =
                CharacterFootConstraintMath.ResolveOriginalSole(
                    frame.AnimatedFoot);
            float originalSoleHeight = Vector3.Dot(originalSole, up);
            float rawTargetHeightAlongUp = hasPath
                ? swing.FormalTargetHeightAlongUp
                : 0f;
            float currentLandingHeightAlongUp = hasPath
                ? Vector3.Dot(swingPath.LandingPoint, up)
                : 0f;
            float rawTargetCorrectionAlongUp = hasPath
                ? rawTargetHeightAlongUp - originalSoleHeight
                : 0f;
            float landingPointDelta = comparablePath
                ? Vector3.Distance(
                    previousLandingPoint,
                    swingPath.LandingPoint)
                : 0f;
            float landingHeightDelta = comparablePath
                ? Mathf.Abs(Vector3.Dot(
                    swingPath.LandingPoint - previousLandingPoint,
                    up))
                : 0f;
            float landingHeightChange = comparablePath
                ? Vector3.Dot(
                    swingPath.LandingPoint - previousLandingPoint,
                    up)
                : 0f;
            bool sameEvent = comparablePath &&
                             previousLandingEventIdentity ==
                             swing.LandingEventIdentity;
            bool groundPathInputChanged = sameEvent &&
                                          previousGroundPathInputIdentity !=
                                          swing.GroundPathInputIdentity;
            bool sameHeightTarget = hasPath &&
                                    state.HasTargetHeight &&
                                    state.TargetHeightEventIdentity ==
                                    swing.LandingEventIdentity;
            float filteredTargetHeightBefore =
                state.FilteredTargetHeightAlongUp;
            bool targetCorrectionRateLimited = false;
            bool targetCorrectionClamped = false;
            bool targetHeightForceRefreshed = false;
            bool targetHeightUpdateHeld = hasPath &&
                                          state.Policy !=
                                          CharacterFootInterpolationPolicy
                                              .SwingResidual;
            bool ownsSwingTargetHeight = state.Policy ==
                                         CharacterFootInterpolationPolicy
                                             .SwingResidual;
            bool directTargetHeightAdoption =
                frame.Settings.TargetHeightAdoptionMode ==
                CharacterFootTargetHeightAdoptionMode.Direct;
            if (hasPath && ownsSwingTargetHeight && !sameHeightTarget)
            {
                state.HasTargetHeight = true;
                state.TargetHeightEventIdentity =
                    swing.LandingEventIdentity;
                state.FilteredTargetHeightAlongUp =
                    currentLandingHeightAlongUp;
                state.TargetHeightRetargetActive = false;
            }
            if (hasPath && ownsSwingTargetHeight)
            {
                filteredTargetHeightBefore = rawTargetHeightAlongUp +
                                             state
                                                 .FilteredTargetHeightAlongUp -
                                             currentLandingHeightAlongUp;
            }
            else if (hasPath)
            {
                filteredTargetHeightBefore = rawTargetHeightAlongUp;
            }
            if (hasPath && ownsSwingTargetHeight)
            {
                float targetHeightDelta = currentLandingHeightAlongUp -
                                          state.FilteredTargetHeightAlongUp;
                if (directTargetHeightAdoption)
                {
                    state.FilteredTargetHeightAlongUp =
                        currentLandingHeightAlongUp;
                    state.TargetHeightRetargetActive = false;
                }
                else
                {
                    bool retargetRequested = groundPathInputChanged &&
                                             landingHeightDelta >
                                             frame.Settings.PathRevisionDistance;
                    if (retargetRequested &&
                        Mathf.Abs(targetHeightDelta) >=
                        frame.Settings.TargetHeightForceRefreshDistance)
                    {
                        state.FilteredTargetHeightAlongUp =
                            currentLandingHeightAlongUp;
                        state.TargetHeightRetargetActive = false;
                        targetHeightForceRefreshed = true;
                    }
                    else if (retargetRequested)
                    {
                        state.TargetHeightRetargetActive = true;
                    }
                    float maximumHeightDelta = ResolveVerticalHistoryDelta(
                        frame.DeltaSeconds,
                        frame.Settings.MaximumVerticalTargetSpeed);
                    if (state.TargetHeightRetargetActive)
                    {
                        targetCorrectionRateLimited = true;
                        float appliedHeightDelta = Mathf.Clamp(
                            targetHeightDelta,
                            -maximumHeightDelta,
                            maximumHeightDelta);
                        targetCorrectionClamped = !Mathf.Approximately(
                            targetHeightDelta,
                            appliedHeightDelta);
                        state.FilteredTargetHeightAlongUp += appliedHeightDelta;
                        if (Mathf.Approximately(
                                targetHeightDelta,
                                appliedHeightDelta))
                        {
                            state.TargetHeightRetargetActive = false;
                        }
                    }
                }
            }
            else if (ownsSwingTargetHeight)
            {
                state.HasTargetHeight = false;
                state.TargetHeightEventIdentity = 0;
                state.FilteredTargetHeightAlongUp = 0f;
                state.TargetHeightRetargetActive = false;
            }
            float filteredTargetHeightAlongUp = hasPath
                ? ownsSwingTargetHeight
                    ? rawTargetHeightAlongUp +
                      state.FilteredTargetHeightAlongUp -
                      currentLandingHeightAlongUp
                    : rawTargetHeightAlongUp
                : 0f;
            Vector3 swingTargetCorrection = hasPath
                ? up * (filteredTargetHeightAlongUp - originalSoleHeight)
                : target.Correction;
            float targetDelta = comparablePath
                ? Vector3.Distance(
                    previousTargetCorrection,
                    up * rawTargetCorrectionAlongUp)
                : 0f;
            CharacterFootPathRevisionReason revisionReason =
                CharacterFootPathRevisionReason.None;
            if (hasPath != pathAvailableBefore)
            {
                revisionReason |=
                    CharacterFootPathRevisionReason.PathAvailabilityChanged;
            }
            if (comparablePath &&
                previousLandingEventIdentity != swing.LandingEventIdentity)
            {
                revisionReason |=
                    CharacterFootPathRevisionReason.LandingEventChanged;
            }
            if (comparablePath &&
                landingPointDelta > frame.Settings.PathRevisionDistance)
            {
                revisionReason |=
                    CharacterFootPathRevisionReason.LandingPointChanged;
            }
            bool revised = revisionReason !=
                           CharacterFootPathRevisionReason.None;
            bool targetTrackingApplied = groundPathInputChanged &&
                targetDelta > frame.Settings.PathRevisionDistance;
            bool lateDownwardLandingRevision =
                groundPathInputChanged &&
                (revisionReason & CharacterFootPathRevisionReason
                    .LandingPointChanged) != 0 &&
                landingHeightChange < -frame.Settings.PathRevisionDistance &&
                target.TimeToLandingSeconds >= 0f &&
                target.TimeToLandingSeconds <=
                frame.DeltaSeconds * 2f +
                CharacterFootConstraintMath.GeometryEpsilon;
            if (lateDownwardLandingRevision)
            {
                state.SwingResidual = default;
            }
            else if (revised || targetTrackingApplied || state.OutputWeightRebased)
            {
                state.SwingResidual =
                    state.EffectiveCorrection - swingTargetCorrection;
            }
            Vector3 residualBeforeDecay = state.SwingResidual;
            state.HasSwingPath = hasPath;
            state.SwingLandingEventIdentity = hasPath
                ? swing.LandingEventIdentity
                : 0;
            state.SwingGroundPathInputIdentity = hasPath
                ? swing.GroundPathInputIdentity
                : 0;
            state.SwingLandingPoint = hasPath
                ? swingPath.LandingPoint
                : default;
            state.PreviousTargetCorrection = swingTargetCorrection;
            state.PreviousSwingTargetCorrection = swingTargetCorrection;
            float halfLifeSeconds = ResolveSwingResidualHalfLife(
                state.SwingResidual,
                target.TimeToLandingSeconds,
                in frame.Settings,
                out bool deadlineHalfLifeAvailable,
                out float deadlineHalfLifeSeconds);
            state.SwingResidual = Advance(
                state.SwingResidual,
                default,
                frame.DeltaSeconds,
                halfLifeSeconds);
            Vector3 swingCorrection =
                swingTargetCorrection + state.SwingResidual;
            CharacterFootCorrectionResponseFact correctionResponseFact = default;
            if (applyCorrectionResponse)
            {
                CharacterFootCorrectionResponseResult response = ApplyCorrectionResponse(
                    ref state,
                    originalSole + swingCorrection,
                    target.SupportTarget.SupportNormal,
                    CharacterFootCorrectionResponseDomain.AnimationRelativeScalar,
                    false,
                    in frame);
                Vector3 responseOutputPoint = response.OutputPoint;
                correctionResponseFact = response.Fact;
                state.SelectedSupportTarget =
                    target.SupportTarget.WithSupportNormal(
                        response.AppliedDirection);
                state.EffectiveCorrection = responseOutputPoint - originalSole;
                state.Residual = state.SwingResidual;
                state.PendingReleaseResponseRebase = false;
            }
            state.Progress = 0f;
            state.StartResidual = 0f;
            state.Completed = false;
            var continuityFact = new CharacterFootPathContinuityFact(
                true,
                revisionReason,
                revised,
                targetTrackingApplied,
                pathAvailableBefore,
                hasPath,
                previousLandingEventIdentity,
                hasPath ? swing.LandingEventIdentity : 0,
                previousTargetCorrection,
                swingTargetCorrection,
                landingPointDelta,
                targetDelta,
                residualBeforeRevision,
                residualBeforeDecay,
                state.SwingResidual,
                frame.Settings.LandingAcceptanceDistance,
                frame.Settings.PathRevisionDistance,
                frame.Settings.SwingResidualTolerance,
                target.TimeToLandingSeconds,
                frame.Settings.EffectiveCorrectionHalfLifeSeconds,
                deadlineHalfLifeAvailable,
                deadlineHalfLifeSeconds,
                halfLifeSeconds,
                hasPath ? rawTargetHeightAlongUp : 0f,
                hasPath ? filteredTargetHeightBefore : 0f,
                hasPath
                    ? rawTargetHeightAlongUp - filteredTargetHeightBefore
                    : 0f,
                hasPath
                    ? filteredTargetHeightAlongUp -
                      filteredTargetHeightBefore
                    : 0f,
                hasPath && targetHeightUpdateHeld,
                hasPath && targetHeightForceRefreshed,
                hasPath && targetCorrectionRateLimited,
                hasPath && targetCorrectionClamped,
                frame.Settings.TargetHeightForceRefreshDistance,
                frame.Settings.MaximumVerticalTargetSpeed,
                frame.Settings.TargetHeightAdoptionMode,
                hasPath
                    ? filteredTargetHeightAlongUp
                    : 0f,
                up);
            return new CharacterFootInterpolationResult(
                state.Policy == CharacterFootInterpolationPolicy.SwingResidual
                    ? state.EffectiveCorrection
                    : swingCorrection,
                false,
                in state.SelectedSupportTarget,
                in continuityFact,
                default,
                in correctionResponseFact);
        }

        static CharacterFootInterpolationResult Result(
            in CharacterFootInterpolationState state,
            bool completed,
            in CharacterFootPathContinuityFact continuityFact,
            in CharacterFootPlantInterpolationFact plantFact,
            in CharacterFootCorrectionResponseFact correctionResponseFact) =>
            new CharacterFootInterpolationResult(
                state.EffectiveCorrection,
                completed,
                in state.SelectedSupportTarget,
                in continuityFact,
                in plantFact,
                in correctionResponseFact);

        static CharacterFootPathContinuityFact Unevaluated(
            in CharacterFootStateTarget target,
            in CharacterFootStateFrame frame) =>
            CharacterFootPathContinuityFact.CreateUnevaluated(
                target.TimeToLandingSeconds,
                in frame.Settings,
                frame.ComponentUp.normalized);

        static CharacterFootCorrectionResponseResult ApplyCorrectionResponse(
            ref CharacterFootInterpolationState state,
            Vector3 desiredOutputPoint,
            Vector3 responseDirection,
            CharacterFootCorrectionResponseDomain domain,
            bool targetContinuityCaptured,
            in CharacterFootStateFrame frame)
        {
            if ((domain != CharacterFootCorrectionResponseDomain.AnimationRelativeScalar &&
                 domain != CharacterFootCorrectionResponseDomain.ContactWorldResidual) ||
                !CharacterFootConstraintMath.Finite(desiredOutputPoint) ||
                !CharacterFootConstraintMath.Finite(responseDirection) ||
                responseDirection.sqrMagnitude <=
                CharacterFootConstraintMath.GeometryEpsilon *
                CharacterFootConstraintMath.GeometryEpsilon)
            {
                throw new System.InvalidOperationException(
                    "Foot Correction Response input is invalid.");
            }
            Vector3 requestedDirection = responseDirection.normalized;
            Vector3 originalSole =
                CharacterFootConstraintMath.ResolveOriginalSole(
                    frame.AnimatedFoot);
            bool previousOutputAvailable = state.HasPreviousResponseOutputPoint;
            Vector3 previousOutputPoint = state.HasPreviousResponseOutputPoint
                ? state.PreviousResponseOutputPoint
                : desiredOutputPoint;
            float desiredResponse = Vector3.Dot(
                desiredOutputPoint - originalSole,
                requestedDirection);
            bool initializedBefore = state.ResponseHistory.HasValue;
            bool initializedThisFrame = !initializedBefore;
            ref readonly CharacterFootCorrectionResponseHistory responseHistory =
                ref state.ResponseHistory;
            CharacterFootCorrectionResponseDomain previousDomain =
                initializedBefore
                    ? responseHistory.Domain
                    : CharacterFootCorrectionResponseDomain.None;
            if (initializedBefore && previousDomain ==
                CharacterFootCorrectionResponseDomain.None)
            {
                throw new System.InvalidOperationException(
                    "Foot Correction Response history has no coordinate domain.");
            }
            bool domainTransferred = initializedBefore && previousDomain != domain;
            bool contactWorldResidual = domain ==
                CharacterFootCorrectionResponseDomain.ContactWorldResidual;
            bool exitingContact = domainTransferred && !contactWorldResidual;
            if (exitingContact && (!targetContinuityCaptured ||
                                   !state.HasPreviousResponseOutputPoint))
            {
                throw new System.InvalidOperationException(
                    "Contact response exit has no complete target residual capture.");
            }
            CharacterFootCorrectionResponseInitializationReason reason =
                CharacterFootCorrectionResponseInitializationReason.None;
            Vector3 previousResponseDirection =
                responseHistory.HasValue
                    ? responseHistory.AppliedDirection
                    : requestedDirection;
            float maximumDirectionChangeDegrees = frame.Settings
                .CorrectionResponseMaximumDirectionChangeDegrees;
            float requestedDirectionChangeDegrees = initializedBefore
                ? Vector3.Angle(
                    previousResponseDirection,
                    requestedDirection)
                : 0f;
            bool directionLimited = initializedBefore &&
                                    requestedDirectionChangeDegrees >
                                    maximumDirectionChangeDegrees;
            Vector3 direction = directionLimited
                ? Vector3.RotateTowards(
                    previousResponseDirection,
                    requestedDirection,
                    maximumDirectionChangeDegrees * Mathf.Deg2Rad,
                    0f).normalized
                : requestedDirection;
            float appliedDirectionChangeDegrees = initializedBefore
                ? Vector3.Angle(previousResponseDirection, direction)
                : 0f;
            desiredResponse = Vector3.Dot(
                desiredOutputPoint - originalSole,
                direction);
            float responseBeforeRebase = contactWorldResidual || exitingContact
                ? 0f
                : initializedBefore
                    ? responseHistory.Scalar
                    : desiredResponse;
            float previousResponse = contactWorldResidual
                ? 0f
                : exitingContact
                    ? desiredResponse
                    : responseBeforeRebase;
            float currentResponse = previousResponse;
            CharacterFootCorrectionResponseDeltaDirection deltaDirection =
            CharacterFootCorrectionResponseDeltaDirection.None;
            float selectedSpeed = 0f;
            float appliedDelta = 0f;
            if (initializedThisFrame)
            {
                reason = state.PendingCorrectionResponseInitializationReason !=
                         CharacterFootCorrectionResponseInitializationReason.None
                    ? state.PendingCorrectionResponseInitializationReason
                    : CharacterFootCorrectionResponseInitializationReason
                        .FirstLegalInput;
            }
            if (contactWorldResidual)
            {
                desiredResponse = 0f;
            }
            else if (!initializedThisFrame && !exitingContact)
            {
                float delta = desiredResponse - previousResponse;
                if (delta != 0f)
                {
                    deltaDirection = delta > 0f
                        ? CharacterFootCorrectionResponseDeltaDirection.Increase
                        : CharacterFootCorrectionResponseDeltaDirection.Decrease;
                    selectedSpeed = delta > 0f
                        ? frame.Settings.CorrectionResponseIncreaseSpeed
                        : frame.Settings.CorrectionResponseDecreaseSpeed;
                    float maximumDelta = selectedSpeed * frame.DeltaSeconds;
                    appliedDelta = Mathf.Clamp(
                        delta,
                        -maximumDelta,
                        maximumDelta);
                    currentResponse = previousResponse + appliedDelta;
                }
            }
            Vector3 responseOutputPoint = contactWorldResidual
                ? desiredOutputPoint
                : desiredOutputPoint + direction *
                  (currentResponse - desiredResponse);
            var fact = new CharacterFootCorrectionResponseFact(
                true,
                initializedBefore,
                initializedThisFrame,
                reason,
                previousOutputAvailable,
                previousOutputPoint,
                desiredOutputPoint,
                responseOutputPoint,
                desiredResponse,
                requestedDirection,
                previousResponseDirection,
                directionLimited,
                maximumDirectionChangeDegrees,
                appliedDirectionChangeDegrees,
                state.OutputWeightRebased,
                responseBeforeRebase,
                previousResponse,
                currentResponse,
                direction,
                deltaDirection,
                selectedSpeed,
                appliedDelta,
                domain,
                previousDomain,
                domainTransferred);
            state.ResponseHistory = new CharacterFootCorrectionResponseHistory(
                currentResponse, domain, direction);
            state.HasPreviousResponseOutputPoint = true;
            state.PreviousResponseOutputPoint = responseOutputPoint;
            state.PendingCorrectionResponseInitializationReason =
                CharacterFootCorrectionResponseInitializationReason.None;
            return new CharacterFootCorrectionResponseResult(
                responseOutputPoint, direction, in fact);
        }

        static void ClearPlant(ref CharacterFootInterpolationState state)
        {
            state.HasPlantTarget = false;
            state.PlantTargetEventIdentity = 0;
            state.PlantTargetKind = CharacterFootPlantTargetKind.None;
            state.PlantLockResponse = CharacterFootLockResponse.None;
            state.PlantTargetVerified = false;
            state.PlantDirectFollow = false;
            state.PlantDesiredPoint = default;
            state.PlantFilteredPoint = default;
            state.PreviousPlantSelectedWorldTarget = default;
            state.PlantWorldResidual = default;
            state.PlantWorldResidualTransitionActive = false;
        }

        static void UpdateCorrectionResponseLineage(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateFrame frame)
        {
            if (!state.HasCorrectionResponseLineage)
            {
                SetCorrectionResponseLineage(ref state, in frame);
                return;
            }
            CharacterFootCorrectionResponseInitializationReason reason =
                CharacterFootCorrectionResponseInitializationReason.None;
            if (!state.CorrectionResponseSourceLineage.Equals(
                    frame.SourceLineage))
            {
                reason = CharacterFootCorrectionResponseInitializationReason
                    .SourceLineageInvalidated;
            }
            else if (!state.CorrectionResponseProfileRevision.Equals(
                         frame.ProfileRevision))
            {
                reason = CharacterFootCorrectionResponseInitializationReason
                    .ProfileLineageInvalidated;
            }
            else if (state.CorrectionResponseWorldRevision !=
                     frame.WorldRevision)
            {
                reason = CharacterFootCorrectionResponseInitializationReason
                    .WorldLineageInvalidated;
            }
            if (reason ==
                CharacterFootCorrectionResponseInitializationReason.None)
            {
                return;
            }
            ClearCorrectionResponse(ref state, reason);
            SetCorrectionResponseLineage(ref state, in frame);
        }

        static void SetCorrectionResponseLineage(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateFrame frame)
        {
            state.HasCorrectionResponseLineage = true;
            state.CorrectionResponseSourceLineage = frame.SourceLineage;
            state.CorrectionResponseProfileRevision = frame.ProfileRevision;
            state.CorrectionResponseWorldRevision = frame.WorldRevision;
        }

        static void ClearCorrectionResponse(
            ref CharacterFootInterpolationState state,
            CharacterFootCorrectionResponseInitializationReason reason)
        {
            state.ResponseHistory = default;
            state.HasPreviousResponseOutputPoint = false;
            state.PreviousResponseOutputPoint = default;
            state.PendingCorrectionResponseInitializationReason = reason;
        }

        static void ResetInterpolation(
            ref CharacterFootInterpolationState state,
            in CharacterFootStateFrame frame,
            CharacterFootCorrectionResponseInitializationReason reason)
        {
            state = default;
            SetCorrectionResponseLineage(ref state, in frame);
            state.PendingCorrectionResponseInitializationReason = reason;
        }

        static CharacterFootCorrectionResponseInitializationReason
            ResolveSuppressedInitializationReason(
                CharacterFootCorrectionResponseInitializationReason pending,
                CharacterFootCorrectionResponseInitializationReason current)
        {
            if (pending !=
                    CharacterFootCorrectionResponseInitializationReason.None &&
                pending != CharacterFootCorrectionResponseInitializationReason
                    .FirstLegalInput &&
                pending != CharacterFootCorrectionResponseInitializationReason
                    .PolicyExited)
            {
                return pending;
            }
            if (current == CharacterFootCorrectionResponseInitializationReason
                    .SourceLineageInvalidated)
            {
                return current;
            }
            return pending !=
                   CharacterFootCorrectionResponseInitializationReason.None
                ? pending
                : current;
        }

        static Vector3 Advance(
            Vector3 current,
            Vector3 target,
            float deltaSeconds,
            float halfLifeSeconds)
        {
            if (deltaSeconds <= 0f)
                return current;
            float alpha = 1f -
                          Mathf.Pow(0.5f, deltaSeconds / halfLifeSeconds);
            return Vector3.LerpUnclamped(current, target, alpha);
        }

        static float ResolveSwingResidualHalfLife(
            Vector3 residual,
            float timeToLandingSeconds,
            in CharacterFootMotionSettings settings,
            out bool deadlineHalfLifeAvailable,
            out float deadlineHalfLifeSeconds)
        {
            deadlineHalfLifeAvailable = false;
            deadlineHalfLifeSeconds = 0f;
            float halfLifeSeconds =
                settings.EffectiveCorrectionHalfLifeSeconds;
            float residualDistance = residual.magnitude;
            if (!float.IsFinite(residualDistance) ||
                residualDistance <= settings.SwingResidualTolerance ||
                !float.IsFinite(timeToLandingSeconds) ||
                timeToLandingSeconds <= 0f)
            {
                return halfLifeSeconds;
            }
            float halfLifeCount = Mathf.Log(
                residualDistance / settings.SwingResidualTolerance,
                2f);
            if (!float.IsFinite(halfLifeCount) || halfLifeCount <= 0f)
                return halfLifeSeconds;
            float candidate = timeToLandingSeconds / halfLifeCount;
            if (!float.IsFinite(candidate) || candidate <= 0f)
                return halfLifeSeconds;
            deadlineHalfLifeAvailable = true;
            deadlineHalfLifeSeconds = candidate;
            return Mathf.Min(halfLifeSeconds, candidate);
        }

        static float ResolveVerticalHistoryDelta(
            float deltaSeconds,
            float maximumSpeed)
        {
            if (deltaSeconds <= 0f)
                return 0f;
            return maximumSpeed * deltaSeconds;
        }

    }
}
