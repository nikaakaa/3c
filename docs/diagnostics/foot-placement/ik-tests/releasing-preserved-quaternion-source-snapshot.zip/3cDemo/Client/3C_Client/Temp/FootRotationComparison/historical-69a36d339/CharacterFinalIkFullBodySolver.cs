using System;
using RootMotion.FinalIK;
using Unity.Collections;
using UnityEngine;

namespace ThirdPersonCharacter.Pipeline.Animation
{
    internal struct CharacterFullBodyIkBendHistory
    {
        internal Vector3 LeftStableDirection;
        internal Vector3 RightStableDirection;
        internal Vector3 LeftAppliedDirection;
        internal Vector3 RightAppliedDirection;
        internal ulong SourceCompletionIdentity;
        internal ulong Revision;
        internal bool HasLeftStableDirection;
        internal bool HasRightStableDirection;
        internal bool HasLeftAppliedDirection;
        internal bool HasRightAppliedDirection;

        internal void Clear() => this = default;
    }

    internal readonly struct CharacterFullBodyIkBendReference
    {
        internal CharacterFullBodyIkBendReference(
            FixedString64Bytes rigId,
            FixedString64Bytes rigRevision,
            Vector3 leftDirection,
            Vector3 rightDirection)
        {
            if (!CharacterPoseConstraintMath.IsFinite(leftDirection) ||
                !CharacterPoseConstraintMath.IsFinite(rightDirection) ||
                leftDirection.sqrMagnitude <= CharacterPoseConstraintMath.Epsilon ||
                rightDirection.sqrMagnitude <= CharacterPoseConstraintMath.Epsilon)
                throw new ArgumentException("FBBIK reference bend directions are invalid.");
            RigId = rigId;
            RigRevision = rigRevision;
            LeftDirection = leftDirection;
            RightDirection = rightDirection;
        }

        internal FixedString64Bytes RigId { get; }
        internal FixedString64Bytes RigRevision { get; }
        internal Vector3 LeftDirection { get; }
        internal Vector3 RightDirection { get; }
    }

    public enum CharacterFullBodyIkFailure : byte
    {
        None = 0,
        NotPrepared = 1,
        InvalidPosePage = 2,
        InvalidGoalWorkspace = 3,
        GoalLineageMismatch = 4,
        DuplicateEffectorSlot = 5,
        UnsupportedPelvisGoal = 6,
        SolverFailure = 7,
        NonFiniteOutput = 8,
        FootEffectorSolverResidualExceeded = 9
    }

    public readonly struct CharacterFullBodyIkResult
    {
        CharacterFullBodyIkResult(
            CharacterFullBodyIkFailure failure,
            int failedGoalSetIndex,
            CharacterFullBodyIkEffectorSlot failedSlot,
            int appliedGoalCount,
            Vector3 failedTargetPosition,
            Vector3 failedSolverPosition,
            Vector3 failedSolvedPosition,
            float failedSolverResidual,
            float failedPositionResidual,
            CharacterFullBodyIkGoalSourceKind failedSourceKind,
            string failureDetail)
        {
            Failure = failure;
            FailedGoalSetIndex = failedGoalSetIndex;
            FailedSlot = failedSlot;
            AppliedGoalCount = appliedGoalCount;
            FailedTargetPosition = failedTargetPosition;
            FailedSolverPosition = failedSolverPosition;
            FailedSolvedPosition = failedSolvedPosition;
            FailedSolverResidual = failedSolverResidual;
            FailedPositionResidual = failedPositionResidual;
            FailedSourceKind = failedSourceKind;
            FailureDetail = failureDetail;
        }

        public CharacterFullBodyIkFailure Failure { get; }
        public int FailedGoalSetIndex { get; }
        public CharacterFullBodyIkEffectorSlot FailedSlot { get; }
        public int AppliedGoalCount { get; }
        public Vector3 FailedTargetPosition { get; }
        public Vector3 FailedSolverPosition { get; }
        public Vector3 FailedSolvedPosition { get; }
        public float FailedSolverResidual { get; }
        public float FailedPositionResidual { get; }
        public CharacterFullBodyIkGoalSourceKind FailedSourceKind { get; }
        public string FailureDetail { get; }
        public bool Succeeded => Failure == CharacterFullBodyIkFailure.None;

        internal static CharacterFullBodyIkResult Success(int appliedGoalCount) =>
            new CharacterFullBodyIkResult(
                CharacterFullBodyIkFailure.None,
                -1,
                default,
                appliedGoalCount,
                default,
                default,
                default,
                0f,
                0f,
                default,
                string.Empty);

        internal static CharacterFullBodyIkResult Fail(
            CharacterFullBodyIkFailure failure,
            int failedGoalSetIndex = -1,
            CharacterFullBodyIkEffectorSlot failedSlot = default) =>
            new CharacterFullBodyIkResult(
                failure,
                failedGoalSetIndex,
                failedSlot,
                0,
                default,
                default,
                default,
                0f,
                0f,
                default,
                string.Empty);

        internal static CharacterFullBodyIkResult FailSolver(Exception exception) =>
            new CharacterFullBodyIkResult(
                CharacterFullBodyIkFailure.SolverFailure,
                -1,
                default,
                0,
                default,
                default,
                default,
                0f,
                0f,
                default,
                $"{exception.GetType().Name}: {exception.Message}");

        internal static CharacterFullBodyIkResult FailFootSolverResidual(
            int failedGoalSetIndex,
            CharacterFullBodyIkEffectorSlot failedSlot,
            int appliedGoalCount,
            Vector3 targetPosition,
            Vector3 solverPosition,
            Vector3 solvedPosition,
            CharacterFullBodyIkGoalSourceKind sourceKind,
            float positionResidual) =>
            new CharacterFullBodyIkResult(
                CharacterFullBodyIkFailure.FootEffectorSolverResidualExceeded,
                failedGoalSetIndex,
                failedSlot,
                appliedGoalCount,
                targetPosition,
                solverPosition,
                solvedPosition,
                Vector3.Distance(targetPosition, solverPosition),
                positionResidual,
                sourceKind,
                string.Empty);
    }

    public sealed class CharacterFinalIkFullBodySolver
    {
        const float FootEffectorSolverResidualTolerance = 0.001f;
        const float ReliableBendHeightRatio = 0.01f;
        const float BendStabilizationStartExtensionRatio = 0.94f;
        const float BendStabilizationFullExtensionRatio = 0.99f;

        readonly CharacterAnimationRigPayload m_Rig;
        readonly CharacterFullBodyIkProfile m_Profile;
        readonly CharacterFinalIkPoseBufferBackend m_Backend;
        readonly IndexedBipedReferences m_References;
        readonly IKSolverFullBodyBiped m_Solver = new IKSolverFullBodyBiped();
        readonly IKEffector[] m_Effectors =
            new IKEffector[(int)CharacterFullBodyIkEffectorSlot.RightFoot + 1];
        CharacterFullBodyIkBendReference m_BendReference;
        readonly CharacterFullBodyIkEffectorDiagnostics[] m_DiagnosticEffectors =
            new CharacterFullBodyIkEffectorDiagnostics[CharacterFullBodyIkGoalSetHeader.MaximumGoalCount];
        readonly CharacterFullBodyIkLimbDiagnostics[] m_DiagnosticLimbs =
            new CharacterFullBodyIkLimbDiagnostics[4];
        CharacterFullBodyIkSolverDiagnostics m_Diagnostics;
        ActiveTuning m_ActiveTuning;
        ActiveTuning m_CandidateTuning;
        bool m_HasTuningCandidate;
        Vector3 m_AppliedPelvisTranslation;
        LegSolveFrame m_LeftLegSolveFrame;
        LegSolveFrame m_RightLegSolveFrame;
        ulong m_BendResetGeneration;
        ulong m_DiagnosticFrameSequence;
        int m_DiagnosticEffectorCount;
        bool m_Prepared;

        public CharacterFinalIkFullBodySolver(
            CharacterAnimationRigPayload rig,
            CharacterFullBodyIkProfile profile,
            NativeArray<int> parentIndices,
            NativeArray<CharacterVirtualBoneDescriptor> virtualBones)
        {
            m_Rig = rig ?? throw new ArgumentNullException(nameof(rig));
            m_Profile = profile ? profile : throw new ArgumentNullException(nameof(profile));
            m_Backend = new CharacterFinalIkPoseBufferBackend(rig, parentIndices, virtualBones);
            m_References = CharacterFinalIkPoseBufferBackend.CreateBipedReferences(rig);
            m_ActiveTuning = ActiveTuning.FromProfile(m_Profile);
            PrepareReferencePose(parentIndices);
        }

        public string BackendIdentity => CharacterFinalIkPoseBufferBackend.SourceIdentity;
        public string ProfileId => m_Profile.ProfileId;
        public string ProfileRevision => m_Profile.Revision;
        public bool IsPrepared => m_Prepared;
        internal CharacterFullBodyIkSolverDiagnostics Diagnostics => m_Diagnostics;
        internal int DiagnosticEffectorCount => m_DiagnosticEffectorCount;
        internal int DiagnosticLimbCount => m_DiagnosticLimbs.Length;

        internal CharacterFullBodyIkEffectorDiagnostics GetDiagnosticEffector(int index)
        {
            if ((uint)index >= (uint)m_DiagnosticEffectorCount)
                throw new ArgumentOutOfRangeException(nameof(index));
            return m_DiagnosticEffectors[index];
        }

        internal CharacterFullBodyIkLimbDiagnostics GetDiagnosticLimb(int index)
        {
            if ((uint)index >= (uint)m_DiagnosticLimbs.Length)
                throw new ArgumentOutOfRangeException(nameof(index));
            return m_DiagnosticLimbs[index];
        }

        internal string PrepareTuningCandidate(
            CharacterPoseTuningLayout layout,
            CharacterPoseTuningParameterBlock block)
        {
            if (layout == null || block == null)
                return "Full Body IK tuning payload is missing.";
            try
            {
                if (m_HasTuningCandidate)
                {
                    throw new InvalidOperationException(
                        "Full Body IK tuning candidate is already prepared.");
                }
                block.RequireValid(layout);
                var next = m_ActiveTuning;
                string ownerId = $"full-body-ik-profile:{m_Profile.ProfileId}";
                for (int i = 0; i < layout.Entries.Count; i++)
                {
                    CharacterPoseTuningLayoutEntry entry = layout.Entries[i];
                    if (!string.Equals(entry.OwnerId, ownerId, StringComparison.Ordinal) ||
                        entry.Interaction != CharacterPoseTuningInteractionPolicy.TunableDefault)
                        continue;
                    ApplyTuningField(ref next, entry, block.GetValue(entry));
                }
                next.RequireValid();
                m_CandidateTuning = next;
                m_HasTuningCandidate = true;
                return string.Empty;
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        internal void CommitTuningCandidate(bool resetOwnerState)
        {
            if (!m_HasTuningCandidate)
            {
                throw new InvalidOperationException(
                    "Full Body IK tuning candidate is not prepared.");
            }
            m_ActiveTuning = m_CandidateTuning;
            m_CandidateTuning = default;
            m_HasTuningCandidate = false;
            ApplyProfile();
            if (!resetOwnerState)
                return;
            ResetEffectorsToPose();
            ResetLegBendState();
        }

        internal void DiscardTuningCandidate()
        {
            m_CandidateTuning = default;
            m_HasTuningCandidate = false;
        }

        CharacterFullBodyIkResult Prepare(
            NativeSlice<AnimationLocalBonePose> referenceComponentPose)
        {
            if (!m_Backend.TryBind(referenceComponentPose))
                return CharacterFullBodyIkResult.Fail(CharacterFullBodyIkFailure.InvalidPosePage);
            try
            {
                m_Solver.SetToIndexedReferences(m_Backend, m_References);
                CacheEffectors();
                ApplyProfile();
                IKConstraintBend left = m_Solver.GetBendConstraint(FullBodyBipedChain.LeftLeg);
                IKConstraintBend right = m_Solver.GetBendConstraint(FullBodyBipedChain.RightLeg);
                if (!left.initiated || !right.initiated)
                    throw new InvalidOperationException("FBBIK reference bend constraints were not initialized.");
                m_BendReference = new CharacterFullBodyIkBendReference(
                    new FixedString64Bytes(m_Rig.RigId),
                    new FixedString64Bytes(m_Rig.RigRevision),
                    left.direction,
                    right.direction);
                ResetEffectorsToPose();
                ResetLegBendState();
                m_Prepared = true;
                return CharacterFullBodyIkResult.Success(0);
            }
            catch (Exception exception)
            {
                m_Prepared = false;
                return CharacterFullBodyIkResult.FailSolver(exception);
            }
        }

        internal CharacterFullBodyIkResult SolvePrepared(
            NativeSlice<AnimationLocalBonePose> pendingOutputComponentPose,
            in CharacterFullBodyIkGoalSetHeader goalSet,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace,
            ref CharacterFullBodyIkBendHistory bendHistory,
            ulong frameSequence,
            ulong completionIdentity,
            bool recordDiagnostics)
        {
            if (recordDiagnostics)
                BeginDiagnostics(frameSequence);
            if (!m_Prepared)
            {
                return CompleteResult(
                    CharacterFullBodyIkResult.Fail(CharacterFullBodyIkFailure.NotPrepared),
                    in goalSet,
                    goalWorkspace,
                    completionIdentity,
                    recordDiagnostics);
            }
            if (!m_Backend.TryBind(pendingOutputComponentPose))
            {
                return CompleteResult(
                    CharacterFullBodyIkResult.Fail(CharacterFullBodyIkFailure.InvalidPosePage),
                    in goalSet,
                    goalWorkspace,
                    completionIdentity,
                    recordDiagnostics);
            }

            try
            {
                CharacterFullBodyIkResult goalResult = ApplyGoals(
                    in goalSet,
                    goalWorkspace,
                    ref bendHistory,
                    frameSequence,
                    completionIdentity);
                if (!goalResult.Succeeded)
                {
                    return CompleteResult(
                        goalResult,
                        in goalSet,
                        goalWorkspace,
                        completionIdentity,
                        recordDiagnostics);
                }
                if (!HasEffectiveGoal(in goalSet, goalWorkspace))
                {
                    bendHistory.SourceCompletionIdentity = completionIdentity;
                    bendHistory.Revision++;
                    return CompleteResult(
                        goalResult,
                        in goalSet,
                        goalWorkspace,
                        completionIdentity,
                        recordDiagnostics);
                }
                m_Solver.Update();
                m_Backend.RebuildVirtualBones();
                if (!IsValidPosePage(pendingOutputComponentPose))
                {
                    return CompleteResult(
                        CharacterFullBodyIkResult.Fail(CharacterFullBodyIkFailure.NonFiniteOutput),
                        in goalSet,
                        goalWorkspace,
                        completionIdentity,
                        recordDiagnostics);
                }
                CharacterFullBodyIkResult solvedResult = ValidateSolvedFootGoals(
                    goalResult,
                    in goalSet,
                    goalWorkspace);
                bendHistory.SourceCompletionIdentity = completionIdentity;
                bendHistory.Revision++;
                return CompleteResult(
                    solvedResult,
                    in goalSet,
                    goalWorkspace,
                    completionIdentity,
                    recordDiagnostics);
            }
            catch (Exception exception)
            {
                return CompleteResult(
                    CharacterFullBodyIkResult.FailSolver(exception),
                    in goalSet,
                    goalWorkspace,
                    completionIdentity,
                    recordDiagnostics);
            }
        }

        public void Reset()
        {
            if (!m_Prepared)
                return;
            for (int i = 0; i < m_Solver.effectors.Length; i++)
            {
                IKEffector effector = m_Solver.effectors[i];
                effector.target = null;
                effector.positionWeight = 0f;
                effector.rotationWeight = 0f;
                effector.positionOffset = Vector3.zero;
            }
            m_Diagnostics = default;
            m_AppliedPelvisTranslation = Vector3.zero;
            ResetLegBendState();
            m_DiagnosticFrameSequence = 0;
            m_DiagnosticEffectorCount = 0;
            Array.Clear(m_DiagnosticEffectors, 0, m_DiagnosticEffectors.Length);
            Array.Clear(m_DiagnosticLimbs, 0, m_DiagnosticLimbs.Length);
        }

        void PrepareReferencePose(NativeArray<int> parentIndices)
        {
            var referencePose = new NativeArray<AnimationLocalBonePose>(
                m_Rig.PoseBoneCount,
                Allocator.Temp,
                NativeArrayOptions.UninitializedMemory);
            try
            {
                for (int bone = 0; bone < referencePose.Length; bone++)
                {
                    AnimationLocalBonePose local = m_Rig.GetReferenceLocalPose(bone);
                    int parent = parentIndices[bone];
                    if (parent < 0)
                    {
                        referencePose[bone] = local;
                        continue;
                    }
                    AnimationLocalBonePose parentPose = referencePose[parent];
                    referencePose[bone] = new AnimationLocalBonePose(
                        parentPose.Position + parentPose.Rotation * Vector3.Scale(parentPose.Scale, local.Position),
                        parentPose.Rotation * local.Rotation,
                        Vector3.Scale(parentPose.Scale, local.Scale));
                }
                CharacterFullBodyIkResult result = Prepare(new NativeSlice<AnimationLocalBonePose>(referencePose));
                if (!result.Succeeded)
                    throw new InvalidOperationException($"FinalIK FBBIK reference preparation failed: {result.Failure}.");
            }
            finally
            {
                referencePose.Dispose();
            }
        }

        CharacterFullBodyIkResult ApplyGoals(
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace,
            ref CharacterFullBodyIkBendHistory bendHistory,
            ulong frameSequence,
            ulong completionIdentity)
        {
            if (!goalWorkspace.IsCreated)
                return CharacterFullBodyIkResult.Fail(CharacterFullBodyIkFailure.InvalidGoalWorkspace);
            if (!header.IsValid ||
                header.FrameSequence != frameSequence ||
                header.CompletionIdentity != completionIdentity ||
                !header.RigId.Equals(m_BendReference.RigId) ||
                !header.RigRevision.Equals(m_BendReference.RigRevision) ||
                header.GoalOffset > goalWorkspace.Length - header.GoalCount)
            {
                return CharacterFullBodyIkResult.Fail(
                    CharacterFullBodyIkFailure.GoalLineageMismatch,
                    0);
            }
            if (header.Availability != CharacterFullBodyIkGoalSetAvailability.Ready)
            {
                return CharacterFullBodyIkResult.Fail(
                    CharacterFullBodyIkFailure.InvalidGoalWorkspace,
                    0);
            }

            ushort occupiedSlots = 0;
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (!goal.IsValid)
                {
                    return CharacterFullBodyIkResult.Fail(
                        CharacterFullBodyIkFailure.InvalidGoalWorkspace,
                        0,
                        goal.Slot);
                }
                int slotBit = 1 << ((int)goal.Slot - 1);
                if ((occupiedSlots & slotBit) != 0)
                {
                    return CharacterFullBodyIkResult.Fail(
                        CharacterFullBodyIkFailure.DuplicateEffectorSlot,
                        0,
                        goal.Slot);
                }
                occupiedSlots = (ushort)(occupiedSlots | slotBit);
            }

            CharacterFullBodyIkResult pelvisResult = ApplyPelvisGoal(
                in header,
                goalWorkspace);
            if (!pelvisResult.Succeeded)
                return pelvisResult;
            ApplyFootPlacementPreSolveRotations(in header, goalWorkspace);
            ushort identityPoseBoneSlots =
                CollectIdentityPoseBoneSlots(in header, goalWorkspace);
            ResetEffectorsToPose();
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (goal.Slot ==
                    CharacterFullBodyIkEffectorSlot.PelvisPreSolveTranslation)
                    continue;
                int slotBit = 1 << ((int)goal.Slot - 1);
                if ((identityPoseBoneSlots & slotBit) != 0)
                    continue;
                ApplyEffectorGoal(goal);
            }
            ApplyLegBendStabilization(
                in header,
                goalWorkspace,
                ref bendHistory);
            return CharacterFullBodyIkResult.Success(header.GoalCount);
        }

        CharacterFullBodyIkResult ApplyPelvisGoal(
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace)
        {
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (goal.Slot !=
                    CharacterFullBodyIkEffectorSlot.PelvisPreSolveTranslation)
                    continue;
                if (goal.Application !=
                    CharacterFullBodyIkGoalApplication.PelvisPreSolveTranslation)
                {
                    return CharacterFullBodyIkResult.Fail(
                        CharacterFullBodyIkFailure.UnsupportedPelvisGoal,
                        0,
                        goal.Slot);
                }
                IndexedBoneHandle pelvis =
                    new IndexedBoneHandle(m_Rig.PelvisPhysicalBoneIndex);
                m_Backend.SetComponentPosition(
                    pelvis,
                    m_Backend.GetComponentPosition(pelvis) +
                    goal.ComponentPosition * goal.PositionWeight);
                m_AppliedPelvisTranslation =
                    goal.ComponentPosition * goal.PositionWeight;
            }
            return CharacterFullBodyIkResult.Success(0);
        }

        void ApplyEffectorGoal(CharacterFullBodyIkGoal goal)
        {
            IKEffector effector = m_Effectors[(int)goal.Slot];
            switch (goal.Application)
            {
                case CharacterFullBodyIkGoalApplication.AbsoluteEffectorTarget:
                    effector.position = goal.ComponentPosition;
                    effector.rotation = goal.ComponentRotation;
                    effector.positionWeight = goal.PositionWeight;
                    effector.rotationWeight = goal.RotationWeight;
                    break;
                case CharacterFullBodyIkGoalApplication.FootPlacementEffectorTarget:
                    effector.position = ResolveFootPlacementEffectorPosition(in goal);
                    effector.positionWeight = goal.PositionWeight;
                    break;
                default:
                    throw new InvalidOperationException($"Unsupported effector goal application {goal.Application}.");
            }
        }

        Vector3 ResolveFootPlacementEffectorPosition(in CharacterFullBodyIkGoal goal)
        {
            float weight = goal.PositionWeight;
            return weight > CharacterPoseConstraintMath.Epsilon
                ? goal.ComponentPosition - m_AppliedPelvisTranslation * ((1f - weight) / weight)
                : goal.ComponentPosition;
        }

        void ApplyFootPlacementPreSolveRotations(
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace)
        {
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (goal.Application !=
                        CharacterFullBodyIkGoalApplication
                            .FootPlacementEffectorTarget ||
                    goal.RotationWeight <= CharacterPoseConstraintMath.Epsilon)
                {
                    continue;
                }
                IKEffector effector =
                    m_Effectors[(int)goal.Slot];
                Quaternion current =
                    m_Backend.GetComponentRotation(effector.boneHandle);
                Quaternion offset =
                    goal.ComponentRotation * Quaternion.Inverse(current);
                Quaternion weightedOffset = Quaternion.Slerp(
                    Quaternion.identity,
                    offset,
                    goal.RotationWeight);
                Quaternion weightedRotation =
                    weightedOffset * current;
                m_Backend.SetComponentRotation(
                    effector.boneHandle,
                    weightedRotation);
            }
        }

        ushort CollectIdentityPoseBoneSlots(
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace)
        {
            ushort slots = 0;
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (goal.SourceKind !=
                        CharacterFullBodyIkGoalSourceKind.PoseBone ||
                    goal.Slot ==
                        CharacterFullBodyIkEffectorSlot
                            .PelvisPreSolveTranslation)
                {
                    continue;
                }
                IKEffector effector =
                    m_Effectors[(int)goal.Slot];
                bool positionUnchanged =
                    goal.PositionWeight <= CharacterPoseConstraintMath.Epsilon ||
                    (goal.ComponentPosition -
                     m_Backend.GetComponentPosition(effector.boneHandle))
                    .sqrMagnitude <= CharacterPoseConstraintMath.Epsilon;
                bool rotationUnchanged =
                    goal.RotationWeight <= CharacterPoseConstraintMath.Epsilon ||
                    Mathf.Abs(Quaternion.Dot(
                        goal.ComponentRotation,
                        m_Backend.GetComponentRotation(effector.boneHandle))) >=
                    1f - CharacterPoseConstraintMath.Epsilon;
                if (positionUnchanged && rotationUnchanged)
                    slots = (ushort)(slots | 1 << ((int)goal.Slot - 1));
            }
            return slots;
        }

        static bool HasEffectiveGoal(
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace)
        {
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (goal.PositionWeight > CharacterPoseConstraintMath.Epsilon ||
                    goal.RotationWeight > CharacterPoseConstraintMath.Epsilon)
                {
                    return true;
                }
            }
            return false;
        }

        void ResetEffectorsToPose()
        {
            for (int i = 0; i < m_Solver.effectors.Length; i++)
            {
                IKEffector effector = m_Solver.effectors[i];
                effector.target = null;
                effector.position = m_Backend.GetComponentPosition(effector.boneHandle);
                effector.rotation = m_Backend.GetComponentRotation(effector.boneHandle);
                effector.positionWeight = 0f;
                effector.rotationWeight = 0f;
                effector.positionOffset = Vector3.zero;
            }
        }

        void ApplyLegBendStabilization(
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace,
            ref CharacterFullBodyIkBendHistory bendHistory)
        {
            bool hasLeftGoal = TryFindFootPlacementGoal(
                CharacterFullBodyIkEffectorSlot.LeftFoot,
                in header,
                goalWorkspace,
                out CharacterFullBodyIkGoal leftGoal);
            bool hasRightGoal = TryFindFootPlacementGoal(
                CharacterFullBodyIkEffectorSlot.RightFoot,
                in header,
                goalWorkspace,
                out CharacterFullBodyIkGoal rightGoal);
            m_LeftLegSolveFrame = ApplyLegBendStabilization(
                m_Rig.LeftLeg,
                FullBodyBipedChain.LeftLeg,
                m_ActiveTuning.LeftLeg,
                hasLeftGoal,
                in leftGoal,
                m_BendReference.LeftDirection,
                ref bendHistory.LeftStableDirection,
                ref bendHistory.HasLeftStableDirection,
                ref bendHistory.LeftAppliedDirection,
                ref bendHistory.HasLeftAppliedDirection);
            m_RightLegSolveFrame = ApplyLegBendStabilization(
                m_Rig.RightLeg,
                FullBodyBipedChain.RightLeg,
                m_ActiveTuning.RightLeg,
                hasRightGoal,
                in rightGoal,
                m_BendReference.RightDirection,
                ref bendHistory.RightStableDirection,
                ref bendHistory.HasRightStableDirection,
                ref bendHistory.RightAppliedDirection,
                ref bendHistory.HasRightAppliedDirection);
        }

        LegSolveFrame ApplyLegBendStabilization(
            CharacterAnimationLegChainPayload leg,
            FullBodyBipedChain chainId,
            ActiveLimb settings,
            bool hasFootPlacementGoal,
            in CharacterFullBodyIkGoal goal,
            Vector3 referenceDirection,
            ref Vector3 stableBendDirection,
            ref bool hasStableBendDirection,
            ref Vector3 appliedBendDirection,
            ref bool hasAppliedBendDirection)
        {
            bool hadStableBendDirection = hasStableBendDirection;
            bool hadAppliedBendDirection = hasAppliedBendDirection;
            var hip = new IndexedBoneHandle(leg.HipPhysicalBoneIndex);
            var knee = new IndexedBoneHandle(leg.KneePhysicalBoneIndex);
            var ankle = new IndexedBoneHandle(leg.AnklePhysicalBoneIndex);
            Vector3 originalHip = m_Backend.GetComponentPosition(hip);
            Vector3 originalKnee = m_Backend.GetComponentPosition(knee);
            Vector3 originalAnkle = m_Backend.GetComponentPosition(ankle);
            float upperLength = Vector3.Distance(originalHip, originalKnee);
            float lowerLength = Vector3.Distance(originalKnee, originalAnkle);
            float legLength = upperLength + lowerLength;
            Vector3 targetAnkle = hasFootPlacementGoal
                ? Vector3.Lerp(originalAnkle, ResolveFootPlacementEffectorPosition(in goal), goal.PositionWeight)
                : originalAnkle;
            bool hasAnimatedDirection = TryResolveBendDirection(
                originalHip,
                originalKnee,
                originalAnkle,
                legLength * ReliableBendHeightRatio,
                out Vector3 animatedDirection);
            CharacterFullBodyIkBendDirectionSource bendDirectionSource =
                hasAnimatedDirection
                    ? CharacterFullBodyIkBendDirectionSource.Animated
                    : hadStableBendDirection
                        ? CharacterFullBodyIkBendDirectionSource.StableHistory
                        : CharacterFullBodyIkBendDirectionSource.Reference;
            float animatedPreviousDot = 1f;
            bool retainedPreviousDirection = false;
            if (hasAnimatedDirection)
            {
                if (hasStableBendDirection)
                {
                    animatedPreviousDot = Vector3.Dot(
                        animatedDirection,
                        stableBendDirection);
                }
                stableBendDirection = animatedDirection;
                hasStableBendDirection = true;
            }
            else if (hasStableBendDirection)
            {
                retainedPreviousDirection = true;
            }

            IKConstraintBend bend = m_Solver.GetBendConstraint(chainId);
            Vector3 effectiveDirection = hasStableBendDirection
                ? stableBendDirection
                : referenceDirection;
            Vector3 targetAxis = targetAnkle - originalHip;
            if (hasAnimatedDirection)
            {
                if (targetAxis.sqrMagnitude <= CharacterPoseConstraintMath.Epsilon)
                    throw new InvalidOperationException(
                        "Reliable animation bend direction requires a nonzero target leg axis.");
                effectiveDirection = (Quaternion.FromToRotation(
                    originalAnkle - originalHip,
                    targetAxis) * animatedDirection).normalized;
            }
            else
            {
                Vector3 projectedDirection = Vector3.ProjectOnPlane(
                    effectiveDirection,
                    targetAxis);
                if (projectedDirection.sqrMagnitude > CharacterPoseConstraintMath.Epsilon)
                    effectiveDirection = projectedDirection.normalized;
            }
            float effectivePreviousDot = hasAppliedBendDirection
                ? Vector3.Dot(effectiveDirection, appliedBendDirection)
                : 1f;
            if (!hasAnimatedDirection && effectivePreviousDot < 0f)
            {
                effectiveDirection = -effectiveDirection;
                effectivePreviousDot = -effectivePreviousDot;
            }
            appliedBendDirection = effectiveDirection;
            hasAppliedBendDirection = true;
            float originalDistance = Vector3.Distance(originalHip, originalAnkle);
            float targetDistance = Vector3.Distance(originalHip, targetAnkle);
            float originalReserve = Mathf.Max(0f, legLength - originalDistance);
            float targetReserve = Mathf.Max(0f, legLength - targetDistance);
            float targetExtensionRatio = legLength > CharacterPoseConstraintMath.Epsilon
                ? targetDistance / legLength
                : 0f;
            float stabilizationWeight = hasFootPlacementGoal
                ? ResolveBendStabilizationWeight(
                    goal.PositionWeight,
                    targetExtensionRatio,
                    originalReserve,
                    targetReserve)
                : 0f;
            float effectiveBendWeight = Mathf.Max(
                settings.BendConstraintWeight,
                stabilizationWeight);
            bend.direction = effectiveDirection;
            bend.weight = effectiveBendWeight;
            return new LegSolveFrame(
                originalHip,
                originalKnee,
                originalAnkle,
                targetAnkle,
                effectiveDirection,
                legLength,
                animatedPreviousDot,
                effectivePreviousDot,
                stabilizationWeight,
                effectiveBendWeight,
                retainedPreviousDirection,
                hadStableBendDirection,
                hadAppliedBendDirection,
                bendDirectionSource);
        }

        static bool TryFindFootPlacementGoal(
            CharacterFullBodyIkEffectorSlot slot,
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace,
            out CharacterFullBodyIkGoal result)
        {
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal candidate =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (candidate.Slot != slot ||
                    candidate.Application !=
                    CharacterFullBodyIkGoalApplication
                        .FootPlacementEffectorTarget)
                {
                    continue;
                }
                result = candidate;
                return true;
            }
            result = default;
            return false;
        }

        static float ResolveBendStabilizationWeight(
            float positionWeight,
            float targetExtensionRatio,
            float originalReserve,
            float targetReserve)
        {
            float extensionRisk = Mathf.SmoothStep(
                0f,
                1f,
                Mathf.InverseLerp(
                    BendStabilizationStartExtensionRatio,
                    BendStabilizationFullExtensionRatio,
                    targetExtensionRatio));
            float reserveConsumptionRisk = originalReserve > CharacterPoseConstraintMath.Epsilon
                ? Mathf.Clamp01((originalReserve - targetReserve) / originalReserve)
                : extensionRisk;
            return Mathf.Clamp01(positionWeight) * Mathf.Max(
                extensionRisk,
                reserveConsumptionRisk);
        }

        static bool TryResolveBendDirection(
            Vector3 hip,
            Vector3 knee,
            Vector3 ankle,
            float minimumHeight,
            out Vector3 direction)
        {
            Vector3 axis = ankle - hip;
            float axisSquare = axis.sqrMagnitude;
            if (axisSquare <= CharacterPoseConstraintMath.Epsilon)
            {
                direction = default;
                return false;
            }
            Vector3 projected = hip + axis * Mathf.Clamp01(
                Vector3.Dot(knee - hip, axis) / axisSquare);
            Vector3 bend = knee - projected;
            if (bend.sqrMagnitude <= minimumHeight * minimumHeight)
            {
                direction = default;
                return false;
            }
            direction = bend.normalized;
            return true;
        }

        CharacterFullBodyIkLegPoseDiagnostics BuildLegPoseDiagnostics(
            in LegSolveFrame frame,
            CharacterAnimationLegChainPayload leg)
        {
            if (!frame.IsAvailable)
                return default;
            Vector3 solvedHip = m_Backend.GetComponentPosition(
                new IndexedBoneHandle(leg.HipPhysicalBoneIndex));
            Vector3 solvedKnee = m_Backend.GetComponentPosition(
                new IndexedBoneHandle(leg.KneePhysicalBoneIndex));
            Vector3 solvedAnkle = m_Backend.GetComponentPosition(
                new IndexedBoneHandle(leg.AnklePhysicalBoneIndex));
            float solvedDistance = Vector3.Distance(solvedHip, solvedAnkle);
            return new CharacterFullBodyIkLegPoseDiagnostics(
                frame.OriginalHip,
                frame.OriginalKnee,
                frame.OriginalAnkle,
                frame.TargetAnkle,
                solvedHip,
                solvedKnee,
                solvedAnkle,
                frame.EffectiveBendDirection,
                ResolveKneeBendDegrees(
                    frame.OriginalHip,
                    frame.OriginalKnee,
                    frame.OriginalAnkle),
                ResolveKneeBendDegrees(solvedHip, solvedKnee, solvedAnkle),
                ResolveExtensionRatio(
                    frame.OriginalHip,
                    frame.OriginalAnkle,
                    frame.LegLength),
                ResolveExtensionRatio(
                    frame.OriginalHip,
                    frame.TargetAnkle,
                    frame.LegLength),
                frame.LegLength > CharacterPoseConstraintMath.Epsilon
                    ? solvedDistance / frame.LegLength
                    : 0f,
                ResolveCompressionReserve(
                    frame.OriginalHip,
                    frame.OriginalAnkle,
                    frame.LegLength),
                ResolveCompressionReserve(
                    frame.OriginalHip,
                    frame.TargetAnkle,
                    frame.LegLength),
                Mathf.Max(0f, frame.LegLength - solvedDistance),
                frame.AnimatedBendDirectionPreviousDot,
                frame.EffectiveBendDirectionPreviousDot,
                frame.StabilizationWeight,
                frame.RetainedPreviousBendDirection,
                frame.HadStableBendDirection,
                frame.HadAppliedBendDirection,
                frame.BendDirectionSource);
        }

        static float ResolveKneeBendDegrees(
            Vector3 hip,
            Vector3 knee,
            Vector3 ankle) =>
            180f - Vector3.Angle(hip - knee, ankle - knee);

        static float ResolveExtensionRatio(
            Vector3 hip,
            Vector3 ankle,
            float legLength) =>
            legLength > CharacterPoseConstraintMath.Epsilon
                ? Vector3.Distance(hip, ankle) / legLength
                : 0f;

        static float ResolveCompressionReserve(
            Vector3 hip,
            Vector3 ankle,
            float legLength) =>
            Mathf.Max(0f, legLength - Vector3.Distance(hip, ankle));

        void ResetLegBendState()
        {
            m_BendResetGeneration++;
            m_LeftLegSolveFrame = default;
            m_RightLegSolveFrame = default;
            IKConstraintBend left = m_Solver.GetBendConstraint(FullBodyBipedChain.LeftLeg);
            IKConstraintBend right = m_Solver.GetBendConstraint(FullBodyBipedChain.RightLeg);
            left.direction = m_BendReference.LeftDirection;
            right.direction = m_BendReference.RightDirection;
            left.weight = m_ActiveTuning.LeftLeg.BendConstraintWeight;
            right.weight = m_ActiveTuning.RightLeg.BendConstraintWeight;
        }

        CharacterFullBodyIkResult ValidateSolvedFootGoals(
            CharacterFullBodyIkResult solvedResult,
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace)
        {
            for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
            {
                CharacterFullBodyIkGoal goal =
                    goalWorkspace[header.GoalOffset + goalIndex];
                if (goal.Application !=
                        CharacterFullBodyIkGoalApplication
                            .FootPlacementEffectorTarget ||
                    goal.PositionWeight <
                        1f - CharacterPoseConstraintMath.Epsilon)
                {
                    continue;
                }
                IKEffector effector =
                    m_Effectors[(int)goal.Slot];
                Vector3 solverPosition =
                    effector.GetNode(m_Solver).solverPosition;
                Vector3 solvedPosition =
                    m_Backend.GetComponentPosition(effector.boneHandle);
                if (!CharacterPoseConstraintMath.IsFinite(solverPosition))
                {
                    return CharacterFullBodyIkResult.Fail(
                        CharacterFullBodyIkFailure.NonFiniteOutput,
                        0,
                        goal.Slot);
                }
                Vector3 effectorTarget = ResolveFootPlacementEffectorPosition(in goal);
                float solverResidual =
                    Vector3.Distance(solverPosition, effectorTarget);
                float residual =
                    Vector3.Distance(solvedPosition, effectorTarget);
                if (solverResidual > FootEffectorSolverResidualTolerance)
                {
                    return CharacterFullBodyIkResult.FailFootSolverResidual(
                        0,
                        goal.Slot,
                        solvedResult.AppliedGoalCount,
                        effectorTarget,
                        solverPosition,
                        solvedPosition,
                        goal.SourceKind,
                        residual);
                }
            }
            return solvedResult;
        }

        void ApplyProfile()
        {
            m_Solver.iterations = m_ActiveTuning.Iterations;
            m_Solver.FABRIKPass = m_ActiveTuning.FabrikPass;
            m_Solver.spineStiffness = m_ActiveTuning.SpineStiffness;
            m_Solver.pullBodyVertical = m_ActiveTuning.PullBodyVertical;
            m_Solver.pullBodyHorizontal = m_ActiveTuning.PullBodyHorizontal;
            ApplyLimbProfile(FullBodyBipedChain.LeftArm, m_ActiveTuning.LeftArm);
            ApplyLimbProfile(FullBodyBipedChain.RightArm, m_ActiveTuning.RightArm);
            ApplyLimbProfile(FullBodyBipedChain.LeftLeg, m_ActiveTuning.LeftLeg);
            ApplyLimbProfile(FullBodyBipedChain.RightLeg, m_ActiveTuning.RightLeg);
            for (int chainIndex = 0; chainIndex < m_Solver.chain.Length; chainIndex++)
            {
                IKSolver.Node[] nodes = m_Solver.chain[chainIndex].nodes;
                for (int nodeIndex = 0; nodeIndex < nodes.Length; nodeIndex++)
                    nodes[nodeIndex].weight = m_ActiveTuning.NodeWeight;
            }
        }

        void BeginDiagnostics(ulong frameSequence)
        {
            m_Diagnostics = default;
            m_AppliedPelvisTranslation = Vector3.zero;
            m_DiagnosticFrameSequence = frameSequence;
            m_DiagnosticEffectorCount = 0;
            m_LeftLegSolveFrame = default;
            m_RightLegSolveFrame = default;
            Array.Clear(m_DiagnosticEffectors, 0, m_DiagnosticEffectors.Length);
            Array.Clear(m_DiagnosticLimbs, 0, m_DiagnosticLimbs.Length);
            if (frameSequence == 0)
                throw new ArgumentOutOfRangeException(nameof(frameSequence));
        }

        CharacterFullBodyIkResult CompleteResult(
            CharacterFullBodyIkResult result,
            in CharacterFullBodyIkGoalSetHeader header,
            NativeArray<CharacterFullBodyIkGoal> goalWorkspace,
            ulong completionIdentity,
            bool recordDiagnostics)
        {
            if (!recordDiagnostics)
                return result;
            if (result.Succeeded ||
                result.Failure ==
                CharacterFullBodyIkFailure.FootEffectorSolverResidualExceeded)
            {
                for (int goalIndex = 0; goalIndex < header.GoalCount; goalIndex++)
                {
                    CharacterFullBodyIkGoal goal =
                        goalWorkspace[header.GoalOffset + goalIndex];
                    Vector3 solvedPosition;
                    Quaternion solvedRotation;
                    float positionResidual;
                    float rotationResidual;
                    if (goal.Slot ==
                        CharacterFullBodyIkEffectorSlot
                            .PelvisPreSolveTranslation)
                    {
                        IndexedBoneHandle pelvis =
                            new IndexedBoneHandle(
                                m_Rig.PelvisPhysicalBoneIndex);
                        solvedPosition =
                            m_Backend.GetComponentPosition(pelvis);
                        solvedRotation =
                            m_Backend.GetComponentRotation(pelvis);
                        positionResidual = 0f;
                        rotationResidual = 0f;
                    }
                    else
                    {
                        IKEffector effector =
                            m_Effectors[(int)goal.Slot];
                        solvedPosition =
                            m_Backend.GetComponentPosition(
                                effector.boneHandle);
                        solvedRotation =
                            m_Backend.GetComponentRotation(
                                effector.boneHandle);
                        positionResidual = Vector3.Distance(
                            solvedPosition,
                            goal.ComponentPosition);
                        rotationResidual = Quaternion.Angle(
                            solvedRotation,
                            goal.ComponentRotation);
                    }
                    m_DiagnosticEffectors[m_DiagnosticEffectorCount++] =
                        new CharacterFullBodyIkEffectorDiagnostics(
                            goal,
                            solvedPosition,
                            solvedRotation,
                            positionResidual,
                            rotationResidual);
                }
            }
            CopyLimbDiagnostics();
            m_Diagnostics = new CharacterFullBodyIkSolverDiagnostics(
                m_DiagnosticFrameSequence,
                completionIdentity,
                result.Succeeded ? completionIdentity : 0,
                BackendIdentity,
                m_Rig.RigId,
                m_Rig.RigRevision,
                ProfileId,
                ProfileRevision,
                m_BendResetGeneration,
                m_ActiveTuning.Iterations,
                m_ActiveTuning.FabrikPass,
                m_AppliedPelvisTranslation,
                result,
                m_DiagnosticEffectorCount,
                m_DiagnosticLimbs.Length);
            return result;
        }

        void CopyLimbDiagnostics()
        {
            m_DiagnosticLimbs[0] = LimbDiagnostics(
                CharacterFullBodyIkLimbSlot.LeftArm,
                m_ActiveTuning.LeftArm,
                default,
                m_ActiveTuning.LeftArm.BendConstraintWeight);
            m_DiagnosticLimbs[1] = LimbDiagnostics(
                CharacterFullBodyIkLimbSlot.RightArm,
                m_ActiveTuning.RightArm,
                default,
                m_ActiveTuning.RightArm.BendConstraintWeight);
            m_DiagnosticLimbs[2] = LimbDiagnostics(
                CharacterFullBodyIkLimbSlot.LeftLeg,
                m_ActiveTuning.LeftLeg,
                BuildLegPoseDiagnostics(in m_LeftLegSolveFrame, m_Rig.LeftLeg),
                m_LeftLegSolveFrame.IsAvailable
                    ? m_LeftLegSolveFrame.EffectiveBendWeight
                    : m_ActiveTuning.LeftLeg.BendConstraintWeight);
            m_DiagnosticLimbs[3] = LimbDiagnostics(
                CharacterFullBodyIkLimbSlot.RightLeg,
                m_ActiveTuning.RightLeg,
                BuildLegPoseDiagnostics(in m_RightLegSolveFrame, m_Rig.RightLeg),
                m_RightLegSolveFrame.IsAvailable
                    ? m_RightLegSolveFrame.EffectiveBendWeight
                    : m_ActiveTuning.RightLeg.BendConstraintWeight);
        }

        static CharacterFullBodyIkLimbDiagnostics LimbDiagnostics(
            CharacterFullBodyIkLimbSlot limb,
            ActiveLimb settings,
            CharacterFullBodyIkLegPoseDiagnostics legPose,
            float bendWeight) =>
            new CharacterFullBodyIkLimbDiagnostics(
                limb,
                settings.Pull,
                settings.Reach,
                bendWeight,
                settings.BendClamp,
                legPose);

        void ApplyLimbProfile(
            FullBodyBipedChain chainId,
            ActiveLimb settings)
        {
            FBIKChain chain = m_Solver.GetChain(chainId);
            chain.pin = settings.Pin;
            chain.pull = settings.Pull;
            chain.push = settings.Push;
            chain.pushParent = settings.PushParent;
            chain.reach = settings.Reach;
            chain.reachSmoothing = ToFinalIkSmoothing(settings.ReachSmoothing);
            chain.pushSmoothing = ToFinalIkSmoothing(settings.PushSmoothing);
            IKMappingLimb mapping = m_Solver.GetLimbMapping(chainId);
            mapping.weight = settings.MappingWeight;
            mapping.maintainRotationWeight = settings.MaintainRotationWeight;
            IKConstraintBend bend = m_Solver.GetBendConstraint(chainId);
            bend.weight = settings.BendConstraintWeight;
            bend.clampF = settings.BendClamp;
        }

        static void ApplyTuningField(
            ref ActiveTuning tuning,
            CharacterPoseTuningLayoutEntry entry,
            CharacterPoseTuningValue value)
        {
            string fieldId = entry.FieldId;
            if (fieldId.EndsWith("/iterations", StringComparison.Ordinal)) tuning.Iterations = value.IntegerValue;
            else if (fieldId.EndsWith("/fabrik-pass", StringComparison.Ordinal)) tuning.FabrikPass = value.BooleanValue;
            else if (fieldId.EndsWith("/spine-stiffness", StringComparison.Ordinal)) tuning.SpineStiffness = value.FloatValue;
            else if (fieldId.EndsWith("/pull-body-vertical", StringComparison.Ordinal)) tuning.PullBodyVertical = value.FloatValue;
            else if (fieldId.EndsWith("/pull-body-horizontal", StringComparison.Ordinal)) tuning.PullBodyHorizontal = value.FloatValue;
            else if (fieldId.EndsWith("/node-weight", StringComparison.Ordinal)) tuning.NodeWeight = value.FloatValue;
            else
            {
                ActiveLimb limb = Contains(fieldId, "/left-arm/") ? tuning.LeftArm :
                    Contains(fieldId, "/right-arm/") ? tuning.RightArm :
                    Contains(fieldId, "/left-leg/") ? tuning.LeftLeg : tuning.RightLeg;
                ApplyLimbField(ref limb, fieldId, value);
                if (Contains(fieldId, "/left-arm/")) tuning.LeftArm = limb;
                else if (Contains(fieldId, "/right-arm/")) tuning.RightArm = limb;
                else if (Contains(fieldId, "/left-leg/")) tuning.LeftLeg = limb;
                else tuning.RightLeg = limb;
            }
        }

        static void ApplyLimbField(ref ActiveLimb limb, string fieldId, CharacterPoseTuningValue value)
        {
            if (fieldId.EndsWith("/pin", StringComparison.Ordinal)) limb.Pin = value.FloatValue;
            else if (fieldId.EndsWith("/pull", StringComparison.Ordinal)) limb.Pull = value.FloatValue;
            else if (fieldId.EndsWith("/push", StringComparison.Ordinal)) limb.Push = value.FloatValue;
            else if (fieldId.EndsWith("/push-parent", StringComparison.Ordinal)) limb.PushParent = value.FloatValue;
            else if (fieldId.EndsWith("/reach", StringComparison.Ordinal)) limb.Reach = value.FloatValue;
            else if (fieldId.EndsWith("/reach-smoothing", StringComparison.Ordinal)) limb.ReachSmoothing = (CharacterFullBodyIkSmoothing)value.EnumValue;
            else if (fieldId.EndsWith("/push-smoothing", StringComparison.Ordinal)) limb.PushSmoothing = (CharacterFullBodyIkSmoothing)value.EnumValue;
            else if (fieldId.EndsWith("/mapping-weight", StringComparison.Ordinal)) limb.MappingWeight = value.FloatValue;
            else if (fieldId.EndsWith("/maintain-rotation-weight", StringComparison.Ordinal)) limb.MaintainRotationWeight = value.FloatValue;
            else if (fieldId.EndsWith("/bend-constraint-weight", StringComparison.Ordinal)) limb.BendConstraintWeight = value.FloatValue;
            else if (fieldId.EndsWith("/bend-clamp", StringComparison.Ordinal)) limb.BendClamp = value.FloatValue;
        }

        static bool Contains(string value, string part) =>
            value.IndexOf(part, StringComparison.Ordinal) >= 0;

        readonly struct LegSolveFrame
        {
            internal LegSolveFrame(
                Vector3 originalHip,
                Vector3 originalKnee,
                Vector3 originalAnkle,
                Vector3 targetAnkle,
                Vector3 effectiveBendDirection,
                float legLength,
                float animatedBendDirectionPreviousDot,
                float effectiveBendDirectionPreviousDot,
                float stabilizationWeight,
                float effectiveBendWeight,
                bool retainedPreviousBendDirection,
                bool hadStableBendDirection,
                bool hadAppliedBendDirection,
                CharacterFullBodyIkBendDirectionSource bendDirectionSource)
            {
                OriginalHip = originalHip;
                OriginalKnee = originalKnee;
                OriginalAnkle = originalAnkle;
                TargetAnkle = targetAnkle;
                EffectiveBendDirection = effectiveBendDirection;
                LegLength = legLength;
                AnimatedBendDirectionPreviousDot = animatedBendDirectionPreviousDot;
                EffectiveBendDirectionPreviousDot = effectiveBendDirectionPreviousDot;
                StabilizationWeight = stabilizationWeight;
                EffectiveBendWeight = effectiveBendWeight;
                RetainedPreviousBendDirection = retainedPreviousBendDirection;
                HadStableBendDirection = hadStableBendDirection;
                HadAppliedBendDirection = hadAppliedBendDirection;
                BendDirectionSource = bendDirectionSource;
                IsAvailable = true;
            }

            internal Vector3 OriginalHip { get; }
            internal Vector3 OriginalKnee { get; }
            internal Vector3 OriginalAnkle { get; }
            internal Vector3 TargetAnkle { get; }
            internal Vector3 EffectiveBendDirection { get; }
            internal float LegLength { get; }
            internal float AnimatedBendDirectionPreviousDot { get; }
            internal float EffectiveBendDirectionPreviousDot { get; }
            internal float StabilizationWeight { get; }
            internal float EffectiveBendWeight { get; }
            internal bool RetainedPreviousBendDirection { get; }
            internal bool HadStableBendDirection { get; }
            internal bool HadAppliedBendDirection { get; }
            internal CharacterFullBodyIkBendDirectionSource BendDirectionSource { get; }
            internal bool IsAvailable { get; }
        }

        struct ActiveTuning
        {
            internal int Iterations;
            internal bool FabrikPass;
            internal float SpineStiffness;
            internal float PullBodyVertical;
            internal float PullBodyHorizontal;
            internal float NodeWeight;
            internal ActiveLimb LeftArm;
            internal ActiveLimb RightArm;
            internal ActiveLimb LeftLeg;
            internal ActiveLimb RightLeg;

            internal static ActiveTuning FromProfile(CharacterFullBodyIkProfile profile) => new ActiveTuning
            {
                Iterations = profile.Iterations,
                FabrikPass = profile.FabrikPass,
                SpineStiffness = profile.SpineStiffness,
                PullBodyVertical = profile.PullBodyVertical,
                PullBodyHorizontal = profile.PullBodyHorizontal,
                NodeWeight = profile.NodeWeight,
                LeftArm = ActiveLimb.FromProfile(profile.LeftArm),
                RightArm = ActiveLimb.FromProfile(profile.RightArm),
                LeftLeg = ActiveLimb.FromProfile(profile.LeftLeg),
                RightLeg = ActiveLimb.FromProfile(profile.RightLeg)
            };

            internal void RequireValid()
            {
                if (Iterations < 0 || Iterations > 10 ||
                    !IsRange(SpineStiffness, 0f, 1f) ||
                    !IsRange(PullBodyVertical, -1f, 1f) ||
                    !IsRange(PullBodyHorizontal, -1f, 1f) ||
                    !IsRange(NodeWeight, 0f, 1f))
                    throw new InvalidOperationException("Full Body IK tuning values are invalid.");
                LeftArm.RequireValid();
                RightArm.RequireValid();
                LeftLeg.RequireValid();
                RightLeg.RequireValid();
            }
        }

        struct ActiveLimb
        {
            internal float Pin;
            internal float Pull;
            internal float Push;
            internal float PushParent;
            internal float Reach;
            internal CharacterFullBodyIkSmoothing ReachSmoothing;
            internal CharacterFullBodyIkSmoothing PushSmoothing;
            internal float MappingWeight;
            internal float MaintainRotationWeight;
            internal float BendConstraintWeight;
            internal float BendClamp;

            internal static ActiveLimb FromProfile(CharacterFullBodyIkLimbSettings settings) => new ActiveLimb
            {
                Pin = settings.Pin,
                Pull = settings.Pull,
                Push = settings.Push,
                PushParent = settings.PushParent,
                Reach = settings.Reach,
                ReachSmoothing = settings.ReachSmoothing,
                PushSmoothing = settings.PushSmoothing,
                MappingWeight = settings.MappingWeight,
                MaintainRotationWeight = settings.MaintainRotationWeight,
                BendConstraintWeight = settings.BendConstraintWeight,
                BendClamp = settings.BendClamp
            };

            internal void RequireValid()
            {
                if (!IsRange(Pin, 0f, 1f) || !IsRange(Pull, 0f, 1f) ||
                    !IsRange(Push, 0f, 1f) || !IsRange(PushParent, -1f, 1f) ||
                    !IsRange(Reach, 0f, 1f) || !IsRange(MappingWeight, 0f, 1f) ||
                    !IsRange(MaintainRotationWeight, 0f, 1f) ||
                    !IsRange(BendConstraintWeight, 0f, 1f) ||
                    !IsRange(BendClamp, 0f, 1f) ||
                    ReachSmoothing < CharacterFullBodyIkSmoothing.None ||
                    ReachSmoothing > CharacterFullBodyIkSmoothing.Cubic ||
                    PushSmoothing < CharacterFullBodyIkSmoothing.None ||
                    PushSmoothing > CharacterFullBodyIkSmoothing.Cubic)
                    throw new InvalidOperationException("Full Body IK limb tuning values are invalid.");
            }
        }

        static bool IsRange(float value, float minimum, float maximum) =>
            float.IsFinite(value) && value >= minimum && value <= maximum;

        bool IsValidPosePage(NativeSlice<AnimationLocalBonePose> pose)
        {
            if (pose.Length != m_Rig.PoseBoneCount)
                return false;
            for (int i = 0; i < pose.Length; i++)
            {
                if (!pose[i].IsValid)
                    return false;
            }
            return true;
        }

        static FullBodyBipedEffector ToFinalIkEffector(CharacterFullBodyIkEffectorSlot slot)
        {
            switch (slot)
            {
                case CharacterFullBodyIkEffectorSlot.Body: return FullBodyBipedEffector.Body;
                case CharacterFullBodyIkEffectorSlot.LeftShoulder: return FullBodyBipedEffector.LeftShoulder;
                case CharacterFullBodyIkEffectorSlot.RightShoulder: return FullBodyBipedEffector.RightShoulder;
                case CharacterFullBodyIkEffectorSlot.LeftThigh: return FullBodyBipedEffector.LeftThigh;
                case CharacterFullBodyIkEffectorSlot.RightThigh: return FullBodyBipedEffector.RightThigh;
                case CharacterFullBodyIkEffectorSlot.LeftHand: return FullBodyBipedEffector.LeftHand;
                case CharacterFullBodyIkEffectorSlot.RightHand: return FullBodyBipedEffector.RightHand;
                case CharacterFullBodyIkEffectorSlot.LeftFoot: return FullBodyBipedEffector.LeftFoot;
                case CharacterFullBodyIkEffectorSlot.RightFoot: return FullBodyBipedEffector.RightFoot;
                default: throw new ArgumentOutOfRangeException(nameof(slot));
            }
        }

        void CacheEffectors()
        {
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.Body] =
                m_Solver.GetEffector(FullBodyBipedEffector.Body);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.LeftShoulder] =
                m_Solver.GetEffector(FullBodyBipedEffector.LeftShoulder);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.RightShoulder] =
                m_Solver.GetEffector(FullBodyBipedEffector.RightShoulder);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.LeftThigh] =
                m_Solver.GetEffector(FullBodyBipedEffector.LeftThigh);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.RightThigh] =
                m_Solver.GetEffector(FullBodyBipedEffector.RightThigh);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.LeftHand] =
                m_Solver.GetEffector(FullBodyBipedEffector.LeftHand);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.RightHand] =
                m_Solver.GetEffector(FullBodyBipedEffector.RightHand);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.LeftFoot] =
                m_Solver.GetEffector(FullBodyBipedEffector.LeftFoot);
            m_Effectors[(int)CharacterFullBodyIkEffectorSlot.RightFoot] =
                m_Solver.GetEffector(FullBodyBipedEffector.RightFoot);
        }

        static FBIKChain.Smoothing ToFinalIkSmoothing(CharacterFullBodyIkSmoothing smoothing)
        {
            switch (smoothing)
            {
                case CharacterFullBodyIkSmoothing.None: return FBIKChain.Smoothing.None;
                case CharacterFullBodyIkSmoothing.Exponential: return FBIKChain.Smoothing.Exponential;
                case CharacterFullBodyIkSmoothing.Cubic: return FBIKChain.Smoothing.Cubic;
                default: throw new ArgumentOutOfRangeException(nameof(smoothing));
            }
        }
    }
}
