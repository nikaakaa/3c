using System;
using KK.GeneratedDiagnosticSampling;
using UnityEngine;
using Unity.Collections;

namespace ThirdPersonCharacter.Pipeline.Presentation
{
    public enum CharacterFootCurrentSupportProbeState : byte
    {
        Accepted = 1,
        Rejected = 2,
        NotExecuted = 3
    }

    public enum CharacterFootCurrentSupportProbeRejectReason : byte
    {
        None = 0,
        CapacityExceeded = 2,
        NoHit = 3,
        NotGrounded = 4
    }

    public enum CharacterFootCurrentSupportRejectReason : byte
    {
        None = 0,
        NoSupport = 1,
        IncompleteQuery = 2,
        NotGrounded = 3,
        WorldRevisionMismatch = 4
    }

    public enum CharacterFootCurrentSupportSelectionReason : byte
    {
        None = 0,
        HighestRequiredDisplacement = 1,
        EquivalentDisplacementSurfaceIdentity = 2,
        EquivalentDisplacementSampleOrder = 3,
        SingleSampleSupport = 4
    }

    internal readonly struct CharacterFootCurrentSupportProbeRequest
    {
        internal CharacterFootCurrentSupportProbeRequest(
            CharacterFootSide side, int sampleIndex, Vector3 probePosition,
            Vector3 unitComponentUp, in CharacterFootCurrentSupportQuerySettings settings)
        {
            Side = side;
            SampleIndex = sampleIndex;
            ProbePosition = probePosition;
            UnitComponentUp = unitComponentUp;
            Settings = settings;
        }

        internal CharacterFootSide Side { get; }
        internal int SampleIndex { get; }
        internal Vector3 ProbePosition { get; }
        internal Vector3 UnitComponentUp { get; }
        internal readonly CharacterFootCurrentSupportQuerySettings Settings;
        internal int LayerMask => Settings.GroundLayerMask;
        internal float MinimumGroundNormalDot => Settings.MinimumGroundNormalDot;
        internal int HitCapacity => Settings.HitCapacity;
        internal CharacterFootPlacementQueryPurpose Purpose => CharacterFootPlacementQueryPurpose.CurrentSupport;
        internal Vector3 Origin => ProbePosition + UnitComponentUp * Settings.CastAbove;
        internal Vector3 Direction => -UnitComponentUp;
        internal float MaximumDistance => Settings.CastAbove + Settings.CastBelow;
    }

    internal readonly struct CharacterFootCurrentSupportProbeResult
    {
        internal CharacterFootCurrentSupportProbeResult(
            CharacterFootCurrentSupportProbeState state,
            CharacterFootCurrentSupportProbeRejectReason rejectReason,
            CharacterFootSupportQueryDiagnostics coverage,
            int surfaceIdentity, Vector3 point, Vector3 normal,
            float distance, ulong worldRevision)
        {
            State = state;
            RejectReason = rejectReason;
            Coverage = coverage;
            SurfaceIdentity = surfaceIdentity;
            Point = point;
            Normal = normal;
            Distance = distance;
            WorldRevision = worldRevision;
        }

        internal CharacterFootCurrentSupportProbeState State { get; }
        internal CharacterFootCurrentSupportProbeRejectReason RejectReason { get; }
        internal CharacterFootSupportQueryDiagnostics Coverage { get; }
        internal int SurfaceIdentity { get; }
        internal Vector3 Point { get; }
        internal Vector3 Normal { get; }
        internal float Distance { get; }
        internal ulong WorldRevision { get; }
        internal bool Accepted => State == CharacterFootCurrentSupportProbeState.Accepted;

        internal static CharacterFootCurrentSupportProbeResult Rejected(
            CharacterFootCurrentSupportProbeRejectReason reason, ulong worldRevision,
            CharacterFootSupportQueryDiagnostics coverage) =>
            new CharacterFootCurrentSupportProbeResult(
                CharacterFootCurrentSupportProbeState.Rejected, reason, coverage,
                0, default, default, 0f, worldRevision);

        internal static CharacterFootCurrentSupportProbeResult NotGrounded(ulong worldRevision) =>
            new CharacterFootCurrentSupportProbeResult(
                CharacterFootCurrentSupportProbeState.NotExecuted,
                CharacterFootCurrentSupportProbeRejectReason.NotGrounded, default,
                0, default, default, 0f, worldRevision);
    }

    internal readonly struct CharacterFootSoleProbeObservation
    {
        internal CharacterFootSoleProbeObservation(Vector3 position, in CharacterFootCurrentSupportProbeResult result)
        {
            Position = position;
            Result = result;
        }

        internal readonly Vector3 Position;
        internal readonly CharacterFootCurrentSupportProbeResult Result;
    }

    internal sealed class CharacterFootSoleProbeBuffer
    {
        FixedList4096Bytes<CharacterFootSoleProbeObservation> m_Values;

        internal int Count => m_Values.Length;
        internal CharacterFootSoleProbeObservation this[int index] => m_Values[index];
        internal void Clear() => m_Values.Clear();
        internal void Add(in CharacterFootSoleProbeObservation value) => m_Values.Add(value);
    }

    internal readonly struct CharacterFootCurrentSupportObservation
    {
        internal const float SelectionEpsilon = 0.0001f;
        readonly CharacterFootSoleProbeBuffer m_Probes;
        readonly CharacterFootCurrentSupportQuerySettings m_Settings;
        readonly Vector3 m_UnitUp;

        internal CharacterFootCurrentSupportObservation(
            ulong frameSequence, ulong completionIdentity, CharacterFootSide side,
            ulong worldRevision, Vector3 unitUp,
            in CharacterFootCurrentSupportQuerySettings settings,
            CharacterFootSoleProbeBuffer probes,
            CharacterFootCurrentSupportRejectReason rejectReason,
            int acceptedSampleCount, float requiredDisplacement, int selectedSampleIndex,
            CharacterFootCurrentSupportSelectionReason selectionReason,
            in CharacterFootSupportTarget target)
        {
            FrameSequence = frameSequence;
            CompletionIdentity = completionIdentity;
            Side = side;
            WorldRevision = worldRevision;
            m_UnitUp = unitUp;
            m_Settings = settings;
            m_Probes = probes;
            RejectReason = rejectReason;
            AcceptedSampleCount = acceptedSampleCount;
            RequiredDisplacement = requiredDisplacement;
            SelectedSampleIndex = selectedSampleIndex;
            SelectionReason = selectionReason;
            Target = target;
        }

        internal ulong FrameSequence { get; }
        internal ulong CompletionIdentity { get; }
        internal CharacterFootSide Side { get; }
        internal ulong WorldRevision { get; }
        internal int SampleCount => IsSpecified ? m_Probes.Count : 0;
        internal int AcceptedSampleCount { get; }
        internal CharacterFootCurrentSupportRejectReason RejectReason { get; }
        internal float RequiredDisplacement { get; }
        internal int SelectedSampleIndex { get; }
        internal CharacterFootCurrentSupportSelectionReason SelectionReason { get; }
        internal readonly CharacterFootSupportTarget Target;
        internal bool IsSpecified => FrameSequence != 0;
        internal bool Available => IsSpecified && RejectReason == CharacterFootCurrentSupportRejectReason.None;

        internal CharacterFootCurrentSupportProbeDiagnostics GetProbe(int index)
        {
            CharacterFootSoleProbeObservation probe = m_Probes[index];
            var request = new CharacterFootCurrentSupportProbeRequest(Side, index, probe.Position, m_UnitUp, in m_Settings);
            return new CharacterFootCurrentSupportProbeDiagnostics(in request, in probe.Result);
        }

        internal bool TryResolveHeightConstraint(out float displacement, out int surfaceIdentity)
        {
            displacement = RequiredDisplacement;
            surfaceIdentity = Target.SurfaceIdentity;
            return Available;
        }
    }

    public readonly struct CharacterFootCurrentSupportProbeDiagnostics
    {
        internal CharacterFootCurrentSupportProbeDiagnostics(
            in CharacterFootCurrentSupportProbeRequest request,
            in CharacterFootCurrentSupportProbeResult result)
        {
            SampleIndex = request.SampleIndex;
            State = result.State;
            RejectReason = result.RejectReason;
            ProbePosition = request.ProbePosition;
            Origin = request.Origin;
            Direction = request.Direction;
            MaximumDistance = request.MaximumDistance;
            LayerMask = request.LayerMask;
            MinimumGroundNormalDot = request.MinimumGroundNormalDot;
            HitCapacity = request.HitCapacity;
            Coverage = result.Coverage;
            SurfaceIdentity = result.SurfaceIdentity;
            Point = result.Point;
            Normal = result.Normal;
            Distance = result.Distance;
            WorldRevision = result.WorldRevision;
            RequiredDisplacement = result.Accepted
                ? Vector3.Dot(result.Point - request.ProbePosition, request.UnitComponentUp) : 0f;
        }

        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public int SampleIndex { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public CharacterFootCurrentSupportProbeState State { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public CharacterFootCurrentSupportProbeRejectReason RejectReason { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public Vector3 ProbePosition { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public Vector3 Origin { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public Vector3 Direction { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public float MaximumDistance { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public int LayerMask { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public float MinimumGroundNormalDot { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public int HitCapacity { get; }
        public CharacterFootSupportQueryDiagnostics Coverage { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public int SurfaceIdentity { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public Vector3 Point { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public Vector3 Normal { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public float Distance { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public ulong WorldRevision { get; }
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public bool RaycastExecuted => State != CharacterFootCurrentSupportProbeState.NotExecuted;
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public bool Accepted => State == CharacterFootCurrentSupportProbeState.Accepted;
        [DiagnosticField] [DiagnosticGroup("current-support-probe")]
        public float RequiredDisplacement { get; }
    }

    public readonly struct CharacterFootCurrentSupportDiagnostics
    {
        readonly CharacterFootCurrentSupportObservation m_Observation;

        internal CharacterFootCurrentSupportDiagnostics(in CharacterFootCurrentSupportObservation observation)
        {
            m_Observation = observation;
            Target = new CharacterFootSupportTargetDiagnostics(in observation.Target);
        }

        [DiagnosticField] [DiagnosticGroup("current-support")]
        public ulong FrameSequence => m_Observation.FrameSequence;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public ulong CompletionIdentity => m_Observation.CompletionIdentity;
        public CharacterFootSide Side => m_Observation.Side;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public ulong WorldRevision => m_Observation.WorldRevision;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public bool IsSpecified => m_Observation.IsSpecified;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public bool Available => m_Observation.Available;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public CharacterFootCurrentSupportRejectReason RejectReason => m_Observation.RejectReason;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public int SampleCount => m_Observation.SampleCount;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public int AcceptedSampleCount => m_Observation.AcceptedSampleCount;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public float RequiredDisplacement => m_Observation.RequiredDisplacement;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public int SelectedSampleIndex => m_Observation.SelectedSampleIndex;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public CharacterFootCurrentSupportSelectionReason SelectionReason => m_Observation.SelectionReason;
        [DiagnosticField] [DiagnosticGroup("current-support")]
        public float SelectionEpsilon => CharacterFootCurrentSupportObservation.SelectionEpsilon;
        public CharacterFootSupportTargetDiagnostics Target { get; }
        public CharacterFootCurrentSupportProbeDiagnostics GetProbe(int index) => m_Observation.GetProbe(index);
        public CharacterFootCurrentSupportProbePage Probes => new CharacterFootCurrentSupportProbePage(in m_Observation);
    }

    public readonly struct CharacterFootCurrentSupportProbePage
    {
        readonly CharacterFootCurrentSupportObservation m_Observation;

        internal CharacterFootCurrentSupportProbePage(in CharacterFootCurrentSupportObservation observation)
        {
            m_Observation = observation;
        }

        public int Count => m_Observation.SampleCount;
        public CharacterFootCurrentSupportProbeDiagnostics this[int index] => m_Observation.GetProbe(index);
    }

    internal interface ICharacterFootCurrentSupportWorldQuery
    {
        CharacterFootCurrentSupportProbeResult Query(
            in CharacterFootCurrentSupportProbeRequest request);

        bool QueryMotion(
            Vector3 origin, Vector3 destination, Vector3 unitComponentUp,
            in CharacterFootCurrentSupportQuerySettings settings,
            out Vector3 point, out Vector3 normal);
    }

    internal sealed class CharacterFootCurrentSupportObservationPage
    {
        CharacterFootCurrentSupportObservation m_Observation;
        internal readonly CharacterFootSoleProbeBuffer Probes = new();

        internal bool HasValue { get; private set; }
        internal ref readonly CharacterFootCurrentSupportObservation Observation =>
            ref m_Observation;

        internal void Set(in CharacterFootCurrentSupportObservation observation)
        {
            if (!observation.IsSpecified)
                throw new ArgumentException("Current Support observation is invalid.");
            HasValue = true;
            m_Observation = observation;
        }

        internal void Clear()
        {
            HasValue = false;
            m_Observation = default;
        }
    }

    internal sealed class CharacterFootCurrentSupportObservationPagePool
    {
        readonly CharacterFootCurrentSupportObservationPage m_First = new();
        readonly CharacterFootCurrentSupportObservationPage m_Second = new();

        internal CharacterFootCurrentSupportObservationPage AcquireWritable(
            CharacterFootCurrentSupportObservationPage committed)
        {
            CharacterFootCurrentSupportObservationPage pending =
                ReferenceEquals(committed, m_First) ? m_Second : m_First;
            pending.Clear();
            return pending;
        }

        internal static void Discard(
            CharacterFootCurrentSupportObservationPage pending,
            CharacterFootCurrentSupportObservationPage committed)
        {
            if (pending != null && !ReferenceEquals(pending, committed))
                pending.Clear();
        }

        internal void Reset()
        {
            m_First.Clear();
            m_Second.Clear();
        }
    }
    internal readonly struct CharacterFootSoleSupportQuery
    {
        readonly ICharacterFootCurrentSupportWorldQuery m_World;
        readonly CharacterFootCurrentSupportQuerySettings m_Settings;

        internal CharacterFootSoleSupportQuery(
            ICharacterFootCurrentSupportWorldQuery world,
            in CharacterFootCurrentSupportQuerySettings settings)
        {
            m_World = world;
            m_Settings = settings;
        }

        internal Vector3 ConstrainMotion(
            in CharacterFootPlacementSoleContactPose contacts,
            in FixedList512Bytes<Vector3> previousOutput,
            Vector3 unitComponentUp,
            Vector3 ankle, Vector3 hip, float maximumLegDistance)
        {
            Vector3 adjustment = default;
            for (int i = 0; i < previousOutput.Length; i++)
            {
                Vector3 origin = previousOutput[i];
                Vector3 destination = contacts.SoleSamples[i] + adjustment;
                if (!m_World.QueryMotion(origin, destination, unitComponentUp, in m_Settings,
                        out Vector3 point, out Vector3 normal))
                    continue;
                Vector3 planarNormal = Vector3.ProjectOnPlane(normal, unitComponentUp);
                float penetration = Vector3.Dot(point - destination, normal);
                if (penetration > 0f)
                {
                    adjustment += planarNormal * ((penetration + CharacterFootConstraintMath.GeometryEpsilon) /
                        planarNormal.sqrMagnitude);
                    Vector3 hipOffset = ankle + adjustment - hip;
                    if (hipOffset.sqrMagnitude > maximumLegDistance * maximumLegDistance)
                    {
                        Vector3 fixedOffset = unitComponentUp * Vector3.Dot(hipOffset, unitComponentUp) +
                            Vector3.Project(hipOffset, planarNormal);
                        Vector3 tangent = hipOffset - fixedOffset;
                        float tangentRadius = Mathf.Sqrt(Mathf.Max(0f,
                            maximumLegDistance * maximumLegDistance - fixedOffset.sqrMagnitude));
                        adjustment += Vector3.ClampMagnitude(tangent, tangentRadius) - tangent;
                    }
                }
            }
            return adjustment;
        }

        internal CharacterFootCurrentSupportObservation Query(
            ulong frameSequence, ulong completionIdentity, ulong worldRevision,
            CharacterFootSide side, Vector3 componentUp, bool grounded,
            in CharacterFootPlacementSoleContactPose contacts,
            CharacterFootSoleProbeBuffer probes)
        {
            Vector3 up = componentUp.normalized;
            probes.Clear();
            int acceptedCount = 0;
            float displacement = float.NegativeInfinity;
            CharacterFootCurrentSupportRejectReason rejection = grounded
                ? CharacterFootCurrentSupportRejectReason.None : CharacterFootCurrentSupportRejectReason.NotGrounded;
            for (int i = 0; i < contacts.SoleSamples.Length; i++)
            {
                Vector3 position = contacts.SoleSamples[i];
                var request = new CharacterFootCurrentSupportProbeRequest(side, i, position, up, in m_Settings);
                CharacterFootCurrentSupportProbeResult result = grounded
                    ? m_World.Query(in request) : CharacterFootCurrentSupportProbeResult.NotGrounded(worldRevision);
                probes.Add(new CharacterFootSoleProbeObservation(position, in result));
                if (result.WorldRevision != worldRevision)
                    rejection = CharacterFootCurrentSupportRejectReason.WorldRevisionMismatch;
                else if (result.RejectReason == CharacterFootCurrentSupportProbeRejectReason.CapacityExceeded)
                    rejection = CharacterFootCurrentSupportRejectReason.IncompleteQuery;
                if (result.Accepted)
                {
                    acceptedCount++;
                    displacement = Mathf.Max(displacement, Vector3.Dot(result.Point - position, up));
                }
            }
            if (acceptedCount == 0 && rejection == CharacterFootCurrentSupportRejectReason.None)
                rejection = CharacterFootCurrentSupportRejectReason.NoSupport;

            int selected = -1;
            var reason = CharacterFootCurrentSupportSelectionReason.None;
            CharacterFootSupportTarget target = default;
            if (rejection == CharacterFootCurrentSupportRejectReason.None)
            {
                reason = acceptedCount == 1
                    ? CharacterFootCurrentSupportSelectionReason.SingleSampleSupport
                    : CharacterFootCurrentSupportSelectionReason.HighestRequiredDisplacement;
                for (int i = 0; i < probes.Count; i++)
                {
                    CharacterFootSoleProbeObservation probe = probes[i];
                    if (!probe.Result.Accepted ||
                        displacement - Vector3.Dot(probe.Result.Point - probe.Position, up) >
                        CharacterFootCurrentSupportObservation.SelectionEpsilon)
                        continue;
                    if (selected < 0)
                        selected = i;
                    else
                    {
                        int previousIdentity = probes[selected].Result.SurfaceIdentity;
                        if (probe.Result.SurfaceIdentity != previousIdentity)
                            reason = CharacterFootCurrentSupportSelectionReason.EquivalentDisplacementSurfaceIdentity;
                        else if (reason != CharacterFootCurrentSupportSelectionReason.EquivalentDisplacementSurfaceIdentity)
                            reason = CharacterFootCurrentSupportSelectionReason.EquivalentDisplacementSampleOrder;
                        if (probe.Result.SurfaceIdentity < previousIdentity)
                            selected = i;
                    }
                }
                CharacterFootCurrentSupportProbeResult support = probes[selected].Result;
                Vector3 originalSole = (contacts.HeelPosition + contacts.ToePosition) * 0.5f;
                target = new CharacterFootSupportTarget(
                    frameSequence, completionIdentity, side, originalSole + up * displacement,
                    support.Normal, support.SurfaceIdentity, worldRevision,
                    CharacterFootSupportTargetKind.CurrentSupport,
                    CharacterFootSupportPositionSource.CurrentSupport, frameSequence, completionIdentity, 0, 0,
                    CharacterFootSupportNormalSource.CurrentSupport, frameSequence, completionIdentity, 0);
            }
            return new CharacterFootCurrentSupportObservation(
                frameSequence, completionIdentity, side, worldRevision, up, in m_Settings, probes,
                rejection, acceptedCount, acceptedCount > 0 ? displacement : 0f, selected, reason, in target);
        }
    }
}
