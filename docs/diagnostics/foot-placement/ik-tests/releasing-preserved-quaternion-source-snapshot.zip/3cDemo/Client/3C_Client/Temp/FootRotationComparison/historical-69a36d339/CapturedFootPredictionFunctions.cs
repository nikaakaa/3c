using System;
using UnityEngine;
using ThirdPersonCharacter.Pipeline.Animation;
using ThirdPersonCharacter.Pipeline.Presentation;
using ThirdPersonSimulation;
namespace ThirdPersonCharacter.Pipeline.Editor { internal sealed class CapturedFootPredictionFunctions {

        readonly CharacterFootPlacementModuleSettings m_Settings;
        readonly ICharacterFootPlacementWorldQuery m_WorldQuery;
        readonly ICharacterFutureBodyTranslationSource m_FutureBodyTranslationSource;
        readonly ActorId m_ActorId;
        internal CapturedFootPredictionFunctions(CharacterFootPlacementModuleSettings settings, ICharacterFootPlacementWorldQuery world, ICharacterFutureBodyTranslationSource future, ActorId actor) { m_Settings=settings; m_WorldQuery=world; m_FutureBodyTranslationSource=future; m_ActorId=actor; }
        internal CharacterFootGroundPathResult PrepareGroundPath(
            CharacterFootSide side,
            bool hasLastLanding,
            in CharacterFootGroundPathLanding lastLanding,
            bool hasNextSwingLanding,
            in CharacterFootGroundPathLanding nextSwingLanding,
            Vector3 componentUp,
            ulong authorityTick,
            CharacterFootGroundPathPagePool pool,
            CharacterFootGroundPathPage committedPage,
            out CharacterFootGroundPathPage pendingPage)
        {
            if (!hasLastLanding)
            {
                pendingPage = pool.AcquireWritable(committedPage);
                pendingPage.SetRejected(
                    CharacterFootGroundPathRejectReason.CurrentLandingUnavailable,
                    false,
                    0,
                    default,
                    default);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }
            if (!hasNextSwingLanding)
            {
                pendingPage = pool.AcquireWritable(committedPage);
                pendingPage.SetRejected(
                    CharacterFootGroundPathRejectReason.NextLandingUnavailable,
                    false, 0, default, default);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }

            CharacterFootGroundPathInputKey key =
                CharacterFootGroundPathInputBuilder.BuildKey(
                    side,
                    in lastLanding,
                    in nextSwingLanding,
                    authorityTick,
                    componentUp,
                    m_Settings.ProfileRevision);
            if (committedPage != null &&
                committedPage.HasInput &&
                committedPage.State == CharacterFootGroundPathState.Accepted &&
                committedPage.Input.Key.Equals(key))
            {
                pendingPage = CharacterFootGroundPathPagePool.ReuseCommitted(committedPage);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }

            pendingPage = pool.AcquireWritable(committedPage);
            ref readonly CharacterFootGroundDetectionSettings settings =
                ref m_Settings.GroundDetection;
            if (!CharacterFootGroundPathInputBuilder.TryBuild(
                    in key,
                    lastLanding.Point,
                    nextSwingLanding.Point,
                    lastLanding.Normal,
                    nextSwingLanding.Normal,
                    lastLanding.SurfaceIdentity,
                    nextSwingLanding.SurfaceIdentity,
                    componentUp,
                    in settings,
                    out CharacterFootGroundPathInput input))
            {
                pendingPage.SetRejected(
                    CharacterFootGroundPathRejectReason.InvalidRequest,
                    false, 0, default, default);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }

            CharacterFootGroundPathQueryResult result = m_WorldQuery.Query(
                in input.Query,
                pendingPage.Contacts);
            if (result.Accepted)
            {
                if (CharacterFootGroundEnvelopeBuilder.TryBuild(
                        in input,
                        pendingPage.Contacts,
                        pool.EnvelopeWorkspace,
                        pendingPage.Edges,
                        pendingPage.Envelope,
                        out CharacterFootGroundPathRejectReason envelopeRejectReason,
                        out CharacterFootGroundInvalidSegment invalidSegment))
                {
                    pendingPage.SetAccepted(result.SegmentCount, in input);
                }
                else
                {
                    pendingPage.SetRejected(
                        envelopeRejectReason, true, result.SegmentCount,
                        in input, in invalidSegment);
                }
            }
            else
                pendingPage.SetRejected(
                    result.RejectReason, true, result.SegmentCount,
                    in input, default);
            return new CharacterFootGroundPathResult(pendingPage, true);
        }

        internal CharacterFootLandingPredictionPair PredictFootPair(
            CharacterFootSide side,
            in AnimationFootMotionRuntimeSample footMotion,
            in CharacterFootPlacementAnimatedFootPose animatedFoot,
            bool hasMotionTimeline,
            ulong trajectoryGeneration,
            CharacterFutureBodyTranslation bodyTrajectory,
            in CapturedPredictionFrame frame,
            in CharacterFootLandingSnapshot landingSnapshot,
            bool plantVerificationRequired,
            CharacterFootLandingObservationPagePool observationPool,
            CharacterFootLandingObservationPage committedObservation,
            out CharacterFootLandingObservationPage pendingObservation)
        {
            pendingObservation = committedObservation;
            Vector3 currentSole =
                (animatedFoot.HeelPosition + animatedFoot.ToePosition) * 0.5f;
            ref readonly AnimationFootMotionEventFrame events =
                ref footMotion.Events;
            ref readonly AnimationFootMotionEventOccurrence current =
                ref events.CurrentContact;
            ref readonly AnimationFootMotionEventOccurrence next =
                ref events.NextLanding;
            bool hasNextCandidate = IsPredictiveLanding(
                in footMotion,
                in next,
                landingSnapshot.LastLandingEventIdentity,
                m_Settings.LandingPrediction.MaximumPredictionTimeSeconds);
            CharacterFootLandingStepSource selectedSource;
            CharacterFootLandingPredictionResult selected;
            if (plantVerificationRequired)
            {
                selectedSource = CharacterFootLandingStepSource.FormalCurrentContact;
                selected = PredictEvent(
                    side,
                    in footMotion,
                    in current,
                    selectedSource,
                    0f,
                    true,
                    animatedFoot,
                    hasMotionTimeline,
                    trajectoryGeneration,
                    bodyTrajectory,
                    in frame,
                    observationPool,
                    committedObservation,
                    out pendingObservation);
            }
            else if (hasNextCandidate)
            {
                selectedSource = CharacterFootLandingStepSource.FormalNextLanding;
                selected = PredictEvent(
                    side,
                    in footMotion,
                    in next,
                    selectedSource,
                    events.TimeToLandingSeconds,
                    false,
                    animatedFoot,
                    hasMotionTimeline,
                    trajectoryGeneration,
                    bodyTrajectory,
                    in frame,
                    observationPool,
                    committedObservation,
                    out pendingObservation);
            }
            else
            {
                selectedSource = CharacterFootLandingStepSource.None;
                selected = RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.StepUnavailable,
                    selectedSource,
                    in next,
                    events.TimeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            return new CharacterFootLandingPredictionPair(
                selected,
                selectedSource);
        }

        static bool IsPredictiveLanding(
            in AnimationFootMotionRuntimeSample footMotion,
            in AnimationFootMotionEventOccurrence next,
            ulong lastLandingEventIdentity,
            float maximumPredictionTimeSeconds) =>
            footMotion.IsValid &&
            footMotion.HasPredictiveLanding &&
            next.IsBound &&
            footMotion.TimeToLandingSeconds > 0.000001f &&
            footMotion.TimeToLandingSeconds <= maximumPredictionTimeSeconds &&
            next.Identity != lastLandingEventIdentity;

        CharacterFootLandingPredictionResult PredictEvent(
            CharacterFootSide side,
            in AnimationFootMotionRuntimeSample footMotion,
            in AnimationFootMotionEventOccurrence landingEvent,
            CharacterFootLandingStepSource stepSource,
            float timeToLandingSeconds,
            bool currentContact,
            in CharacterFootPlacementAnimatedFootPose animatedFoot,
            bool hasMotionTimeline,
            ulong trajectoryGeneration,
            CharacterFutureBodyTranslation bodyTrajectory,
            in CapturedPredictionFrame frame,
            CharacterFootLandingObservationPagePool observationPool,
            CharacterFootLandingObservationPage committedObservation,
            out CharacterFootLandingObservationPage pendingObservation)
        {
            Vector3 currentSole = CharacterFootConstraintMath.ResolveOriginalSole(animatedFoot);
            ref readonly CapturedPredictionBody body = ref frame.Body;
            pendingObservation = committedObservation;
            if (!footMotion.IsValid)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.StepUnavailable,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            if (!landingEvent.IsBound)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.StepIdentityMismatch,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            ref readonly CharacterFootLandingPredictionSettings settings =
                ref m_Settings.LandingPrediction;
            if (!float.IsFinite(timeToLandingSeconds) ||
                timeToLandingSeconds < 0f ||
                timeToLandingSeconds > settings.MaximumPredictionTimeSeconds)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.LandingTimeInvalid,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            if (!currentContact && !hasMotionTimeline && bodyTrajectory == null)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.MotionTimelineUnavailable,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    0,
                    currentSole,
                    default,
                    default);
            }
            bool requiresFutureBodyTranslation =
                !currentContact && timeToLandingSeconds > 0.000001f;
            if (requiresFutureBodyTranslation && bodyTrajectory == null)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.FutureBodyTranslationUnavailable,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            if (requiresFutureBodyTranslation &&
                bodyTrajectory.DurationSeconds + 0.0001f < timeToLandingSeconds)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.FutureBodyTranslationRangeInvalid,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }

            CharacterFutureBodyTranslationSample bodyTranslation =
                bodyTrajectory != null
                    ? bodyTrajectory.Evaluate(timeToLandingSeconds)
                    : default;
            Vector3 rawLanding = currentContact
                ? currentSole
                : CharacterFootLandingPredictor.ProjectRawLanding(
                    body.VisiblePosition,
                    body.VisibleRotation,
                    in bodyTranslation,
                    landingEvent.RootLocalLanding);
            Vector3 componentUp = body.VisibleRotation * Vector3.up;
            CharacterFootLandingObservationRefreshMode refreshMode =
                currentContact
                    ? CharacterFootLandingObservationRefreshMode
                        .ForcedPlantVerification
                    : footMotion.InApproachContactToLanding ||
                      footMotion.LockMode == AnimationFootStepObservationLockMode.Sliding
                        ? CharacterFootLandingObservationRefreshMode
                            .ChangedContactApproachInput
                        : CharacterFootLandingObservationRefreshMode.Thresholded;
            CharacterFootLandingObservationResult observation =
                CharacterFootLandingPredictor.ResolveObservation(
                    side,
                    landingEvent.Identity,
                    landingEvent.SourceSampleIdentity,
                    landingEvent.LandingCycle,
                    rawLanding,
                    componentUp,
                    refreshMode,
                    m_Settings.ProfileRevision,
                    in settings,
                    m_WorldQuery,
                    observationPool,
                    committedObservation,
                    out pendingObservation,
                    currentContact ? animatedFoot.HeelPosition - currentSole : default,
                    currentContact ? animatedFoot.ToePosition - currentSole : default);
            CharacterFootLandingObservationPage observationPage =
                observation.Page;
            ref readonly CharacterFootLandingQueryResult queryResult =
                ref observationPage.Result;
            bool accepted = queryResult.Accepted;
            CharacterFootLandingQueryRejectReason queryRejectReason =
                queryResult.RejectReason;
            var observationDiagnostics =
                new CharacterFootLandingObservationDiagnostics(in observation);
            return new CharacterFootLandingPredictionResult(
                side,
                accepted
                    ? CharacterFootLandingPredictionState.Accepted
                    : CharacterFootLandingPredictionState.Rejected,
                accepted
                    ? CharacterFootLandingPredictionRejectReason.None
                    : queryRejectReason ==
                      CharacterFootLandingQueryRejectReason.CapacityExceeded
                        ? CharacterFootLandingPredictionRejectReason
                            .GroundQueryCapacityExceeded
                        : CharacterFootLandingPredictionRejectReason
                            .GroundQueryMissed,
                stepSource,
                landingEvent.Identity,
                trajectoryGeneration,
                1f,
                timeToLandingSeconds,
                landingEvent.RootLocalLanding,
                bodyTrajectory != null,
                bodyTrajectory != null
                    ? bodyTrajectory.SourceIdentity
                    : string.Empty,
                in bodyTranslation,
                currentSole,
                rawLanding,
                in observationDiagnostics,
                in observationPage.Query,
                in queryResult.Support,
                in queryResult.SelectionDiagnostics);
        }

        static CharacterFootLandingPredictionResult RejectedEvent(
            CharacterFootSide side,
            CharacterFootLandingPredictionRejectReason reason,
            CharacterFootLandingStepSource stepSource,
            in AnimationFootMotionEventOccurrence landingEvent,
            float timeToLandingSeconds,
            ulong trajectoryGeneration,
            Vector3 currentSole,
            Vector3 rawLanding,
            CharacterFootPlacementQueryRequest query) =>
            new CharacterFootLandingPredictionResult(
                side,
                CharacterFootLandingPredictionState.Rejected,
                reason,
                stepSource,
                landingEvent.IsBound ? landingEvent.Identity : 0,
                trajectoryGeneration,
                landingEvent.IsBound ? 1f : 0f,
                landingEvent.IsBound && float.IsFinite(timeToLandingSeconds)
                    ? Mathf.Max(0f, timeToLandingSeconds)
                    : 0f,
                landingEvent.IsBound
                    ? landingEvent.RootLocalLanding
                    : default,
                false,
                string.Empty,
                default,
                currentSole,
                rawLanding,
                default,
                in query,
                default,
                default);

        internal CharacterFutureBodyTranslation ResolveBodyTrajectory(
            CharacterFootPlacementBank bank,
            in AnimationFootMotionRuntimeSample leftFootMotion,
            in AnimationFootMotionRuntimeSample rightFootMotion,
            in CapturedPredictionTimeline timeline,
            float currentSegmentRemainingSeconds,
            float presentationDeltaSeconds,
            in CapturedPredictionBody body)
        {
            ref readonly CharacterFootLandingPredictionSettings settings =
                ref m_Settings.LandingPrediction;
            Vector2 rawCurrentVelocity = new Vector2(
                body.TargetVelocity.x,
                body.TargetVelocity.z);
            Vector2 rawContinuationVelocity = timeline.IsValid
                ? new Vector2(
                    timeline.ContinuationVelocityX,
                    timeline.ContinuationVelocityZ)
                : default;
            string predictionSourceIdentity =
                m_FutureBodyTranslationSource?.PredictionSourceIdentity ??
                string.Empty;
            CharacterFootPredictionMotionResult predictionMotion =
                CharacterFootPredictionMotionRuntime.Evaluate(
                    ref bank.PredictionMotion,
                    timeline.IsValid,
                    timeline.IsValid ? timeline.Generation : 0,
                    body.ResetSequence,
                    predictionSourceIdentity,
                    rawCurrentVelocity,
                    rawContinuationVelocity,
                    presentationDeltaSeconds,
                    in settings);
            bank.PredictionMotionResult = predictionMotion;
            float maximum = m_Settings.LandingPrediction.MaximumPredictionTimeSeconds;
            float leftTime = ResolvePredictionTime(
                in leftFootMotion, maximum);
            float rightTime = ResolvePredictionTime(
                in rightFootMotion, maximum);
            float duration = Mathf.Max(leftTime, rightTime);
            if (!predictionMotion.IsValid ||
                m_FutureBodyTranslationSource == null)
            {
                bank.BodyTrajectory.Clear();
                bank.HasBodyTrajectoryAttempt = false;
                bank.BodyTrajectoryPredictionMotionRevision = 0;
                return null;
            }
            if (duration <= 0f)
            {
                return null;
            }

            bool sameCommittedBody = bank.HasBodyTrajectoryAttempt &&
                                     bank.BodyTrajectoryTick == body.CurrentTick &&
                                     bank.BodyTrajectoryResetSequence == body.ResetSequence &&
                                     bank.BodyTrajectoryGeneration == timeline.Generation &&
                                     bank.BodyTrajectoryAuthorityTick == timeline.AuthorityTick.Value &&
                                     bank.BodyTrajectoryPredictionMotionRevision ==
                                     predictionMotion.Revision;
            if (sameCommittedBody &&
                duration <= bank.BodyTrajectoryRequestedDuration + 0.0001f)
            {
                return bank.BodyTrajectory.IsAvailable
                    ? bank.BodyTrajectory
                    : null;
            }

            bank.HasBodyTrajectoryAttempt = true;
            bank.BodyTrajectoryTick = body.CurrentTick;
            bank.BodyTrajectoryResetSequence = body.ResetSequence;
            bank.BodyTrajectoryGeneration = timeline.Generation;
            bank.BodyTrajectoryAuthorityTick = timeline.AuthorityTick.Value;
            bank.BodyTrajectoryPredictionMotionRevision =
                predictionMotion.Revision;
            bank.BodyTrajectoryRequestedDuration = duration;
            bank.BodyTrajectory.Clear();

            var request = new CharacterFutureBodyTranslationRequest(
                m_ActorId,
                duration,
                predictionMotion.StableCurrentVelocity.x,
                predictionMotion.StableCurrentVelocity.y,
                predictionMotion.StableContinuationVelocity.x,
                predictionMotion.StableContinuationVelocity.y,
                currentSegmentRemainingSeconds,
                timeline.HasContinuation,
                leftTime,
                0f,
                rightTime,
                0f);
            if (m_FutureBodyTranslationSource.TryPredict(
                    in request,
                    bank.BodyTrajectory))
                return bank.BodyTrajectory;
            return null;
        }

        static float ResolvePredictionTime(
            in AnimationFootMotionRuntimeSample step,
            float maximum) =>
            step.IsAuthoritative && step.HasConsistentLandingEventIdentity &&
            step.TimeToLandingSeconds > 0.000001f &&
            step.TimeToLandingSeconds <= maximum
                ? step.TimeToLandingSeconds
                : 0f;


}}