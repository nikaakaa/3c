using UnityEngine;
using ThirdPersonCharacter.Pipeline.Animation;
using ThirdPersonCharacter.Pipeline.Presentation;
namespace ThirdPersonCharacter.Pipeline.Editor { internal static class CapturedFootModuleFunctions {
        internal static CharacterFootGoalOwnershipLossReason ResolveFootGoalOwnershipLoss(
            bool grounded,
            bool authoritative)
        {
            CharacterFootGoalOwnershipLossReason reason =
                CharacterFootGoalOwnershipLossReason.None;
            if (!grounded)
                reason |= CharacterFootGoalOwnershipLossReason.Ungrounded;
            if (!authoritative)
            {
                reason |= CharacterFootGoalOwnershipLossReason
                    .SourceLineageInvalidated;
            }
            return reason;
        }
        internal static CharacterFullBodyIkGoal CreatePelvisGoal(
            in CharacterFootStrideHipsResult strideHips,
            Transform poseRoot)
        {
            Vector3 translation = default;
            float weight = 0f;
            if (strideHips.ProducesPelvisGoal && poseRoot != null)
            {
                translation = poseRoot.InverseTransformVector(strideHips.PelvisDelta);
                weight = strideHips.PositionWeight;
            }
            return new CharacterFullBodyIkGoal(
                CharacterFullBodyIkEffectorSlot.PelvisPreSolveTranslation,
                translation,
                Quaternion.identity,
                weight,
                0f,
                CharacterFullBodyIkGoalApplication.PelvisPreSolveTranslation,
                CharacterFullBodyIkGoalSourceKind.FootPlacement,
                -1);
        }
        internal static CharacterFullBodyIkGoal EncodeFootGoal(in CharacterResolvedFootResult result)
        {
            ref readonly CharacterFootGoalTarget target = ref result.GoalTarget;
            return new CharacterFullBodyIkGoal(
                result.Identity.Side == CharacterFootSide.Left
                    ? CharacterFullBodyIkEffectorSlot.LeftFoot
                    : CharacterFullBodyIkEffectorSlot.RightFoot,
                target.ComponentPosition,
                target.ComponentRotation,
                target.PositionWeight,
                target.RotationWeight,
                CharacterFullBodyIkGoalApplication.FootPlacementEffectorTarget,
                CharacterFullBodyIkGoalSourceKind.FootPlacement,
                -1);
        }
}}