using System;
using ThirdPersonCharacter.Pipeline.Animation;
using ThirdPersonSimulation;
using Unity.Collections;
using UnityEngine;

namespace ThirdPersonCharacter.Pipeline.Presentation
{
    internal sealed class CharacterFootPlacementDiagnosticsPage
    {
        CharacterFootLandingPredictionDiagnostics m_Value;

        internal bool HasValue => m_Value.FrameSequence != 0;
        internal ref readonly CharacterFootLandingPredictionDiagnostics Value =>
            ref m_Value;

        internal void Set(in CharacterFootLandingPredictionDiagnostics value) =>
            m_Value = value;

        internal void Clear() => m_Value = default;
    }

    internal sealed class CharacterFootPlacementBank
    {
        internal CharacterFootLifecycleContext LeftFoot;
        internal CharacterFootLifecycleContext RightFoot;
        internal readonly CharacterFootLifecycleInputPage LeftInputState = new();
        internal readonly CharacterFootLifecycleInputPage RightInputState = new();
        internal CharacterFootPelvisSpringState PelvisSpring;
        internal CharacterFootPrimarySupportState PrimarySupport;
        internal CharacterResolvedFootPair ResolvedFeet;
        internal CharacterFootStrideHipsResult StrideHips;
        internal CharacterFullBodyIkGoal PelvisGoal;
        internal CharacterFullBodyIkGoal LeftGoal;
        internal CharacterFullBodyIkGoal RightGoal;
        internal CharacterFootGroundPathPage LeftGroundPath;
        internal CharacterFootGroundPathPage RightGroundPath;
        internal CharacterFootLandingObservationPage LeftLandingObservation;
        internal CharacterFootLandingObservationPage RightLandingObservation;
        internal CharacterFootCurrentSupportObservationPage LeftCurrentSupport;
        internal CharacterFootCurrentSupportObservationPage RightCurrentSupport;
        internal readonly CharacterFootSoleProbeBuffer LeftStateTargetProbes = new();
        internal readonly CharacterFootSoleProbeBuffer RightStateTargetProbes = new();
        internal readonly CharacterFootSoleProbeBuffer LeftOutputProbes = new();
        internal readonly CharacterFootSoleProbeBuffer RightOutputProbes = new();
        internal CharacterFootPredictionMotionState PredictionMotion;
        internal CharacterFootPredictionMotionResult PredictionMotionResult;
        internal readonly CharacterFutureBodyTranslation BodyTrajectory =
            new CharacterFutureBodyTranslation();
        internal ulong BodyTrajectoryTick;
        internal ulong BodyTrajectoryResetSequence;
        internal ulong BodyTrajectoryGeneration;
        internal ulong BodyTrajectoryAuthorityTick;
        internal ulong BodyTrajectoryPredictionMotionRevision;
        internal float BodyTrajectoryRequestedDuration;
        internal bool HasBodyTrajectoryAttempt;
        internal readonly CharacterFootPlacementDiagnosticsPage Diagnostics =
            new CharacterFootPlacementDiagnosticsPage();
        internal ulong FrameSequence;
        internal ulong CompletionIdentity;
        internal bool RecordDiagnostics;
        internal bool IsPendingFrameOpen;

        internal void Begin(
            CharacterFootPlacementBank committed,
            bool recordDiagnostics)
        {
            if (committed == null)
            {
                Reset();
            }
            else
            {
                LeftFoot = committed.LeftFoot;
                RightFoot = committed.RightFoot;
                PelvisSpring = committed.PelvisSpring;
                PrimarySupport = committed.PrimarySupport;
                ResolvedFeet = default;
                StrideHips = default;
                PelvisGoal = default;
                LeftGoal = default;
                RightGoal = default;
                LeftGroundPath = null;
                RightGroundPath = null;
                LeftLandingObservation = null;
                RightLandingObservation = null;
                LeftCurrentSupport = null;
                RightCurrentSupport = null;
                PredictionMotion = committed.PredictionMotion;
                PredictionMotionResult = default;
                BodyTrajectory.CopyFrom(committed.BodyTrajectory);
                BodyTrajectoryTick = committed.BodyTrajectoryTick;
                BodyTrajectoryResetSequence = committed.BodyTrajectoryResetSequence;
                BodyTrajectoryGeneration = committed.BodyTrajectoryGeneration;
                BodyTrajectoryAuthorityTick = committed.BodyTrajectoryAuthorityTick;
                BodyTrajectoryPredictionMotionRevision =
                    committed.BodyTrajectoryPredictionMotionRevision;
                BodyTrajectoryRequestedDuration = committed.BodyTrajectoryRequestedDuration;
                HasBodyTrajectoryAttempt = committed.HasBodyTrajectoryAttempt;
                Diagnostics.Clear();
            }
            FrameSequence = 0;
            CompletionIdentity = 0;
            RecordDiagnostics = recordDiagnostics;
            IsPendingFrameOpen = true;
        }

        internal void ClearPending()
        {
            LeftGroundPath = null;
            RightGroundPath = null;
            LeftLandingObservation = null;
            RightLandingObservation = null;
            LeftCurrentSupport = null;
            RightCurrentSupport = null;
            PredictionMotionResult = default;
            ResolvedFeet = default;
            StrideHips = default;
            PelvisGoal = default;
            LeftGoal = default;
            RightGoal = default;
            Diagnostics.Clear();
            FrameSequence = 0;
            CompletionIdentity = 0;
            RecordDiagnostics = false;
            IsPendingFrameOpen = false;
        }

        internal void Reset()
        {
            CharacterFootCorrectionResponseInitializationReason leftReason =
                LeftFoot.Interpolation
                    .PendingCorrectionResponseInitializationReason;
            CharacterFootCorrectionResponseInitializationReason rightReason =
                RightFoot.Interpolation
                    .PendingCorrectionResponseInitializationReason;
            if (leftReason !=
                    CharacterFootCorrectionResponseInitializationReason.None &&
                rightReason !=
                    CharacterFootCorrectionResponseInitializationReason.None &&
                leftReason != rightReason)
            {
                throw new InvalidOperationException(
                    "Foot correction response reset reasons are inconsistent.");
            }
            Reset(leftReason !=
                  CharacterFootCorrectionResponseInitializationReason.None
                ? leftReason
                : rightReason !=
                  CharacterFootCorrectionResponseInitializationReason.None
                    ? rightReason
                    : CharacterFootCorrectionResponseInitializationReason
                        .FirstLegalInput);
        }

        internal void Reset(
            CharacterFootCorrectionResponseInitializationReason reason)
        {
            if (reason ==
                CharacterFootCorrectionResponseInitializationReason.None)
            {
                throw new ArgumentOutOfRangeException(nameof(reason));
            }
            LeftFoot = default;
            RightFoot = default;
            LeftInputState.Clear();
            RightInputState.Clear();
            LeftFoot.Interpolation
                .PendingCorrectionResponseInitializationReason = reason;
            RightFoot.Interpolation
                .PendingCorrectionResponseInitializationReason = reason;
            PelvisSpring.Clear();
            PrimarySupport.Clear();
            ResolvedFeet = default;
            StrideHips = default;
            PelvisGoal = default;
            LeftGoal = default;
            RightGoal = default;
            LeftGroundPath = null;
            RightGroundPath = null;
            LeftLandingObservation = null;
            RightLandingObservation = null;
            LeftCurrentSupport = null;
            RightCurrentSupport = null;
            PredictionMotion.Clear();
            PredictionMotionResult = default;
            BodyTrajectory.Clear();
            BodyTrajectoryTick = 0;
            BodyTrajectoryResetSequence = 0;
            BodyTrajectoryGeneration = 0;
            BodyTrajectoryAuthorityTick = 0;
            BodyTrajectoryPredictionMotionRevision = 0;
            BodyTrajectoryRequestedDuration = 0f;
            HasBodyTrajectoryAttempt = false;
            Diagnostics.Clear();
            FrameSequence = 0;
            CompletionIdentity = 0;
            RecordDiagnostics = false;
            IsPendingFrameOpen = false;
        }
    }

    readonly struct CharacterFootLandingPredictionPair
    {

        internal CharacterFootLandingPredictionPair(
            in CharacterFootLandingPredictionResult selected,
            CharacterFootLandingStepSource selectedSource)
        {
            Selected = selected;
            SelectedSource = selectedSource;
        }

        internal readonly CharacterFootLandingPredictionResult Selected;
        internal CharacterFootLandingStepSource SelectedSource { get; }
    }

    readonly struct CharacterFootActionOccupancy
    {
        internal CharacterFootActionOccupancy(ulong actionInstanceIdentity, float weight)
        {
            ActionInstanceIdentity = actionInstanceIdentity;
            Weight = weight;
        }

        internal ulong ActionInstanceIdentity { get; }
        internal float Weight { get; }
    }

    internal sealed class CharacterFootPlacementModule : IDisposable
    {
        readonly ActorId m_ActorId;
        readonly CharacterFootPlacementModuleSettings m_Settings;
        readonly CharacterFootPlacementPoseRig m_Rig;
        readonly ICharacterFutureBodyTranslationSource m_FutureBodyTranslationSource;
        readonly ICharacterFootPlacementWorldQuery m_WorldQuery;
        readonly CharacterFootGroundPathPagePool m_LeftGroundPath;
        readonly CharacterFootGroundPathPagePool m_RightGroundPath;
        readonly CharacterFootLandingObservationPagePool m_LeftLandingObservation;
        readonly CharacterFootLandingObservationPagePool m_RightLandingObservation;
        readonly CharacterFootCurrentSupportObservationPagePool m_LeftCurrentSupport;
        readonly CharacterFootCurrentSupportObservationPagePool m_RightCurrentSupport;

        bool m_Disposed;

        internal CharacterFootPlacementModule(
            ActorId actorId,
            CharacterFootPlacementModuleSettings settings,
            CharacterFootPlacementPoseRig rig,
            ICharacterFutureBodyTranslationSource futureBodyTranslationSource,
            ICharacterFootPlacementWorldQuery worldQuery)
        {
            if (!actorId.IsValid || settings == null || rig == null || worldQuery == null)
            {
                throw new ArgumentException("Foot Placement Runtime input is invalid.");
            }
            m_ActorId = actorId;
            m_Settings = settings;
            m_Rig = rig;
            m_FutureBodyTranslationSource = futureBodyTranslationSource;
            m_WorldQuery = worldQuery;
            m_LeftGroundPath = new CharacterFootGroundPathPagePool(
                settings.GroundDetection.ContactCapacity);
            m_RightGroundPath = new CharacterFootGroundPathPagePool(
                settings.GroundDetection.ContactCapacity);
            m_LeftLandingObservation = new CharacterFootLandingObservationPagePool();
            m_RightLandingObservation = new CharacterFootLandingObservationPagePool();
            m_LeftCurrentSupport =
                new CharacterFootCurrentSupportObservationPagePool();
            m_RightCurrentSupport =
                new CharacterFootCurrentSupportObservationPagePool();
        }

        internal CharacterFootPlacementBank CreateBank() =>
            new CharacterFootPlacementBank();

        internal CharacterFootPlacementResult EvaluateFrame(
            in CharacterFootPlacementFrameInput frame,
            CharacterFootPlacementBank committedBank,
            CharacterFootPlacementBank bank)
        {
            RequireAlive();
            ref readonly CharacterFootPlacementPoseInput poseInput = ref frame.Pose;
            ref readonly CharacterBodyPresentationFrame body = ref frame.Body;
            ref readonly CharacterPresentationFactFrame facts = ref frame.Facts;
            if (bank == null || !bank.IsPendingFrameOpen)
                throw new InvalidOperationException("Foot Placement has no open bank.");
            if (bank.FrameSequence != 0)
                throw new InvalidOperationException("Foot Placement already evaluated the open bank.");
            if (bank.RecordDiagnostics)
            {
                bank.LeftInputState.Capture(in bank.LeftFoot);
                bank.RightInputState.Capture(in bank.RightFoot);
            }
            if (frame.ActorId != m_ActorId ||
                !string.Equals(
                    poseInput.PosePlanHash,
                    m_Settings.PosePlanHash,
                    StringComparison.Ordinal) ||
                frame.FootPlacementWeight < 0f ||
                frame.FootPlacementWeight > 1f)
            {
                throw new ArgumentException("Foot Placement frame contract is inconsistent.");
            }
            CharacterFootPlacementAnimatedPose pose = m_Rig.CaptureAnimatedPose(
                frame.RenderFrame,
                poseInput.DenseComponentPoses);
            ref readonly CharacterFootPlacementAnimatedFootPose leftPose = ref pose.Left;
            ref readonly CharacterFootPlacementAnimatedFootPose rightPose = ref pose.Right;
            ref readonly Vector3 pelvisLocalPosition = ref pose.PelvisLocalPosition;
            ref readonly CommittedLocomotionPlanarMotionTimeline timeline =
                ref facts.LocomotionMotionTimeline;
            bool hasMotionTimeline = timeline.IsValid;
            ulong trajectoryGeneration = hasMotionTimeline ? timeline.Generation : 0;
            CharacterFootActionOccupancy leftAction = ResolveActionOccupancy(
                in poseInput,
                CharacterFootSide.Left);
            CharacterFootActionOccupancy rightAction = ResolveActionOccupancy(
                in poseInput,
                CharacterFootSide.Right);
            float currentSegmentRemainingSeconds = hasMotionTimeline
                ? ResolveCurrentSegmentRemainingSeconds(timeline, in body)
                : 0f;
            ref readonly AnimationFootMotionRuntimeFrame formalFootFrame =
                ref poseInput.FootMotion;
            ref readonly AnimationFootMotionRuntimeSample leftCurrentStep =
                ref formalFootFrame.Left;
            ref readonly AnimationFootMotionRuntimeSample rightCurrentStep =
                ref formalFootFrame.Right;
            var leftLockRequest = new CharacterFootLockRequest(in leftCurrentStep);
            var rightLockRequest = new CharacterFootLockRequest(in rightCurrentStep);
            CharacterFutureBodyTranslation bodyTrajectory = ResolveBodyTrajectory(
                bank,
                in leftCurrentStep,
                in rightCurrentStep,
                in timeline,
                currentSegmentRemainingSeconds,
                frame.PresentationDeltaSeconds,
                in body);
            Vector3 componentUp = body.VisibleRotation * Vector3.up;
            bank.LeftCurrentSupport = PrepareCurrentSupport(
                CharacterFootSide.Left,
                in leftPose,
                componentUp,
                facts.Grounded,
                frame.RenderFrame,
                poseInput.CompletionIdentity,
                m_LeftCurrentSupport,
                committedBank?.LeftCurrentSupport);
            bank.RightCurrentSupport = PrepareCurrentSupport(
                CharacterFootSide.Right,
                in rightPose,
                componentUp,
                facts.Grounded,
                frame.RenderFrame,
                poseInput.CompletionIdentity,
                m_RightCurrentSupport,
                committedBank?.RightCurrentSupport);
            ref readonly CharacterFootCurrentSupportObservation leftCurrentSupport =
                ref bank.LeftCurrentSupport.Observation;
            ref readonly CharacterFootCurrentSupportObservation rightCurrentSupport =
                ref bank.RightCurrentSupport.Observation;

            CharacterFootLandingSnapshot leftLanding =
                CharacterFootLandingRuntime.ProjectBeforePrediction(
                    in bank.LeftFoot,
                    in leftCurrentStep);
            CharacterFootLandingSnapshot rightLanding =
                CharacterFootLandingRuntime.ProjectBeforePrediction(
                    in bank.RightFoot,
                    in rightCurrentStep);
            bool leftPlantVerificationRequired =
                CharacterFootTransitionResolver.RequiresPlantVerification(
                    in bank.LeftFoot,
                    in leftLockRequest);
            bool rightPlantVerificationRequired =
                CharacterFootTransitionResolver.RequiresPlantVerification(
                    in bank.RightFoot,
                    in rightLockRequest);
            CharacterFootLandingPredictionPair leftPair = PredictFootPair(
                CharacterFootSide.Left,
                leftCurrentStep,
                in leftPose,
                hasMotionTimeline,
                trajectoryGeneration,
                bodyTrajectory,
                in frame,
                in leftLanding,
                leftPlantVerificationRequired,
                m_LeftLandingObservation,
                committedBank?.LeftLandingObservation,
                out bank.LeftLandingObservation);
            CharacterFootLandingPredictionPair rightPair = PredictFootPair(
                CharacterFootSide.Right,
                rightCurrentStep,
                in rightPose,
                hasMotionTimeline,
                trajectoryGeneration,
                bodyTrajectory,
                in frame,
                in rightLanding,
                rightPlantVerificationRequired,
                m_RightLandingObservation,
                committedBank?.RightLandingObservation,
                out bank.RightLandingObservation);
            ref readonly CharacterFootLandingPredictionResult leftPrediction =
                ref leftPair.Selected;
            ref readonly CharacterFootLandingPredictionResult rightPrediction =
                ref rightPair.Selected;
            leftLanding = CharacterFootLandingRuntime.ProjectAfterPrediction(
                in bank.LeftFoot,
                in leftCurrentStep,
                in leftPrediction,
                in m_Settings.FootMotion);
            rightLanding = CharacterFootLandingRuntime.ProjectAfterPrediction(
                in bank.RightFoot,
                in rightCurrentStep,
                in rightPrediction,
                in m_Settings.FootMotion);
            bool hasLeftLastLanding = leftLanding.HasLastLanding;
            bool hasLeftNextSwingLanding = leftLanding.HasNextSwingLanding;
            bool hasRightLastLanding = rightLanding.HasLastLanding;
            bool hasRightNextSwingLanding = rightLanding.HasNextSwingLanding;
            ref readonly CharacterFootGroundPathLanding leftLastLanding =
                ref leftLanding.LastLanding;
            ref readonly CharacterFootGroundPathLanding leftNextSwingLanding =
                ref leftLanding.NextSwingLanding;
            ref readonly CharacterFootGroundPathLanding rightLastLanding =
                ref rightLanding.LastLanding;
            ref readonly CharacterFootGroundPathLanding rightNextSwingLanding =
                ref rightLanding.NextSwingLanding;
            CharacterFootGroundPathLanding leftContactLanding = default;
            bool hasLeftContactLanding = leftLockRequest.RequestsLock &&
                (leftLanding.TryResolveVerifiedLanding(
                     leftLockRequest.EventIdentity,
                     out leftContactLanding) ||
                 CharacterFootLandingRuntime.TryResolveCurrentContactCandidate(
                     in leftCurrentStep,
                     in leftPrediction,
                     out leftContactLanding));
            CharacterFootGroundPathLanding rightContactLanding = default;
            bool hasRightContactLanding = rightLockRequest.RequestsLock &&
                (rightLanding.TryResolveVerifiedLanding(
                     rightLockRequest.EventIdentity,
                     out rightContactLanding) ||
                 CharacterFootLandingRuntime.TryResolveCurrentContactCandidate(
                     in rightCurrentStep,
                     in rightPrediction,
                     out rightContactLanding));
            bool leftPreparedPlantActive = leftLanding.PlantTargetState ==
                CharacterFootPlantTargetState.Tracking;
            bool rightPreparedPlantActive = rightLanding.PlantTargetState ==
                CharacterFootPlantTargetState.Tracking;
            CharacterFootGroundPathLanding leftPreparedPlantTarget =
                leftPreparedPlantActive ? leftLanding.PlantTarget : default;
            CharacterFootGroundPathLanding rightPreparedPlantTarget =
                rightPreparedPlantActive ? rightLanding.PlantTarget : default;
            CharacterFootGroundPathResult leftGroundPath = PrepareGroundPath(
                CharacterFootSide.Left,
                hasLeftLastLanding,
                in leftLastLanding,
                hasLeftNextSwingLanding,
                in leftNextSwingLanding,
                componentUp,
                hasMotionTimeline ? timeline.AuthorityTick.Value : 0,
                m_LeftGroundPath,
                committedBank?.LeftGroundPath,
                out bank.LeftGroundPath);
            CharacterFootGroundPathResult rightGroundPath = PrepareGroundPath(
                CharacterFootSide.Right,
                hasRightLastLanding,
                in rightLastLanding,
                hasRightNextSwingLanding,
                in rightNextSwingLanding,
                componentUp,
                hasMotionTimeline ? timeline.AuthorityTick.Value : 0,
                m_RightGroundPath,
                committedBank?.RightGroundPath,
                out bank.RightGroundPath);
            CharacterFootLandingPredictionResult left =
                leftPrediction.WithGroundPath(in leftGroundPath);
            CharacterFootLandingPredictionResult right =
                rightPrediction.WithGroundPath(in rightGroundPath);

            float footPlacementWeight = frame.FootPlacementWeight;
            CharacterFootSwingMotionResult leftSwingMotion =
                CharacterFootSwingMotionBuilder.Build(
                    in leftPose,
                    in leftCurrentStep,
                    footPlacementWeight,
                    componentUp,
                    in leftGroundPath,
                    true,
                    formalFootFrame.Left.FootHeight,
                    leftLanding.NextSwingPredictionError);
            CharacterFootSwingMotionResult rightSwingMotion =
                CharacterFootSwingMotionBuilder.Build(
                    in rightPose,
                    in rightCurrentStep,
                    footPlacementWeight,
                    componentUp,
                    in rightGroundPath,
                    true,
                    formalFootFrame.Right.FootHeight,
                    rightLanding.NextSwingPredictionError);
            bool hasSelectedSwing = CharacterFootStrideHipsBuilder.TrySelectSwing(
                in leftCurrentStep,
                in rightCurrentStep,
                in leftSwingMotion,
                in rightSwingMotion,
                out CharacterFootSide selectedSwingSide);
            Transform goalRoot = m_Rig.PoseRoot;
            var sourceLineage = new FixedString128Bytes(
                poseInput.PosePlanHash);
            var profileRevision = new FixedString128Bytes(
                m_Settings.ProfileRevision);
            ulong worldRevision = m_WorldQuery.WorldRevision;
            var leftConstraintFrame = new CharacterFootStateFrame(
                frame.RenderFrame,
                poseInput.CompletionIdentity,
                new FixedString64Bytes(m_Rig.Rig.RigId),
                new FixedString64Bytes(m_Rig.Rig.RigRevision),
                CharacterFootSide.Left,
                in leftPose,
                leftPose.HipPosition,
                m_Rig.LeftLegLength,
                in leftSwingMotion,
                in leftGroundPath,
                hasLeftContactLanding,
                in leftContactLanding,
                leftPreparedPlantActive,
                in leftPreparedPlantTarget,
                in leftCurrentSupport,
                in leftLockRequest,
                leftCurrentStep.Support,
                leftLockRequest.EventIdentity,
                ResolveFootGoalOwnershipLoss(
                    facts.Grounded,
                    leftCurrentStep.IsAuthoritative),
                footPlacementWeight,
                componentUp,
                frame.PresentationDeltaSeconds,
                sourceLineage,
                profileRevision,
                worldRevision,
                in m_Settings.FootMotion);
            var rightConstraintFrame = new CharacterFootStateFrame(
                frame.RenderFrame,
                poseInput.CompletionIdentity,
                new FixedString64Bytes(m_Rig.Rig.RigId),
                new FixedString64Bytes(m_Rig.Rig.RigRevision),
                CharacterFootSide.Right,
                in rightPose,
                rightPose.HipPosition,
                m_Rig.RightLegLength,
                in rightSwingMotion,
                in rightGroundPath,
                hasRightContactLanding,
                in rightContactLanding,
                rightPreparedPlantActive,
                in rightPreparedPlantTarget,
                in rightCurrentSupport,
                in rightLockRequest,
                rightCurrentStep.Support,
                rightLockRequest.EventIdentity,
                ResolveFootGoalOwnershipLoss(
                    facts.Grounded,
                    rightCurrentStep.IsAuthoritative),
                footPlacementWeight,
                componentUp,
                frame.PresentationDeltaSeconds,
                sourceLineage,
                profileRevision,
                worldRevision,
                in m_Settings.FootMotion);
            var leftStrideRequest = new CharacterFootStrideRequest(
                in leftCurrentStep, hasLeftNextSwingLanding,
                in leftNextSwingLanding, leftGroundPath.Accepted);
            var rightStrideRequest = new CharacterFootStrideRequest(
                in rightCurrentStep, hasRightNextSwingLanding,
                in rightNextSwingLanding, rightGroundPath.Accepted);
            var leftEvaluation = new CharacterFootStateEvaluation(
                CharacterFootSide.Left,
                in leftCurrentStep,
                in left,
                in leftConstraintFrame,
                in leftStrideRequest,
                facts.Grounded,
                goalRoot,
                new CharacterFootSoleSupportQuery(m_WorldQuery,
                    in m_Settings.CurrentSupportQuery),
                bank.LeftStateTargetProbes, bank.LeftOutputProbes);
            var rightEvaluation = new CharacterFootStateEvaluation(
                CharacterFootSide.Right,
                in rightCurrentStep,
                in right,
                in rightConstraintFrame,
                in rightStrideRequest,
                facts.Grounded,
                goalRoot,
                new CharacterFootSoleSupportQuery(m_WorldQuery,
                    in m_Settings.CurrentSupportQuery),
                bank.RightStateTargetProbes, bank.RightOutputProbes);
            CharacterFootPlacementRequest leftRequest =
                CharacterFootLifecycle.Evaluate(
                    ref bank.LeftFoot,
                    in leftEvaluation,
                    out CharacterFootLifecycle.Completion leftCompletion);
            CharacterFootPlacementRequest rightRequest =
                CharacterFootLifecycle.Evaluate(
                    ref bank.RightFoot,
                    in rightEvaluation,
                    out CharacterFootLifecycle.Completion rightCompletion);
            var requestPair = new CharacterFootPlacementRequestPair(
                in leftRequest,
                in rightRequest);
            CharacterFootPrimarySupportResult primarySupport =
                CharacterFootStrideHipsBuilder.ResolvePrimarySupport(
                    in leftRequest,
                    in rightRequest,
                    ref bank.PrimarySupport);
            CharacterFootStrideIntentResult strideIntent =
                CharacterFootStrideHipsBuilder.ResolveIntent(
                    in requestPair,
                    in primarySupport,
                    facts.Grounded,
                    hasSelectedSwing,
                    selectedSwingSide,
                    componentUp);
            var pelvisFrame = new CharacterFootPelvisFrame(
                componentUp,
                m_Rig.PoseRoot.position,
                m_Rig.PoseRoot.TransformPoint(pelvisLocalPosition),
                pelvisLocalPosition,
                in pose,
                leftRequest.GoalTarget.EffectiveSole,
                rightRequest.GoalTarget.EffectiveSole,
                m_Rig.LeftLegLength,
                m_Rig.RightLegLength,
                footPlacementWeight,
                frame.PresentationDeltaSeconds);
            bool leftLandingReach = leftRequest.LandingReachAdmitted;
            bool rightLandingReach = rightRequest.LandingReachAdmitted;
            CharacterFootPelvisInput pelvisInput = CharacterFootStrideHipsBuilder.PreparePelvis(
                in strideIntent, in requestPair, in primarySupport, in pelvisFrame);
            CharacterFootStrideHipsResult strideHips = CharacterFootStrideHipsBuilder.ResolvePelvis(
                in pelvisInput,
                in m_Settings.FootMotion,
                ref bank.PelvisSpring);
            bool leftReachAvailable = strideHips.LeftLandingReachAvailable;
            bool rightReachAvailable = strideHips.RightLandingReachAvailable;
            CharacterResolvedFootResult leftResolved = leftCompletion.Complete(
                ref bank.LeftFoot,
                leftReachAvailable,
                strideHips.PelvisDelta * strideHips.PositionWeight,
                out CharacterFootSwingMotionResult leftFootMotion);
            CharacterResolvedFootResult rightResolved = rightCompletion.Complete(
                ref bank.RightFoot,
                rightReachAvailable,
                strideHips.PelvisDelta * strideHips.PositionWeight,
                out CharacterFootSwingMotionResult rightFootMotion);
            var resolvedPair = new CharacterResolvedFootPair(
                in leftResolved,
                in rightResolved);
            bank.ResolvedFeet = resolvedPair;
            CharacterFullBodyIkGoal leftGoal = EncodeFootGoal(in leftResolved);
            CharacterFullBodyIkGoal rightGoal = EncodeFootGoal(in rightResolved);
            leftFootMotion = CharacterFootSwingMotionBuilder.WithLandingReach(
                in leftFootMotion, leftLandingReach, leftReachAvailable);
            rightFootMotion = CharacterFootSwingMotionBuilder.WithLandingReach(
                in rightFootMotion, rightLandingReach, rightReachAvailable);
            CharacterFullBodyIkGoal pelvisGoal = CreatePelvisGoal(in strideHips, m_Rig.PoseRoot);
            bank.StrideHips = strideHips;
            if (!strideHips.ProducesPelvisGoal)
                bank.PelvisSpring.Clear();
            bank.PelvisGoal = pelvisGoal;
            bank.LeftGoal = leftGoal;
            bank.RightGoal = rightGoal;
            bank.FrameSequence = frame.RenderFrame;
            bank.CompletionIdentity = poseInput.CompletionIdentity;
            if (bank.RecordDiagnostics)
            {
                var inputDiagnostics = new CharacterFootLandingPredictionInputDiagnostics(
                    frame.PresentationDeltaSeconds,
                    frame.FootPlacementWeight,
                    poseInput.PosePlanHash,
                    new CharacterFootBodyTrajectoryInputDiagnostics(bank, bodyTrajectory),
                    in body,
                    facts.Grounded,
                    frame.ParameterFrame.Require(
                        new PoseParameterId(CharacterAnimationVariableIds.HorizontalSpeed)),
                    in leftAction,
                    in rightAction,
                    in timeline,
                    currentSegmentRemainingSeconds,
                    in bank.PredictionMotionResult,
                    in formalFootFrame);
                var leftDiagnostics =
                    new CharacterFootLandingPredictionFootDiagnostics(
                        in left,
                        new CharacterFootLifecycleInputDiagnostics(bank.LeftInputState),
                        leftPose,
                        new CharacterFootStepSelectionDiagnostics(
                            leftLanding.LastLandingEventIdentity,
                            leftPair.SelectedSource,
                            left.LandingEventIdentity,
                            m_Settings.LandingPrediction
                                .MaximumPredictionTimeSeconds),
                        bank.LeftFoot.LandingSnapshot,
                        leftPreparedPlantActive,
                        in leftCurrentSupport,
                        in leftResolved,
                        in leftFootMotion,
                        in leftGoal,
                        leftCompletion.OutputSupport,
                        leftCompletion.StateTargetSupport);
                var rightDiagnostics =
                    new CharacterFootLandingPredictionFootDiagnostics(
                        in right,
                        new CharacterFootLifecycleInputDiagnostics(bank.RightInputState),
                        rightPose,
                        new CharacterFootStepSelectionDiagnostics(
                            rightLanding.LastLandingEventIdentity,
                            rightPair.SelectedSource,
                            right.LandingEventIdentity,
                            m_Settings.LandingPrediction
                                .MaximumPredictionTimeSeconds),
                        bank.RightFoot.LandingSnapshot,
                        rightPreparedPlantActive,
                        in rightCurrentSupport,
                        in rightResolved,
                        in rightFootMotion,
                        in rightGoal,
                        rightCompletion.OutputSupport,
                        rightCompletion.StateTargetSupport);
                var primarySupportDiagnostics =
                    new CharacterFootPrimarySupportDiagnostics(in primarySupport);
                var strideDiagnostics =
                    new CharacterFootStrideHipsDiagnostics(in strideHips);
                var diagnostics = new CharacterFootLandingPredictionDiagnostics(
                    frame.RenderFrame,
                    poseInput.CompletionIdentity,
                    m_Rig.VisualRoot.GetInstanceID(),
                    m_Settings.ProfileId,
                    m_Settings.ProfileRevision,
                    in inputDiagnostics,
                    in primarySupportDiagnostics,
                    pelvisGoal,
                    in strideDiagnostics,
                    in leftDiagnostics,
                    in rightDiagnostics);
                bank.Diagnostics.Set(in diagnostics);
            }
            return new CharacterFootPlacementResult(
                frame.RenderFrame,
                poseInput.CompletionIdentity,
                new FixedString64Bytes(m_Rig.Rig.RigId),
                new FixedString64Bytes(m_Rig.Rig.RigRevision),
                in resolvedPair,
                in primarySupport,
                in strideHips,
                pelvisGoal,
                leftGoal,
                rightGoal);
        }

        internal void ValidateFrame(
            CharacterFootPlacementBank bank,
            ulong renderFrame,
            ulong completionIdentity)
        {
            RequireAlive();
            if (bank == null || !bank.IsPendingFrameOpen ||
                bank.FrameSequence != renderFrame ||
                bank.CompletionIdentity != completionIdentity)
            {
                throw new InvalidOperationException(
                    "Foot Placement pending completion identity is inconsistent.");
            }
        }

        internal void ReleasePendingPages(
            CharacterFootPlacementBank committed,
            CharacterFootPlacementBank pending)
        {
            RequireAlive();
            CharacterFootGroundPathPagePool.Discard(
                pending?.LeftGroundPath,
                committed?.LeftGroundPath);
            CharacterFootGroundPathPagePool.Discard(
                pending?.RightGroundPath,
                committed?.RightGroundPath);
            CharacterFootLandingObservationPagePool.Discard(
                pending?.LeftLandingObservation,
                committed?.LeftLandingObservation);
            CharacterFootLandingObservationPagePool.Discard(
                pending?.RightLandingObservation,
                committed?.RightLandingObservation);
            CharacterFootCurrentSupportObservationPagePool.Discard(
                pending?.LeftCurrentSupport,
                committed?.LeftCurrentSupport);
            CharacterFootCurrentSupportObservationPagePool.Discard(
                pending?.RightCurrentSupport,
                committed?.RightCurrentSupport);
        }

        internal void ResetShared(in CharacterFootPlacementReset reset)
        {
            RequireAlive();
            if (reset.ActorId != m_ActorId)
                throw new ArgumentException("Foot Placement reset Actor identity is invalid.");
            m_LeftGroundPath.Reset();
            m_RightGroundPath.Reset();
            m_LeftLandingObservation.Reset();
            m_RightLandingObservation.Reset();
            m_LeftCurrentSupport.Reset();
            m_RightCurrentSupport.Reset();
        }

        internal void RetargetShared(ulong resetSequence)
        {
            RequireAlive();
            if (resetSequence == 0)
                throw new ArgumentOutOfRangeException(nameof(resetSequence));
            m_LeftGroundPath.Reset();
            m_RightGroundPath.Reset();
            m_LeftLandingObservation.Reset();
            m_RightLandingObservation.Reset();
            m_LeftCurrentSupport.Reset();
            m_RightCurrentSupport.Reset();
        }

        internal string ValidateTuningCandidate(
            CharacterPoseTuningLayout layout,
            CharacterPoseTuningParameterBlock block)
        {
            if (layout == null || block == null)
                return "Foot Placement tuning payload is missing.";
            try
            {
                block.RequireValid(layout);
                return string.Empty;
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        CharacterFootCurrentSupportObservationPage PrepareCurrentSupport(
            CharacterFootSide side,
            in CharacterFootPlacementAnimatedFootPose foot,
            Vector3 componentUp,
            bool grounded,
            ulong frameSequence,
            ulong completionIdentity,
            CharacterFootCurrentSupportObservationPagePool pool,
            CharacterFootCurrentSupportObservationPage committed)
        {
            CharacterFootCurrentSupportObservationPage pending =
                pool.AcquireWritable(committed);
            ref readonly CharacterFootCurrentSupportQuerySettings settings =
                ref m_Settings.CurrentSupportQuery;
            var query = new CharacterFootSoleSupportQuery(m_WorldQuery, in settings);
            CharacterFootPlacementSoleContactPose contacts = foot.ResolveSoleContacts(foot.AnklePosition, foot.AnkleRotation);
            CharacterFootCurrentSupportObservation observation = query.Query(
                frameSequence, completionIdentity, m_WorldQuery.WorldRevision,
                side, componentUp, grounded, in contacts, pending.Probes);
            pending.Set(in observation);
            return pending;
        }

        CharacterFootGroundPathResult PrepareGroundPath(
            CharacterFootSide side,
            bool hasLastLanding,
            in CharacterFootGroundPathLanding lastLanding,
            bool hasNextSwingLanding,
            in CharacterFootGroundPathLanding nextSwingLanding,
            Vector3 componentUp,
            ulong authorityTick,
            CharacterFootGroundPathPagePool pool,
            CharacterFootGroundPathPage committedPage,
            out CharacterFootGroundPathPage pendingPage)
        {
            if (!hasLastLanding)
            {
                pendingPage = pool.AcquireWritable(committedPage);
                pendingPage.SetRejected(
                    CharacterFootGroundPathRejectReason.CurrentLandingUnavailable,
                    false,
                    0,
                    default,
                    default);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }
            if (!hasNextSwingLanding)
            {
                pendingPage = pool.AcquireWritable(committedPage);
                pendingPage.SetRejected(
                    CharacterFootGroundPathRejectReason.NextLandingUnavailable,
                    false, 0, default, default);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }

            CharacterFootGroundPathInputKey key =
                CharacterFootGroundPathInputBuilder.BuildKey(
                    side,
                    in lastLanding,
                    in nextSwingLanding,
                    authorityTick,
                    componentUp,
                    m_Settings.ProfileRevision);
            if (committedPage != null &&
                committedPage.HasInput &&
                committedPage.State == CharacterFootGroundPathState.Accepted &&
                committedPage.Input.Key.Equals(key))
            {
                pendingPage = CharacterFootGroundPathPagePool.ReuseCommitted(committedPage);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }

            pendingPage = pool.AcquireWritable(committedPage);
            ref readonly CharacterFootGroundDetectionSettings settings =
                ref m_Settings.GroundDetection;
            if (!CharacterFootGroundPathInputBuilder.TryBuild(
                    in key,
                    lastLanding.Point,
                    nextSwingLanding.Point,
                    lastLanding.Normal,
                    nextSwingLanding.Normal,
                    lastLanding.SurfaceIdentity,
                    nextSwingLanding.SurfaceIdentity,
                    componentUp,
                    in settings,
                    out CharacterFootGroundPathInput input))
            {
                pendingPage.SetRejected(
                    CharacterFootGroundPathRejectReason.InvalidRequest,
                    false, 0, default, default);
                return new CharacterFootGroundPathResult(pendingPage, false);
            }

            CharacterFootGroundPathQueryResult result = m_WorldQuery.Query(
                in input.Query,
                pendingPage.Contacts);
            if (result.Accepted)
            {
                if (CharacterFootGroundEnvelopeBuilder.TryBuild(
                        in input,
                        pendingPage.Contacts,
                        pool.EnvelopeWorkspace,
                        pendingPage.Edges,
                        pendingPage.Envelope,
                        out CharacterFootGroundPathRejectReason envelopeRejectReason,
                        out CharacterFootGroundInvalidSegment invalidSegment))
                {
                    pendingPage.SetAccepted(result.SegmentCount, in input);
                }
                else
                {
                    pendingPage.SetRejected(
                        envelopeRejectReason, true, result.SegmentCount,
                        in input, in invalidSegment);
                }
            }
            else
                pendingPage.SetRejected(
                    result.RejectReason, true, result.SegmentCount,
                    in input, default);
            return new CharacterFootGroundPathResult(pendingPage, true);
        }

        CharacterFootLandingPredictionPair PredictFootPair(
            CharacterFootSide side,
            in AnimationFootMotionRuntimeSample footMotion,
            in CharacterFootPlacementAnimatedFootPose animatedFoot,
            bool hasMotionTimeline,
            ulong trajectoryGeneration,
            CharacterFutureBodyTranslation bodyTrajectory,
            in CharacterFootPlacementFrameInput frame,
            in CharacterFootLandingSnapshot landingSnapshot,
            bool plantVerificationRequired,
            CharacterFootLandingObservationPagePool observationPool,
            CharacterFootLandingObservationPage committedObservation,
            out CharacterFootLandingObservationPage pendingObservation)
        {
            pendingObservation = committedObservation;
            Vector3 currentSole =
                (animatedFoot.HeelPosition + animatedFoot.ToePosition) * 0.5f;
            ref readonly AnimationFootMotionEventFrame events =
                ref footMotion.Events;
            ref readonly AnimationFootMotionEventOccurrence current =
                ref events.CurrentContact;
            ref readonly AnimationFootMotionEventOccurrence next =
                ref events.NextLanding;
            bool hasNextCandidate = IsPredictiveLanding(
                in footMotion,
                in next,
                landingSnapshot.LastLandingEventIdentity,
                m_Settings.LandingPrediction.MaximumPredictionTimeSeconds);
            CharacterFootLandingStepSource selectedSource;
            CharacterFootLandingPredictionResult selected;
            if (plantVerificationRequired)
            {
                selectedSource = CharacterFootLandingStepSource.FormalCurrentContact;
                selected = PredictEvent(
                    side,
                    in footMotion,
                    in current,
                    selectedSource,
                    0f,
                    true,
                    animatedFoot,
                    hasMotionTimeline,
                    trajectoryGeneration,
                    bodyTrajectory,
                    in frame,
                    observationPool,
                    committedObservation,
                    out pendingObservation);
            }
            else if (hasNextCandidate)
            {
                selectedSource = CharacterFootLandingStepSource.FormalNextLanding;
                selected = PredictEvent(
                    side,
                    in footMotion,
                    in next,
                    selectedSource,
                    events.TimeToLandingSeconds,
                    false,
                    animatedFoot,
                    hasMotionTimeline,
                    trajectoryGeneration,
                    bodyTrajectory,
                    in frame,
                    observationPool,
                    committedObservation,
                    out pendingObservation);
            }
            else
            {
                selectedSource = CharacterFootLandingStepSource.None;
                selected = RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.StepUnavailable,
                    selectedSource,
                    in next,
                    events.TimeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            return new CharacterFootLandingPredictionPair(
                selected,
                selectedSource);
        }

        static bool IsPredictiveLanding(
            in AnimationFootMotionRuntimeSample footMotion,
            in AnimationFootMotionEventOccurrence next,
            ulong lastLandingEventIdentity,
            float maximumPredictionTimeSeconds) =>
            footMotion.IsValid &&
            footMotion.HasPredictiveLanding &&
            next.IsBound &&
            footMotion.TimeToLandingSeconds > 0.000001f &&
            footMotion.TimeToLandingSeconds <= maximumPredictionTimeSeconds &&
            next.Identity != lastLandingEventIdentity;

        CharacterFootLandingPredictionResult PredictEvent(
            CharacterFootSide side,
            in AnimationFootMotionRuntimeSample footMotion,
            in AnimationFootMotionEventOccurrence landingEvent,
            CharacterFootLandingStepSource stepSource,
            float timeToLandingSeconds,
            bool currentContact,
            in CharacterFootPlacementAnimatedFootPose animatedFoot,
            bool hasMotionTimeline,
            ulong trajectoryGeneration,
            CharacterFutureBodyTranslation bodyTrajectory,
            in CharacterFootPlacementFrameInput frame,
            CharacterFootLandingObservationPagePool observationPool,
            CharacterFootLandingObservationPage committedObservation,
            out CharacterFootLandingObservationPage pendingObservation)
        {
            Vector3 currentSole = CharacterFootConstraintMath.ResolveOriginalSole(animatedFoot);
            ref readonly CharacterBodyPresentationFrame body = ref frame.Body;
            pendingObservation = committedObservation;
            if (!footMotion.IsValid)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.StepUnavailable,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            if (!landingEvent.IsBound)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.StepIdentityMismatch,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            ref readonly CharacterFootLandingPredictionSettings settings =
                ref m_Settings.LandingPrediction;
            if (!float.IsFinite(timeToLandingSeconds) ||
                timeToLandingSeconds < 0f ||
                timeToLandingSeconds > settings.MaximumPredictionTimeSeconds)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.LandingTimeInvalid,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            if (!currentContact && !hasMotionTimeline && bodyTrajectory == null)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.MotionTimelineUnavailable,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    0,
                    currentSole,
                    default,
                    default);
            }
            bool requiresFutureBodyTranslation =
                !currentContact && timeToLandingSeconds > 0.000001f;
            if (requiresFutureBodyTranslation && bodyTrajectory == null)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.FutureBodyTranslationUnavailable,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }
            if (requiresFutureBodyTranslation &&
                bodyTrajectory.DurationSeconds + 0.0001f < timeToLandingSeconds)
            {
                return RejectedEvent(
                    side,
                    CharacterFootLandingPredictionRejectReason.FutureBodyTranslationRangeInvalid,
                    stepSource,
                    in landingEvent,
                    timeToLandingSeconds,
                    trajectoryGeneration,
                    currentSole,
                    default,
                    default);
            }

            CharacterFutureBodyTranslationSample bodyTranslation =
                bodyTrajectory != null
                    ? bodyTrajectory.Evaluate(timeToLandingSeconds)
                    : default;
            Vector3 rawLanding = currentContact
                ? currentSole
                : CharacterFootLandingPredictor.ProjectRawLanding(
                    body.VisiblePosition,
                    body.VisibleRotation,
                    in bodyTranslation,
                    landingEvent.RootLocalLanding);
            Vector3 componentUp = body.VisibleRotation * Vector3.up;
            CharacterFootLandingObservationRefreshMode refreshMode =
                currentContact
                    ? CharacterFootLandingObservationRefreshMode
                        .ForcedPlantVerification
                    : footMotion.InApproachContactToLanding ||
                      footMotion.LockMode == AnimationFootStepObservationLockMode.Sliding
                        ? CharacterFootLandingObservationRefreshMode
                            .ChangedContactApproachInput
                        : CharacterFootLandingObservationRefreshMode.Thresholded;
            CharacterFootLandingObservationResult observation =
                CharacterFootLandingPredictor.ResolveObservation(
                    side,
                    landingEvent.Identity,
                    landingEvent.SourceSampleIdentity,
                    landingEvent.LandingCycle,
                    rawLanding,
                    componentUp,
                    refreshMode,
                    m_Settings.ProfileRevision,
                    in settings,
                    m_WorldQuery,
                    observationPool,
                    committedObservation,
                    out pendingObservation,
                    currentContact ? animatedFoot.HeelPosition - currentSole : default,
                    currentContact ? animatedFoot.ToePosition - currentSole : default);
            CharacterFootLandingObservationPage observationPage =
                observation.Page;
            ref readonly CharacterFootLandingQueryResult queryResult =
                ref observationPage.Result;
            bool accepted = queryResult.Accepted;
            CharacterFootLandingQueryRejectReason queryRejectReason =
                queryResult.RejectReason;
            var observationDiagnostics =
                new CharacterFootLandingObservationDiagnostics(in observation);
            return new CharacterFootLandingPredictionResult(
                side,
                accepted
                    ? CharacterFootLandingPredictionState.Accepted
                    : CharacterFootLandingPredictionState.Rejected,
                accepted
                    ? CharacterFootLandingPredictionRejectReason.None
                    : queryRejectReason ==
                      CharacterFootLandingQueryRejectReason.CapacityExceeded
                        ? CharacterFootLandingPredictionRejectReason
                            .GroundQueryCapacityExceeded
                        : CharacterFootLandingPredictionRejectReason
                            .GroundQueryMissed,
                stepSource,
                landingEvent.Identity,
                trajectoryGeneration,
                1f,
                timeToLandingSeconds,
                landingEvent.RootLocalLanding,
                bodyTrajectory != null,
                bodyTrajectory != null
                    ? bodyTrajectory.SourceIdentity
                    : string.Empty,
                in bodyTranslation,
                currentSole,
                rawLanding,
                in observationDiagnostics,
                in observationPage.Query,
                in queryResult.Support,
                in queryResult.SelectionDiagnostics);
        }

        static CharacterFootLandingPredictionResult RejectedEvent(
            CharacterFootSide side,
            CharacterFootLandingPredictionRejectReason reason,
            CharacterFootLandingStepSource stepSource,
            in AnimationFootMotionEventOccurrence landingEvent,
            float timeToLandingSeconds,
            ulong trajectoryGeneration,
            Vector3 currentSole,
            Vector3 rawLanding,
            CharacterFootPlacementQueryRequest query) =>
            new CharacterFootLandingPredictionResult(
                side,
                CharacterFootLandingPredictionState.Rejected,
                reason,
                stepSource,
                landingEvent.IsBound ? landingEvent.Identity : 0,
                trajectoryGeneration,
                landingEvent.IsBound ? 1f : 0f,
                landingEvent.IsBound && float.IsFinite(timeToLandingSeconds)
                    ? Mathf.Max(0f, timeToLandingSeconds)
                    : 0f,
                landingEvent.IsBound
                    ? landingEvent.RootLocalLanding
                    : default,
                false,
                string.Empty,
                default,
                currentSole,
                rawLanding,
                default,
                in query,
                default,
                default);

        CharacterFutureBodyTranslation ResolveBodyTrajectory(
            CharacterFootPlacementBank bank,
            in AnimationFootMotionRuntimeSample leftFootMotion,
            in AnimationFootMotionRuntimeSample rightFootMotion,
            in CommittedLocomotionPlanarMotionTimeline timeline,
            float currentSegmentRemainingSeconds,
            float presentationDeltaSeconds,
            in CharacterBodyPresentationFrame body)
        {
            ref readonly CharacterFootLandingPredictionSettings settings =
                ref m_Settings.LandingPrediction;
            Vector2 rawCurrentVelocity = new Vector2(
                body.TargetVelocity.x,
                body.TargetVelocity.z);
            Vector2 rawContinuationVelocity = timeline.IsValid
                ? new Vector2(
                    timeline.ContinuationVelocityX,
                    timeline.ContinuationVelocityZ)
                : default;
            string predictionSourceIdentity =
                m_FutureBodyTranslationSource?.PredictionSourceIdentity ??
                string.Empty;
            CharacterFootPredictionMotionResult predictionMotion =
                CharacterFootPredictionMotionRuntime.Evaluate(
                    ref bank.PredictionMotion,
                    timeline.IsValid,
                    timeline.IsValid ? timeline.Generation : 0,
                    body.ResetSequence,
                    predictionSourceIdentity,
                    rawCurrentVelocity,
                    rawContinuationVelocity,
                    presentationDeltaSeconds,
                    in settings);
            bank.PredictionMotionResult = predictionMotion;
            float maximum = m_Settings.LandingPrediction.MaximumPredictionTimeSeconds;
            float leftTime = ResolvePredictionTime(
                in leftFootMotion, maximum);
            float rightTime = ResolvePredictionTime(
                in rightFootMotion, maximum);
            float duration = Mathf.Max(leftTime, rightTime);
            if (!predictionMotion.IsValid ||
                m_FutureBodyTranslationSource == null)
            {
                bank.BodyTrajectory.Clear();
                bank.HasBodyTrajectoryAttempt = false;
                bank.BodyTrajectoryPredictionMotionRevision = 0;
                return null;
            }
            if (duration <= 0f)
            {
                return null;
            }

            bool sameCommittedBody = bank.HasBodyTrajectoryAttempt &&
                                     bank.BodyTrajectoryTick == body.CurrentTick &&
                                     bank.BodyTrajectoryResetSequence == body.ResetSequence &&
                                     bank.BodyTrajectoryGeneration == timeline.Generation &&
                                     bank.BodyTrajectoryAuthorityTick == timeline.AuthorityTick.Value &&
                                     bank.BodyTrajectoryPredictionMotionRevision ==
                                     predictionMotion.Revision;
            if (sameCommittedBody &&
                duration <= bank.BodyTrajectoryRequestedDuration + 0.0001f)
            {
                return bank.BodyTrajectory.IsAvailable
                    ? bank.BodyTrajectory
                    : null;
            }

            bank.HasBodyTrajectoryAttempt = true;
            bank.BodyTrajectoryTick = body.CurrentTick;
            bank.BodyTrajectoryResetSequence = body.ResetSequence;
            bank.BodyTrajectoryGeneration = timeline.Generation;
            bank.BodyTrajectoryAuthorityTick = timeline.AuthorityTick.Value;
            bank.BodyTrajectoryPredictionMotionRevision =
                predictionMotion.Revision;
            bank.BodyTrajectoryRequestedDuration = duration;
            bank.BodyTrajectory.Clear();

            var request = new CharacterFutureBodyTranslationRequest(
                m_ActorId,
                duration,
                predictionMotion.StableCurrentVelocity.x,
                predictionMotion.StableCurrentVelocity.y,
                predictionMotion.StableContinuationVelocity.x,
                predictionMotion.StableContinuationVelocity.y,
                currentSegmentRemainingSeconds,
                timeline.HasContinuation,
                leftTime,
                0f,
                rightTime,
                0f);
            if (m_FutureBodyTranslationSource.TryPredict(
                    in request,
                    bank.BodyTrajectory))
                return bank.BodyTrajectory;
            return null;
        }

        static float ResolvePredictionTime(
            in AnimationFootMotionRuntimeSample step,
            float maximum) =>
            step.IsAuthoritative && step.HasConsistentLandingEventIdentity &&
            step.TimeToLandingSeconds > 0.000001f &&
            step.TimeToLandingSeconds <= maximum
                ? step.TimeToLandingSeconds
                : 0f;

        static float ResolveCurrentSegmentRemainingSeconds(
            in CommittedLocomotionPlanarMotionTimeline timeline,
            in CharacterBodyPresentationFrame body)
        {
            if (timeline.CurrentSegmentDurationTicks == 0)
                return float.PositiveInfinity;
            ulong elapsedWholeTicks = body.CurrentTick > timeline.AuthorityTick.Value
                ? body.CurrentTick - timeline.AuthorityTick.Value
                : 0;
            double elapsedTicks = elapsedWholeTicks + body.SampleAlpha;
            double remainingTicks = Math.Max(
                0d,
                timeline.CurrentSegmentDurationTicks - elapsedTicks);
            return (float)(remainingTicks / timeline.TickRate);
        }

        static CharacterFootActionOccupancy ResolveActionOccupancy(
            in CharacterFootPlacementPoseInput pose,
            CharacterFootSide side)
        {
            ulong actionInstanceIdentity = 0;
            float selectedWeight = 0f;
            for (int i = 0; i < pose.ContributionCount; i++)
            {
                ref readonly AnimationPoseSourceContribution contribution = ref pose.Contributions[i];
                if (contribution.Kind != AnimationPoseContributionKind.Live ||
                    contribution.SourceIdRef.SourceActionInstanceId == 0)
                {
                    continue;
                }
                float weight = side == CharacterFootSide.Left
                    ? contribution.LeftFootWeight
                    : contribution.RightFootWeight;
                ulong candidateIdentity = contribution.SourceIdRef.SourceActionInstanceId;
                if (weight <= 0.0001f ||
                    weight < selectedWeight ||
                    Mathf.Abs(weight - selectedWeight) <= 0.0001f &&
                    actionInstanceIdentity != 0 &&
                    candidateIdentity >= actionInstanceIdentity)
                {
                    continue;
                }
                actionInstanceIdentity = candidateIdentity;
                selectedWeight = weight;
            }
            return new CharacterFootActionOccupancy(
                actionInstanceIdentity,
                selectedWeight);
        }

        static CharacterFootGoalOwnershipLossReason ResolveFootGoalOwnershipLoss(
            bool grounded,
            bool authoritative)
        {
            CharacterFootGoalOwnershipLossReason reason =
                CharacterFootGoalOwnershipLossReason.None;
            if (!grounded)
                reason |= CharacterFootGoalOwnershipLossReason.Ungrounded;
            if (!authoritative)
            {
                reason |= CharacterFootGoalOwnershipLossReason
                    .SourceLineageInvalidated;
            }
            return reason;
        }

        static CharacterFullBodyIkGoal CreatePelvisGoal(
            in CharacterFootStrideHipsResult strideHips,
            Transform poseRoot)
        {
            Vector3 translation = default;
            float weight = 0f;
            if (strideHips.ProducesPelvisGoal && poseRoot != null)
            {
                translation = poseRoot.InverseTransformVector(strideHips.PelvisDelta);
                weight = strideHips.PositionWeight;
            }
            return new CharacterFullBodyIkGoal(
                CharacterFullBodyIkEffectorSlot.PelvisPreSolveTranslation,
                translation,
                Quaternion.identity,
                weight,
                0f,
                CharacterFullBodyIkGoalApplication.PelvisPreSolveTranslation,
                CharacterFullBodyIkGoalSourceKind.FootPlacement,
                -1);
        }

        static CharacterFullBodyIkGoal EncodeFootGoal(in CharacterResolvedFootResult result)
        {
            ref readonly CharacterFootGoalTarget target = ref result.GoalTarget;
            return new CharacterFullBodyIkGoal(
                result.Identity.Side == CharacterFootSide.Left
                    ? CharacterFullBodyIkEffectorSlot.LeftFoot
                    : CharacterFullBodyIkEffectorSlot.RightFoot,
                target.ComponentPosition,
                target.ComponentRotation,
                target.PositionWeight,
                target.RotationWeight,
                CharacterFullBodyIkGoalApplication.FootPlacementEffectorTarget,
                CharacterFullBodyIkGoalSourceKind.FootPlacement,
                -1);
        }

        void RequireAlive()
        {
            if (m_Disposed)
                throw new ObjectDisposedException(nameof(CharacterFootPlacementModule));
        }

        public void Dispose()
        {
            if (m_Disposed)
                return;
            m_Disposed = true;
            m_LeftGroundPath.Reset();
            m_RightGroundPath.Reset();
            m_LeftLandingObservation.Reset();
            m_RightLandingObservation.Reset();
            m_LeftCurrentSupport.Reset();
            m_RightCurrentSupport.Reset();
        }
    }
}
