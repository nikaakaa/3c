using System;
using KK.GeneratedDiagnosticSampling;
using ThirdPersonCharacter.Pipeline.Presentation;
using Unity.Collections;
using UnityEngine;

namespace ThirdPersonCharacter.Pipeline.Animation {
    public readonly struct AnimationFootMotionRuntimeSample
    {

        internal AnimationFootMotionRuntimeSample(
            float footHeight,
            float toeHeight,
            float toeSpeed,
            float positionError,
            float rotationError,
            float contact,
            AnimationFootStepObservationLockMode lockMode,
            float lockWeight,
            float support,
            in AnimationFootMotionEventFrame events)
        {
            FootHeight = RequireNonNegative(footHeight, nameof(footHeight));
            if (!float.IsFinite(toeHeight))
                throw new ArgumentOutOfRangeException(nameof(toeHeight), toeHeight, "Foot observation must be finite.");
            ToeHeight = toeHeight;
            ToeSpeed = RequireNonNegative(toeSpeed, nameof(toeSpeed));
            PositionError = RequireNonNegative(positionError, nameof(positionError));
            RotationError = RequireNonNegative(rotationError, nameof(rotationError));
            Contact = NormalizeCurveWeight(contact, nameof(contact));
            if ((byte)lockMode > (byte)AnimationFootStepObservationLockMode.Locked)
                throw new ArgumentOutOfRangeException(nameof(lockMode), lockMode, "Foot observation lock mode is invalid.");
            LockMode = lockMode;
            LockWeight = NormalizeCurveWeight(lockWeight, nameof(lockWeight));
            Support = NormalizeCurveWeight(support, nameof(support));
            if (!events.IsValid)
                throw new ArgumentException("Foot observation event frame is invalid.", nameof(events));
            Events = events;
            m_IsSpecified = 1;
        }

        readonly byte m_IsSpecified;
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float FootHeight { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float ToeHeight { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float ToeSpeed { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float PositionError { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float RotationError { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float Contact { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public AnimationFootStepObservationLockMode LockMode { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float LockWeight { get; }
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float Support { get; }
        public readonly AnimationFootMotionEventFrame Events;
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        public bool IsValid => m_IsSpecified != 0;
        public bool HasPredictiveLanding =>
            IsValid && Events.NextLanding.IsBound &&
            (Events.Phase == AnimationFootMotionEventPhase.PreSwing ||
             Events.Phase == AnimationFootMotionEventPhase.Swing ||
             Events.Phase == AnimationFootMotionEventPhase.ApproachContact);
        public bool IsPreSwing =>
            IsValid && Events.Phase == AnimationFootMotionEventPhase.PreSwing;
        public bool IsSwing =>
            IsValid &&
            (Events.Phase == AnimationFootMotionEventPhase.Swing ||
             Events.Phase == AnimationFootMotionEventPhase.ApproachContact);
        [DiagnosticField]
        [DiagnosticKey("formal-landing-event")]
        [DiagnosticGroup("formal-source")]
        public ulong LandingEventIdentity =>
            HasPredictiveLanding ? Events.NextLanding.Identity : 0;
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float TimeToLandingSeconds =>
            HasPredictiveLanding ? Events.TimeToLandingSeconds : 0f;
        [DiagnosticField]
        [DiagnosticGroup("formal-motion")]
        [DiagnosticAvailability(DiagnosticAvailabilityReference.Member, nameof(IsValid))]
        public float Distance =>
            HasPredictiveLanding ? Events.NextLanding.Distance : 0f;
        public Vector3 RootLocalLanding =>
            HasPredictiveLanding ? Events.NextLanding.RootLocalLanding : default;
        public float SwingProgress =>
            HasPredictiveLanding ? Events.SwingProgress : 0f;
        [DiagnosticField]
        [DiagnosticKey("formal-approach-progress")]
        [DiagnosticGroup("formal-source")]
        public float ApproachContactToLandingProgress =>
            HasPredictiveLanding && Events.InApproachContactToLanding
                ? Events.ApproachContactToLandingProgress
                : 0f;
        public int EventOrdinal =>
            HasPredictiveLanding ? Events.NextLanding.Ordinal : 0;
        [DiagnosticField]
        [DiagnosticKey("formal-source-cycle")]
        [DiagnosticGroup("formal-source")]
        public int SourceSampleCycle =>
            HasPredictiveLanding ? Events.NextLanding.LandingCycle : 0;
        [DiagnosticField]
        [DiagnosticKey("formal-source-sample-identity")]
        [DiagnosticGroup("formal-source")]
        public ulong SourceSampleIdentity =>
            HasPredictiveLanding ? Events.NextLanding.SourceSampleIdentity : 0;
        [DiagnosticField]
        [DiagnosticKey("formal-contribution-continuity")]
        [DiagnosticGroup("formal-source")]
        public ulong ContributionContinuityIdentity =>
            HasPredictiveLanding
                ? Events.NextLanding.ContributionContinuityIdentity
                : 0;
        [DiagnosticField]
        [DiagnosticKey("formal-authoritative")]
        [DiagnosticGroup("formal-source")]
        public bool IsAuthoritative => IsValid;
        public bool HasConsistentLandingEventIdentity =>
            HasPredictiveLanding && LandingEventIdentity != 0;
        public bool HasCurrentContactEvent =>
            IsValid && Events.CurrentContact.IsBound;
        public ulong CurrentContactEventIdentity =>
            HasCurrentContactEvent ? Events.CurrentContact.Identity : 0;

        [DiagnosticField]
        [DiagnosticKey("formal-in-approach")]
        [DiagnosticGroup("formal-source")]
        public bool InApproachContactToLanding =>
            HasPredictiveLanding && Events.InApproachContactToLanding;

        internal AnimationFootMotionRuntimeSample BindEventLineage(
            ulong sourceSampleIdentity,
            ulong contributionContinuityIdentity,
            CharacterFootSide side) =>
            new AnimationFootMotionRuntimeSample(
                in this,
                Events.Bind(
                    sourceSampleIdentity,
                    contributionContinuityIdentity,
                    side),
                FootHeight,
                ToeSpeed);

        AnimationFootMotionRuntimeSample(
            in AnimationFootMotionRuntimeSample source,
            in AnimationFootMotionEventFrame events,
            float footHeight,
            float toeSpeed)
        {
            FootHeight = footHeight;
            ToeHeight = source.ToeHeight;
            ToeSpeed = toeSpeed;
            PositionError = source.PositionError;
            RotationError = source.RotationError;
            Contact = source.Contact;
            LockMode = source.LockMode;
            LockWeight = source.LockWeight;
            Support = source.Support;
            Events = events;
            m_IsSpecified = source.m_IsSpecified;
        }

        internal AnimationFootMotionRuntimeSample WithFootHeight(float footHeight) =>
            new AnimationFootMotionRuntimeSample(in this, in Events, footHeight, ToeSpeed);

        internal AnimationFootMotionRuntimeSample CaptureStoredPose()
        {
            var events = new AnimationFootMotionEventFrame(
                in Events.CurrentContact,
                default,
                Events.CurrentContact.IsValid
                    ? AnimationFootMotionEventPhase.Contact
                    : AnimationFootMotionEventPhase.Unavailable,
                0f, 0f, 0f);
            return new AnimationFootMotionRuntimeSample(in this, in events, FootHeight, 0f);
        }

        static float RequireNonNegative(float value, string parameter)
        {
            if (!float.IsFinite(value) || value < 0f)
                throw new ArgumentOutOfRangeException(parameter, value, "Foot observation must be finite and non-negative.");
            return value;
        }

        static float NormalizeCurveWeight(float value, string parameter)
        {
            // AnimationCurve evaluation can round just outside the domain near a valid endpoint.
            const float tolerance = 0.000001f;
            if (!float.IsFinite(value) || value < -tolerance || value > 1f + tolerance)
                throw new ArgumentOutOfRangeException(parameter, value, "Foot observation weight must be in [0, 1].");
            return Mathf.Clamp01(value);
        }
    }
    internal readonly struct AnimationFootMotionSourceSample
    {
        internal AnimationFootMotionSourceSample(
            int sourceNameIndex,
            ulong sourceSampleIdentity,
            int clipBindingIndex,
            int cycle,
            float normalizedTime,
            in AnimationFootMotionRuntimeSample left,
            in AnimationFootMotionRuntimeSample right)
        {
            SourceNameIndex = sourceNameIndex;
            SourceSampleIdentity = sourceSampleIdentity;
            ClipBindingIndex = clipBindingIndex;
            Cycle = cycle;
            NormalizedTime = normalizedTime;
            Left = left;
            Right = right;
        }

        internal readonly int SourceNameIndex;
        internal readonly ulong SourceSampleIdentity;
        internal readonly int ClipBindingIndex;
        internal readonly int Cycle;
        internal readonly float NormalizedTime;
        internal readonly AnimationFootMotionRuntimeSample Left;
        internal readonly AnimationFootMotionRuntimeSample Right;

        internal AnimationFootMotionSourceSample BindContribution(ulong continuityIdentity) =>
            new AnimationFootMotionSourceSample(
                SourceNameIndex, SourceSampleIdentity, ClipBindingIndex, Cycle, NormalizedTime,
                Left.BindEventLineage(SourceSampleIdentity, continuityIdentity, CharacterFootSide.Left),
                Right.BindEventLineage(SourceSampleIdentity, continuityIdentity, CharacterFootSide.Right));

        internal AnimationFootMotionSourceSample CaptureStoredPose() =>
            new AnimationFootMotionSourceSample(
                SourceNameIndex, SourceSampleIdentity, ClipBindingIndex, Cycle, NormalizedTime,
                Left.CaptureStoredPose(), Right.CaptureStoredPose());

        internal AnimationFootMotionSourceSample BlendFootHeights(
            NativeSlice<AnimationPrimitivePoseContribution> contributions,
            int count)
        {
            float leftHeight = 0f;
            float rightHeight = 0f;
            float leftWeight = 0f;
            float rightWeight = 0f;
            for (int i = 0; i < count; i++)
            {
                AnimationPrimitivePoseContribution contribution = contributions[i];
                leftHeight += contribution.FootMotion.Left.FootHeight * contribution.LeftFootWeight;
                rightHeight += contribution.FootMotion.Right.FootHeight * contribution.RightFootWeight;
                leftWeight += contribution.LeftFootWeight;
                rightWeight += contribution.RightFootWeight;
            }
            return new AnimationFootMotionSourceSample(
                SourceNameIndex, SourceSampleIdentity, ClipBindingIndex, Cycle, NormalizedTime,
                Left.WithFootHeight(leftWeight > 0f ? leftHeight / leftWeight : 0f),
                Right.WithFootHeight(rightWeight > 0f ? rightHeight / rightWeight : 0f));
        }
    }
}