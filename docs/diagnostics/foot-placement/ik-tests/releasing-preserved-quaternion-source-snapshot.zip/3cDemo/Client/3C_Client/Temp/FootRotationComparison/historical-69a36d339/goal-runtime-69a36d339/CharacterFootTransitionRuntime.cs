namespace ThirdPersonCharacter.Pipeline.Presentation
{
    internal static class CharacterFootTransitionRuntime
    {
        internal static void Apply(
            ref CharacterFootLifecycleContext context,
            in CharacterFootTransitionDecision decision,
            in CharacterFootStateFrame frame)
        {
            if (decision.Phase == CharacterFootTransitionPhase.PreInterpolation)
            {
                UpdateContactTransition(
                    ref context.ContactTransition,
                    in decision,
                    in frame);
            }
            context.Discrete.State = decision.TargetState;
            context.Discrete.LockResponse = decision.TargetLockResponse;
            switch (decision.AnchorCommand)
            {
                case CharacterFootAnchorCommand.None:
                case CharacterFootAnchorCommand.Retain:
                    break;
                case CharacterFootAnchorCommand.Create:
                    context.Contact.HasContact = true;
                    context.Contact.EventIdentity =
                        frame.ContactLanding.LandingEventIdentity;
                    context.Contact.AcquiredFrameSequence =
                        frame.FrameSequence;
                    context.Contact.AcquiredCompletionIdentity =
                        frame.CompletionIdentity;
                    context.Contact.WorldRevision = frame.WorldRevision;
                    context.Contact.SurfaceIdentity =
                        frame.ContactLanding.SurfaceIdentity;
                    context.Contact.Anchor = frame.ContactLanding.Point;
                    context.Contact.Normal = frame.ContactLanding.Normal;
                    break;
                case CharacterFootAnchorCommand.Release:
                    context.Contact.Clear();
                    context.ContactTransition.CompletedLockWeightEventIdentity = 0;
                    break;
                default:
                    throw new System.InvalidOperationException(
                        "Foot anchor command is invalid.");
            }
        }

        static void UpdateContactTransition(
            ref CharacterFootContactTransitionContext context,
            in CharacterFootTransitionDecision decision,
            in CharacterFootStateFrame frame)
        {
            ulong eventIdentity = frame.LockRequest.EventIdentity;
            bool isInZone = frame.LockRequest.IsInZone;
            bool isSliding = frame.LockRequest.IsSliding;
            bool lockNow = frame.LockRequest.LockNow;
            bool previousIsMoving = !context.HasPreviousRequest || context.IsMoving;
            bool previousIsLocking = context.IsLocking;
            bool groundedEdge = false;
            bool releasedEdge = false;
            if (eventIdentity != 0 &&
                context.CompletedLockWeightEventIdentity != 0 &&
                context.CompletedLockWeightEventIdentity != eventIdentity)
            {
                context.CompletedLockWeightEventIdentity = 0;
            }
            if (decision.ContactEdge == CharacterFootContactEdge.None)
            {
                context.SecondsSinceEdge += frame.DeltaSeconds;
            }
            else
            {
                context.SecondsSinceEdge = 0f;
                if (decision.ContactEdge == CharacterFootContactEdge.Falling ||
                    decision.ContactEdge == CharacterFootContactEdge.EventChanged)
                {
                    context.LatestReleasedContactEventIdentity =
                        context.PreviousEventIdentity;
                }
                if (decision.ContactEdge == CharacterFootContactEdge.Rising ||
                    decision.ContactEdge == CharacterFootContactEdge.EventChanged)
                {
                    context.LatestContactEventIdentity =
                        frame.LockRequest.EventIdentity;
                }
            }
            if (previousIsMoving)
            {
                if (isInZone)
                {
                    context.EnterLockZone = lockNow;
                    context.EnterGroundedZone = true;
                    context.IsBreakToGround = context.RemainTime > context.Time;
                    context.Time = 0f;
                    groundedEdge = true;
                }
                else
                {
                    context.EnterLockZone = false;
                }
            }
            else if (previousIsLocking)
            {
                if (isInZone)
                {
                    context.LeaveLockZone = !lockNow;
                }
                else
                {
                    context.LeaveLockZone = true;
                    context.LeaveGroundedZone = true;
                    context.Time = 0f;
                    releasedEdge = true;
                }
            }
            else if (isInZone)
            {
                context.EnterLockZone = lockNow;
            }
            else
            {
                context.EnterLockZone = false;
                context.LeaveGroundedZone = true;
                context.Time = 0f;
                releasedEdge = true;
            }
            context.CurrentContactEdge = groundedEdge
                ? CharacterFootContactEdge.Rising
                : releasedEdge
                    ? CharacterFootContactEdge.Falling
                    : CharacterFootContactEdge.None;
            context.CurrentEventIdentity = eventIdentity;
            context.IsMoving = !isInZone;
            context.IsLocking = lockNow;
            context.PreviousIsInZone = isInZone;
            context.PreviousIsSliding = isSliding;
            context.HasPreviousRequest = true;
            context.PreviousRequestedLock = frame.LockRequest.RequestsLock;
            context.PreviousEventIdentity = frame.LockRequest.EventIdentity;
            context.PreviousMode = frame.LockRequest.Mode;
            context.PreviousWeight = frame.LockRequest.Weight;
            if (frame.LockRequest.RequestsLock && eventIdentity != 0 &&
                frame.LockRequest.Weight >=
                1f - CharacterFootConstraintMath.GeometryEpsilon)
            {
                context.CompletedLockWeightEventIdentity = eventIdentity;
            }
        }
    }
}
